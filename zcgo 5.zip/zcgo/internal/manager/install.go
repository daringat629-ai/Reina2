// Поиск, проверка и установка модулей; замена версий; удаление; цикл тиков. Порты discovery.py, validation.py,
// installer.py, hot_swap.py, rollback.py, uninstall.py и tick менеджера.
package manager

import (
	"archive/zip"
	"io"
	"io/fs"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"

	"zcgo/internal/kernel"
)

// Discovered — найденная в каталоге деталь.
type Discovered struct {
	Dir      string
	Manifest *kernel.Manifest
}

// Discover ищет подкаталоги с manifest.json. Битые манифесты попадают в errs, а не прерывают поиск.
func Discover(root string) (map[string]Discovered, []string) {
	found := map[string]Discovered{}
	var errs []string
	ents, err := os.ReadDir(root)
	if err != nil {
		return found, errs
	}
	for _, e := range ents {
		if !e.IsDir() {
			continue
		}
		dir := filepath.Join(root, e.Name())
		if _, err := os.Stat(filepath.Join(dir, "manifest.json")); err != nil {
			continue
		}
		mod, err := kernel.LoadManifest(filepath.Join(dir, "manifest.json"))
		if err != nil {
			errs = append(errs, dir+": "+err.Error())
			continue
		}
		found[mod.Name] = Discovered{Dir: dir, Manifest: mod}
	}
	return found, errs
}

// ValidateSource проверяет модуль до установки: манифест, наличие файлов, добавки к промптам.
func ValidateSource(path string) (*kernel.Manifest, error) {
	if _, err := os.Stat(filepath.Join(path, "manifest.json")); err != nil {
		return nil, kernel.Newf(kernel.KindContract, "%s: нет manifest.json", path)
	}
	mod, err := kernel.LoadManifest(filepath.Join(path, "manifest.json"))
	if err != nil {
		return nil, err
	}
	checkFile := func(rel string) error {
		if _, err := os.Stat(filepath.Join(path, rel)); err != nil {
			return kernel.Newf(kernel.KindContract, "%s: файл %s из command не найден в модуле", mod.Name, rel)
		}
		return nil
	}
	if mod.Kind == "service" || mod.Kind == "job" {
		if cmd := stringsOfAny(mod.Run["command"]); len(cmd) > 0 && strings.HasPrefix(cmd[0], "${module_dir}") {
			if err := checkFile(strings.TrimPrefix(cmd[0], "${module_dir}/")); err != nil {
				return nil, err
			}
		}
	}
	for _, arg := range stringsOfAny(mod.Run["command"]) {
		if rel, ok := strings.CutPrefix(arg, "${module_dir}/"); ok {
			if err := checkFile(rel); err != nil {
				return nil, err
			}
		}
	}
	for _, p := range mod.Patches {
		id := stringOf(p["id"])
		if stringOf(p["key"]) == "prompt.append" {
			file := stringOf(p["file"])
			raw, err := os.ReadFile(filepath.Join(path, file))
			if err != nil {
				return nil, kernel.Newf(kernel.KindContract, "%s: файл %s патча %s не найден в модуле", mod.Name, file, id)
			}
			if !utf8.Valid(raw) {
				return nil, kernel.Newf(kernel.KindContract, "%s: файл %s патча %s не в кодировке UTF-8", mod.Name, file, id)
			}
			if len(raw) > kernel.MaxPromptBytes || strings.ContainsRune(string(raw), 0) {
				return nil, kernel.Newf(kernel.KindContract, "%s: файл %s патча %s больше %d байт или содержит нулевые символы", mod.Name, file, id, kernel.MaxPromptBytes)
			}
			continue
		}
		for _, arg := range stringsOfAny(p["command"]) {
			if rel, ok := strings.CutPrefix(arg, "${module_dir}/"); ok {
				if _, err := os.Stat(filepath.Join(path, rel)); err != nil {
					return nil, kernel.Newf(kernel.KindContract, "%s: файл %s реакции %s не найден в модуле", mod.Name, arg, id)
				}
			}
		}
	}
	return mod, nil
}

// unpack распаковывает zip во временный каталог (с защитой от выхода за пределы). Возвращает каталог модуля и временный корень.
func unpack(source string) (string, string, error) {
	st, err := os.Stat(source)
	if err != nil || st.IsDir() || !strings.HasSuffix(source, ".zip") {
		return source, "", nil
	}
	tmp, err := os.MkdirTemp("", "zerocore_")
	if err != nil {
		return "", "", err
	}
	fail := func(err error) (string, string, error) {
		_ = os.RemoveAll(tmp)
		return "", "", err
	}
	zr, err := zip.OpenReader(source)
	if err != nil {
		return fail(err)
	}
	defer zr.Close()
	for _, f := range zr.File {
		if strings.HasPrefix(f.Name, "/") || containsDotDot(f.Name) {
			return fail(kernel.Newf(kernel.KindGeneric, "небезопасный путь в архиве: %s", f.Name))
		}
	}
	for _, f := range zr.File {
		dest := filepath.Join(tmp, filepath.FromSlash(f.Name))
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(dest, 0o755); err != nil {
				return fail(err)
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
			return fail(err)
		}
		rc, err := f.Open()
		if err != nil {
			return fail(err)
		}
		out, err := os.OpenFile(dest, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o644)
		if err != nil {
			rc.Close()
			return fail(err)
		}
		_, err = io.Copy(out, rc)
		rc.Close()
		out.Close()
		if err != nil {
			return fail(err)
		}
	}
	if _, err := os.Stat(filepath.Join(tmp, "manifest.json")); err == nil {
		return tmp, tmp, nil
	}
	ents, _ := os.ReadDir(tmp)
	var subs []string
	for _, e := range ents {
		if e.IsDir() {
			if _, err := os.Stat(filepath.Join(tmp, e.Name(), "manifest.json")); err == nil {
				subs = append(subs, filepath.Join(tmp, e.Name()))
			}
		}
	}
	if len(subs) != 1 {
		return fail(kernel.Newf(kernel.KindGeneric, "в архиве должен быть ровно один модуль с manifest.json"))
	}
	return subs[0], tmp, nil
}

func containsDotDot(name string) bool {
	for _, p := range strings.Split(name, "/") {
		if p == ".." {
			return true
		}
	}
	return false
}

// copyTree копирует каталог (симлинки разыменовываются, как в shutil.copytree по умолчанию).
func copyTree(src, dst string) error {
	return filepath.WalkDir(src, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(src, p)
		target := filepath.Join(dst, rel)
		st, err := os.Stat(p)
		if err != nil {
			return err
		}
		if st.IsDir() {
			return os.MkdirAll(target, 0o755)
		}
		raw, err := os.ReadFile(p)
		if err != nil {
			return err
		}
		return os.WriteFile(target, raw, st.Mode().Perm())
	})
}

// Install ставит модуль выключенным. Возвращает его манифест.
func (m *Manager) Install(source string) (*kernel.Manifest, error) {
	src, tmp, err := unpack(source)
	if err != nil {
		return nil, err
	}
	if tmp != "" {
		defer os.RemoveAll(tmp)
	}
	mod, err := ValidateSource(src)
	if err != nil {
		return nil, err
	}
	root := m.ModuleRoot(mod.Name)
	dest := filepath.Join(root, "versions", mod.Version)
	err = m.Txn("install "+mod.Name+" "+mod.Version, func(t *kernel.Txn) error {
		var st State
		if err := m.Store.Load(&st); err != nil {
			return err
		}
		if st.Modules == nil {
			st.Modules = map[string]*ModuleState{}
		}
		_, known := st.Modules[mod.Name]
		first := !known
		if _, err := os.Stat(dest); err == nil {
			return kernel.Newf(kernel.KindGeneric, "%s %s: эта версия уже установлена", mod.Name, mod.Version)
		}
		undoPath := dest
		if first {
			undoPath = root
		}
		if err := t.AddUndo("rmtree", undoPath); err != nil {
			return err
		}
		if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
			return err
		}
		if err := copyTree(src, dest); err != nil {
			return err
		}
		if first {
			if err := os.Symlink("versions/"+mod.Version, filepath.Join(root, "current")); err != nil {
				return err
			}
			st.Modules[mod.Name] = &ModuleState{Version: mod.Version, Versions: []string{mod.Version}}
		} else {
			st.Modules[mod.Name].Versions = append(st.Modules[mod.Name].Versions, mod.Version)
		}
		if err := os.MkdirAll(filepath.Join(m.Home, "data", mod.Name), 0o755); err != nil {
			return err
		}
		return m.Store.Save(st)
	})
	if err != nil {
		return nil, err
	}
	_, _ = m.Emit("module.installed", map[string]any{"module": mod.Name, "version": mod.Version})
	return mod, nil
}

// --- замена версий ---

func switchLink(link, version string) error {
	tmp := filepath.Join(filepath.Dir(link), "current.new")
	_ = os.Remove(tmp)
	if err := os.Symlink("versions/"+version, tmp); err != nil {
		return err
	}
	return os.Rename(tmp, link)
}

// Swap меняет активную версию модуля. parallel: новая стартует рядом и проверяется; stop_first: старая останавливается.
func (m *Manager) Swap(name, newVersion string) (string, string, error) {
	var old string
	err := m.Txn("swap "+name+" -> "+newVersion, func(t *kernel.Txn) error {
		var st State
		if err := m.Store.Load(&st); err != nil {
			return err
		}
		ms, ok := st.Modules[name]
		if !ok {
			return kernel.Newf(kernel.KindGeneric, "%s: не установлен", name)
		}
		if !contains(ms.Versions, newVersion) {
			return kernel.Newf(kernel.KindGeneric, "%s: версия %s не установлена (есть: %s)", name, newVersion, strings.Join(ms.Versions, ", "))
		}
		old = ms.Version
		if old == newVersion {
			return kernel.Newf(kernel.KindGeneric, "%s: версия %s уже активна", name, newVersion)
		}
		oldMod, err := m.Manifest(name, "")
		if err != nil {
			return err
		}
		newMod, err := m.Manifest(name, newVersion)
		if err != nil {
			return err
		}
		if ms.Enabled {
			manifests, err := m.EnabledManifests("", map[string]*kernel.Manifest{name: newMod}, "")
			if err != nil {
				return err
			}
			if _, err := Solve(manifests); err != nil {
				return err
			}
		}
		link := filepath.Join(m.ModuleRoot(name), "current")
		oldTarget, err := os.Readlink(link)
		if err != nil {
			return err
		}
		oldDir, newDir := m.ModuleDir(name, ""), m.ModuleDir(name, newVersion)
		running := m.IsRunning(name, oldMod)
		strategy := "parallel"
		if newMod.Kind == "external" {
			strategy = "stop_first"
		} else if h, ok := newMod.Run["handoff"].(string); ok {
			strategy = h
		}
		doSwitch := func() error {
			if err := t.AddUndo("symlink", link, oldTarget); err != nil {
				return err
			}
			return switchLink(link, newVersion)
		}
		switch {
		case !running || (newMod.Kind != "service" && newMod.Kind != "external"):
			if err := doSwitch(); err != nil {
				return err
			}
		case strategy == "parallel":
			if err := m.spawn(name, newMod, newDir, ".staging", true); err != nil {
				return err
			}
			if err := m.waitReady(name, newMod, newDir, ".staging"); err != nil {
				_, _ = m.Runner.Stop(name, 5*time.Second, ".staging")
				_, _ = m.Emit("swap.failed", map[string]any{"module": name, "version": newVersion, "error": truncate(err.Error(), 300)})
				return kernel.Newf(kernel.KindLifecycle, "%s %s: новая версия не запустилась, продолжает работать %s. %s", name, newVersion, old, err.Error())
			}
			if err := doSwitch(); err != nil {
				_, _ = m.Runner.Stop(name, 5*time.Second, ".staging")
				return err
			}
			if _, err := m.Runner.Stop(name, time.Duration(numOrDefault(oldMod.Run["stop_timeout"], 10))*time.Second, ""); err != nil {
				_, _ = m.Runner.Stop(name, 5*time.Second, ".staging")
				return err
			}
			if err := m.Runner.Promote(name, ".staging", ""); err != nil {
				return err
			}
		default:
			if err := m.stopInstance(name, oldMod, ""); err != nil {
				return err
			}
			if err := m.startInstance(name, newMod, newDir, "", false); err != nil {
				_ = m.stopInstance(name, newMod, "")
				_ = m.startInstance(name, oldMod, oldDir, "", false)
				_, _ = m.Emit("swap.failed", map[string]any{"module": name, "version": newVersion, "error": truncate(err.Error(), 300)})
				return kernel.Newf(kernel.KindLifecycle, "%s %s: не запустилась, старая версия %s возвращена. %s", name, newVersion, old, err.Error())
			}
			if err := doSwitch(); err != nil {
				return err
			}
		}
		ms.Previous = &old
		ms.Version = newVersion
		return m.Store.Save(st)
	})
	if err != nil {
		return "", "", err
	}
	_, _ = m.Emit("module.swapped", map[string]any{"module": name, "old": old, "new": newVersion})
	m.RefreshExtensions()
	return old, newVersion, nil
}

// Rollback возвращает предыдущую версию тем же способом, что и обновление.
func (m *Manager) Rollback(name string) (string, string, error) {
	st, err := m.Installed()
	if err != nil {
		return "", "", err
	}
	ms, ok := st[name]
	if !ok {
		return "", "", kernel.Newf(kernel.KindGeneric, "%s: не установлен", name)
	}
	if ms.Previous == nil || *ms.Previous == "" {
		return "", "", kernel.Newf(kernel.KindGeneric, "%s: нет предыдущей версии для отката", name)
	}
	return m.Swap(name, *ms.Previous)
}

func contains(list []string, v string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

// --- удаление ---

// Uninstall удаляет модуль. Код уходит в корзину под транзакцией; данные — по политике модуля или флагу purge.
// failAfterMove — тестовая точка: прерывает операцию после перемещения файлов (проверка отката).
func (m *Manager) Uninstall(name string, purge *bool, force bool, failAfterMove bool) (bool, error) {
	st, err := m.Installed()
	if err != nil {
		return false, err
	}
	if _, ok := st[name]; !ok {
		return false, kernel.Newf(kernel.KindGeneric, "%s: не установлен", name)
	}
	manifests, err := m.EnabledManifests("", nil, "")
	if err != nil {
		return false, err
	}
	deps := map[string]bool{}
	if _, ok := manifests[name]; ok {
		deps = Dependents(name, manifests)
	}
	if len(deps) > 0 && !force {
		return false, kernel.Newf(kernel.KindDependency, "от %s зависят включённые модули: %s (используйте force)", name, strings.Join(sortedBoolKeys(deps), ", "))
	}
	if _, ok := manifests[name]; ok {
		if _, err := m.Disable(name, true); err != nil {
			return false, err
		}
	}
	mod, err := m.Manifest(name, "")
	if err != nil {
		return false, err
	}
	if m.IsRunning(name, mod) {
		if err := m.stopInstance(name, mod, ""); err != nil {
			return false, err
		}
	}
	doPurge := mod.DataPolicy == "delete"
	if purge != nil {
		doPurge = *purge
	}
	trash := filepath.Join(m.Home, ".trash", name+"-"+strconv.FormatInt(time.Now().UnixNano()/1e6, 10))
	root := m.ModuleRoot(name)
	data := filepath.Join(m.Home, "data", name)
	cfg := m.ConfigPath(name)
	err = m.Txn("uninstall "+name, func(t *kernel.Txn) error {
		var st State
		if err := m.Store.Load(&st); err != nil {
			return err
		}
		if err := os.MkdirAll(trash, 0o755); err != nil {
			return err
		}
		if err := t.AddUndo("mv", filepath.Join(trash, "code"), root); err != nil {
			return err
		}
		if err := os.Rename(root, filepath.Join(trash, "code")); err != nil {
			return err
		}
		if _, err := os.Stat(data); doPurge && err == nil {
			if err := t.AddUndo("mv", filepath.Join(trash, "data"), data); err != nil {
				return err
			}
			if err := os.Rename(data, filepath.Join(trash, "data")); err != nil {
				return err
			}
		}
		if raw, err := os.ReadFile(cfg); doPurge && err == nil {
			if err := t.AddUndo("restore_file", cfg, string(raw)); err != nil {
				return err
			}
			if err := os.Remove(cfg); err != nil {
				return err
			}
		}
		delete(st.Modules, name)
		if err := m.Store.Save(st); err != nil {
			return err
		}
		if failAfterMove {
			return kernel.Newf(kernel.KindGeneric, "операция прервана (тестовая точка)")
		}
		return nil
	})
	if err != nil {
		return false, err
	}
	_ = os.RemoveAll(trash)
	_, _ = m.Emit("module.uninstalled", map[string]any{"module": name, "purged": doPurge})
	m.RefreshExtensions()
	return doPurge, nil
}

// --- тики (раз в минуту): задачи, здоровье, перезапуск с ограничением ---

// Tick выполняет периодическую работу. Возвращает список действий.
func (m *Manager) Tick(now time.Time) []string {
	lockPath := filepath.Join(m.Home, "tick.lock")
	lock, err := os.OpenFile(lockPath, os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		return []string{"tick: " + err.Error()}
	}
	defer lock.Close()
	if !tryLock(lock) {
		return []string{"tick уже выполняется, пропуск"}
	}
	defer unlockFile(lock)
	var actions []string
	nowF := float64(now.UnixNano()) / 1e9
	rt := map[string]any{}
	_ = m.RuntimeSt.Load(&rt)
	problems := m.CheckIntegrity()
	probsAny := toAnyList(problems)
	if len(problems) > 0 && !equalAny(rt["_integrity"], probsAny) {
		_, _ = m.Emit("integrity.broken", map[string]any{"problems": probsAny})
		actions = append(actions, "целостность нарушена: "+strings.Join(problems, "; "))
	}
	rt["_integrity"] = probsAny
	installed := m.installedMap()
	for _, n := range m.EnabledNames() {
		mod, err := m.Manifest(n, "")
		if err != nil {
			actions = append(actions, n+": "+err.Error())
			continue
		}
		e, _ := rt[n].(map[string]any)
		if e == nil {
			e = map[string]any{}
			rt[n] = e
		}
		if mod.Kind == "job" {
			interval, _ := asIntAny(mod.Run["schedule_seconds"])
			last, _ := e["last_run"].(float64)
			if nowF-last >= float64(interval) {
				mdir := m.ModuleDir(n, "")
				argv := m.expandList(stringsOfAny(mod.Run["command"]), n, mdir)
				cwd := m.expandStr(stringOrDefault(mod.Run["cwd"], "${module_dir}"), n, mdir)
				timeout := numOrDefault(mod.Run["timeout"], 55)
				rc, out := runJob(argv, cwd, m.envFor(n, mod, mdir, false), timeout)
				e["last_run"], e["last_rc"] = nowF, rc
				e["last_out"] = trimTail(out, 300)
				actions = append(actions, sprintfJob(n, rc))
				if rc != 0 {
					_, _ = m.Emit("job.failed", map[string]any{"module": n, "rc": rc})
				}
			}
		}
		h := "unknown"
		if mod.Kind != "library" || stringOf(mod.Health["type"]) != "none" {
			hh, _ := m.Health(n)
			h = hh.State
		}
		if old, _ := e["health"].(string); old != h {
			_, _ = m.Emit("health.changed", map[string]any{"module": n, "old": old, "new": h})
			e["health"] = h
		}
		if mod.Kind == "service" && stringOf(mod.Run["restart"]) == "on-failure" && installed[n] != nil && installed[n].Desired &&
			(h == "stopped" || h == "unhealthy") {
			stamps := []float64{}
			for _, t := range floatsOf(e["restarts"]) {
				if nowF-t < 600 {
					stamps = append(stamps, t)
				}
			}
			if len(stamps) >= 3 {
				if sup, _ := e["suppressed"].(bool); !sup {
					_, _ = m.Emit("restart.suppressed", map[string]any{"module": n})
					e["suppressed"] = true
				}
			} else {
				err := m.stopInstance(n, mod, "")
				if err == nil {
					err = m.startInstance(n, mod, m.ModuleDir(n, ""), "", false)
				}
				stamps = append(stamps, nowF)
				if err != nil {
					actions = append(actions, n+": перезапуск не удался: "+truncate(err.Error(), 120))
				} else {
					e["suppressed"] = false
					actions = append(actions, n+": перезапущен")
					_, _ = m.Emit("module.restarted", map[string]any{"module": n})
				}
			}
			e["restarts"] = stamps
		}
	}
	_ = m.RuntimeSt.Save(rt)
	return actions
}

func sprintfJob(name string, rc int) string {
	return name + ": задача выполнена, код " + strconv.Itoa(rc)
}

func stringOrDefault(v any, def string) string {
	if s, ok := v.(string); ok {
		return s
	}
	return def
}

func toAnyList(list []string) []any {
	out := make([]any, len(list))
	for i, s := range list {
		out[i] = s
	}
	return out
}

func equalAny(a any, b []any) bool {
	la, ok := a.([]any)
	if !ok || len(la) != len(b) {
		return false
	}
	for i := range la {
		if la[i] != b[i] {
			return false
		}
	}
	return true
}

func floatsOf(v any) []float64 {
	l, _ := v.([]any)
	out := make([]float64, 0, len(l))
	for _, x := range l {
		if f, ok := x.(float64); ok {
			out = append(out, f)
		}
	}
	return out
}

func runJob(argv []string, cwd string, env []string, timeoutSec int) (int, string) {
	if len(argv) == 0 {
		return -1, "пустая команда"
	}
	cmd := exec.Command(argv[0], argv[1:]...)
	cmd.Dir = cwd
	cmd.Env = env
	out, err := cmd.CombinedOutput()
	if err == nil {
		return 0, string(out)
	}
	if ee, ok := err.(*exec.ExitError); ok {
		return ee.ExitCode(), string(out)
	}
	return -1, err.Error()
}
