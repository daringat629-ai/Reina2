// Реакции деталей на события бота (ключ hook.event). Порт module_manager/hooks.py.
//
// Команда реакции запускается ТОЛЬКО у включённой и доверенной детали; событие уходит в stdin как JSON.
// Защита: пауза между запусками (cooldown_seconds), предел запусков в минуту, таймаут, пауза реакции после сбоев подряд.
package manager

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"os/exec"
	"sync"
	"time"

	"zcgo/internal/kernel"
)

const (
	MaxPerMinute       = 30
	PauseAfterFailures = 5
	OutLimit           = 400
	TrustCacheSeconds  = 20
)

// RunFunc запускает команду с вводом и возвращает код и вывод. Подменяется в тестах.
type RunFunc func(argv []string, stdin string, cwd string, env []string, timeout time.Duration) (rc int, out string)

// HookRecord — запись о запуске реакции.
type HookRecord struct {
	T      float64        `json:"t"`
	Module string         `json:"module"`
	Patch  string         `json:"patch"`
	RC     int            `json:"rc"`
	MS     int64          `json:"ms"`
	Event  map[string]any `json:"event"`
	Out    string         `json:"out"`
}

// HookRunner обрабатывает события и запускает реакции.
type HookRunner struct {
	mgr       *Manager
	getEvents func(since float64) []map[string]any
	run       RunFunc
	clock     func() time.Time
	Threaded  bool

	mu       sync.Mutex
	since    float64
	seen     map[string]bool
	lastRun  map[string]float64
	failures map[string]int
	paused   map[string]bool
	recent   []HookRecord
	minute   []float64
	Skipped  map[string]int
	trust    map[string]trustCacheEntry
	sem      chan struct{}
}

type trustCacheEntry struct {
	at      float64
	allowed bool
}

// NewHookRunner создаёт обработчик. getEvents отдаёт события с момента since (unix-секунды).
func NewHookRunner(m *Manager, getEvents func(since float64) []map[string]any, run RunFunc, clock func() time.Time) *HookRunner {
	if clock == nil {
		clock = time.Now
	}
	if run == nil {
		run = defaultRun
	}
	h := &HookRunner{mgr: m, getEvents: getEvents, run: run, clock: clock,
		since: nowSec(clock), seen: map[string]bool{}, lastRun: map[string]float64{}, failures: map[string]int{},
		paused: map[string]bool{}, Skipped: map[string]int{"cooldown": 0, "paused": 0, "rate_limited": 0},
		trust: map[string]trustCacheEntry{}, sem: make(chan struct{}, 4)}
	return h
}

func nowSec(clock func() time.Time) float64 { return float64(clock().UnixNano()) / 1e9 }

func defaultRun(argv []string, stdin string, cwd string, env []string, timeout time.Duration) (int, string) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	cmd.Dir = cwd
	cmd.Env = env
	cmd.Stdin = bytes.NewBufferString(stdin)
	var out bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &out
	err := cmd.Run()
	if ctx.Err() == context.DeadlineExceeded {
		return -1, "таймаут"
	}
	if err == nil {
		return 0, trimOut(out.String())
	}
	var ee *exec.ExitError
	if errors.As(err, &ee) {
		return ee.ExitCode(), trimOut(out.String())
	}
	return -2, fmt.Sprintf("не удалось запустить: %v", err)
}

func trimOut(s string) string {
	return string(bytes.TrimSpace([]byte(s)))
}

func matchesHook(patch map[string]any, event map[string]any) bool {
	on := stringOf(patch["on"])
	var ok bool
	if on == "error" {
		ok = stringOf(event["level"]) == "error"
	} else {
		ok = stringOf(event["kind"]) == on
	}
	if ok {
		if c := stringOf(patch["contains"]); c != "" {
			ok = containsFold(stringOf(event["text"]), c)
		}
	}
	return ok
}

func containsFold(text, sub string) bool {
	return bytes.Contains(bytes.ToLower([]byte(text)), bytes.ToLower([]byte(sub)))
}

func (h *HookRunner) allowed(name string) bool {
	now := nowSec(h.clock)
	if c, ok := h.trust[name]; ok && now-c.at < TrustCacheSeconds {
		return c.allowed
	}
	dir := h.mgr.ModuleDir(name, "")
	st, err := Status(h.mgr.Home, name, dir)
	ok := err == nil && st.Allowed
	h.trust[name] = trustCacheEntry{at: now, allowed: ok}
	return ok
}

// ForgetTrust сбрасывает кэш доверия (после подписи, одобрения или снятия одобрения).
func (h *HookRunner) ForgetTrust(name string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	if name == "" {
		h.trust = map[string]trustCacheEntry{}
	} else {
		delete(h.trust, name)
	}
}

type activeHook struct {
	name  string
	mod   *kernel.Manifest
	patch map[string]any
}

func (h *HookRunner) activeHooks() []activeHook {
	var out []activeHook
	for _, name := range h.mgr.EnabledNames() {
		mod, err := h.mgr.Manifest(name, "")
		if err != nil {
			continue
		}
		var hooks []map[string]any
		for _, p := range mod.Patches {
			if stringOf(p["key"]) == "hook.event" {
				hooks = append(hooks, p)
			}
		}
		if len(hooks) > 0 && h.allowed(name) {
			for _, p := range hooks {
				out = append(out, activeHook{name, mod, p})
			}
		}
	}
	return out
}

// Handle обрабатывает одно событие. Возвращает ключи запущенных реакций ("модуль/id").
func (h *HookRunner) Handle(event map[string]any) []string {
	var ran []string
	for _, a := range h.activeHooks() {
		if !matchesHook(a.patch, event) {
			continue
		}
		id := stringOf(a.patch["id"])
		key := a.name + "/" + id
		now := nowSec(h.clock)
		h.mu.Lock()
		if h.paused[key] {
			h.Skipped["paused"]++
			h.mu.Unlock()
			continue
		}
		cooldown := 60.0
		if c, ok := asInt(a.patch["cooldown_seconds"]); ok {
			cooldown = float64(c)
		}
		if now-lastOr(h.lastRun, key) < cooldown {
			h.Skipped["cooldown"]++
			h.mu.Unlock()
			continue
		}
		kept := h.minute[:0]
		for _, t := range h.minute {
			if now-t <= 60 {
				kept = append(kept, t)
			}
		}
		h.minute = kept
		if len(h.minute) >= MaxPerMinute {
			h.Skipped["rate_limited"]++
			h.mu.Unlock()
			continue
		}
		h.minute = append(h.minute, now)
		h.lastRun[key] = now
		h.mu.Unlock()
		if h.Threaded {
			go h.guarded(a, event)
		} else {
			h.runOne(a, event)
		}
		ran = append(ran, key)
	}
	return ran
}

func lastOr(m map[string]float64, k string) float64 {
	if v, ok := m[k]; ok {
		return v
	}
	return -1e12
}

func asInt(v any) (int, bool) {
	f, ok := v.(float64)
	if !ok || math.Trunc(f) != f {
		return 0, false
	}
	return int(f), true
}

func (h *HookRunner) guarded(a activeHook, event map[string]any) {
	h.sem <- struct{}{}
	defer func() { <-h.sem }()
	h.runOne(a, event)
}

func (h *HookRunner) runOne(a activeHook, event map[string]any) HookRecord {
	mdir := h.mgr.ModuleDir(a.name, "")
	argv := h.mgr.expandList(stringsOfAny(a.patch["command"]), a.name, mdir)
	env := h.mgr.envFor(a.name, a.mod, mdir, false)
	env = append(env, "ZEROCORE_EVENT_KIND="+stringOf(event["kind"]))
	timeout := 10
	if t, ok := asInt(a.patch["timeout_seconds"]); ok {
		timeout = t
	}
	raw, _ := json.Marshal(event)
	t0 := nowSec(h.clock)
	rc, out := h.run(argv, string(raw), mdir, env, time.Duration(timeout)*time.Second)
	ms := int64((nowSec(h.clock) - t0) * 1000)
	if len(out) > OutLimit {
		out = out[len(out)-OutLimit:]
	}
	rec := HookRecord{T: math.Round(t0*1000) / 1000, Module: a.name, Patch: stringOf(a.patch["id"]), RC: rc, MS: ms,
		Event: map[string]any{"kind": event["kind"], "level": event["level"], "text": event["text"]}, Out: out}
	key := a.name + "/" + rec.Patch
	h.mu.Lock()
	h.recent = append(h.recent, rec)
	if len(h.recent) > 200 {
		h.recent = h.recent[len(h.recent)-200:]
	}
	if rc == 0 {
		h.failures[key] = 0
	} else {
		h.failures[key]++
	}
	pause := h.failures[key] >= PauseAfterFailures
	if pause {
		h.paused[key] = true
	}
	n := h.failures[key]
	h.mu.Unlock()
	_, _ = h.mgr.Emit("hook.ran", map[string]any{"module": a.name, "patch": rec.Patch, "rc": rc, "kind": event["kind"]})
	if rc != 0 && pause {
		_, _ = h.mgr.Emit("hook.paused", map[string]any{"module": a.name, "patch": rec.Patch, "failures": n})
	}
	return rec
}

// Poll забирает новые события (без повторов) и обрабатывает их. Возвращает число обработанных событий.
func (h *HookRunner) Poll() int {
	h.mu.Lock()
	since := h.since - 2
	h.mu.Unlock()
	events := h.getEvents(since)
	var fresh []map[string]any
	h.mu.Lock()
	for _, e := range events {
		t := numOf(e["t"])
		key := fmt.Sprintf("%v|%v|%v|%v", e["t"], e["a"], e["b"], e["text"])
		if h.seen[key] || t < h.since-2 {
			continue
		}
		h.seen[key] = true
		fresh = append(fresh, e)
	}
	for _, e := range fresh {
		if t := numOf(e["t"]); t > h.since {
			h.since = t
		}
	}
	if len(h.seen) > 4000 {
		h.seen = map[string]bool{}
	}
	h.mu.Unlock()
	for _, e := range fresh {
		h.Handle(e)
	}
	return len(fresh)
}

func numOf(v any) float64 {
	f, _ := v.(float64)
	return f
}

// Status — для панели: активные реакции и последние запуски.
func (h *HookRunner) Status() map[string]any {
	type row = map[string]any
	var hooks []row
	h.mu.Lock()
	defer h.mu.Unlock()
	for _, a := range h.activeHooks() {
		id := stringOf(a.patch["id"])
		key := a.name + "/" + id
		cd := 60
		if c, ok := asInt(a.patch["cooldown_seconds"]); ok {
			cd = c
		}
		hooks = append(hooks, row{"module": a.name, "id": id, "on": stringOf(a.patch["on"]), "contains": a.patch["contains"],
			"cooldown_seconds": cd, "paused": h.paused[key], "failures": h.failures[key], "last_run": h.lastRun[key]})
	}
	recent := h.recent
	if len(recent) > 20 {
		recent = recent[len(recent)-20:]
	}
	return map[string]any{"hooks": hooks, "recent": recent, "skipped": h.Skipped}
}

// Resume снимает паузу реакции. Возвращает true, если она была на паузе.
func (h *HookRunner) Resume(module, patchID string) bool {
	h.mu.Lock()
	defer h.mu.Unlock()
	key := module + "/" + patchID
	was := h.paused[key]
	delete(h.paused, key)
	h.failures[key] = 0
	return was
}
