package manager

import (
	"archive/zip"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"zcgo/internal/kernel"
)

// makeModule создаёт папку модуля с манифестом и файлами.
func makeModule(t *testing.T, root string, manifest map[string]any, files map[string]string) string {
	t.Helper()
	name := manifest["name"].(string)
	dir := filepath.Join(root, name)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	if _, ok := manifest["api"]; !ok {
		manifest["api"] = "1"
	}
	if _, ok := manifest["version"]; !ok {
		manifest["version"] = "1.0.0"
	}
	if _, ok := manifest["kind"]; !ok {
		manifest["kind"] = "library"
	}
	raw, _ := json.Marshal(manifest)
	if err := os.WriteFile(filepath.Join(dir, "manifest.json"), raw, 0o644); err != nil {
		t.Fatal(err)
	}
	for rel, body := range files {
		p := filepath.Join(dir, rel)
		_ = os.MkdirAll(filepath.Dir(p), 0o755)
		if err := os.WriteFile(p, []byte(body), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	return dir
}

func newManager(t *testing.T) *Manager {
	t.Helper()
	home := filepath.Join(t.TempDir(), "home")
	m, err := New(home, t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { stopAll(m) })
	return m
}

func stopAll(m *Manager) {
	for _, n := range m.EnabledNames() {
		_, _ = m.Stop(n)
	}
	for _, n := range sortedKeys(m.installedMap()) {
		_, _ = m.Stop(n)
	}
}

func service(name, provides, requires string, cmd ...string) map[string]any {
	mf := map[string]any{"name": name, "kind": "service", "run": map[string]any{"command": cmd, "start_timeout": 5, "stop_timeout": 3}}
	if provides != "" {
		mf["provides"] = []string{provides}
	}
	if requires != "" {
		mf["requires"] = []string{requires}
	}
	return mf
}

func TestInstallIsDisabledAndCopied(t *testing.T) {
	m := newManager(t)
	dir := makeModule(t, t.TempDir(), map[string]any{"name": "demo_tools"}, map[string]string{"tools.py": "x"})
	mod, err := m.Install(dir)
	if err != nil || mod.Name != "demo_tools" {
		t.Fatalf("установка: %v", err)
	}
	st := m.installedMap()
	if st["demo_tools"] == nil || st["demo_tools"].Enabled {
		t.Fatalf("модуль должен появиться выключенным: %+v", st["demo_tools"])
	}
	if _, err := os.Stat(filepath.Join(m.ModuleDir("demo_tools", ""), "manifest.json")); err != nil {
		t.Errorf("файлы не скопированы: %v", err)
	}
}

func TestInstallFromZipAndZipSlipRejected(t *testing.T) {
	m := newManager(t)
	zipPath := filepath.Join(t.TempDir(), "mod.zip")
	f, _ := os.Create(zipPath)
	zw := zip.NewWriter(f)
	w, _ := zw.Create("zero_core/manifest.json")
	_, _ = w.Write([]byte(`{"api":"1","name":"zip_mod","version":"1.0.0","kind":"library"}`))
	w2, _ := zw.Create("zero_core/../../evil.txt")
	_, _ = w2.Write([]byte("x"))
	_ = zw.Close()
	_ = f.Close()
	if _, err := m.Install(zipPath); err == nil {
		t.Fatal("архив с выходом за пределы должен отклоняться")
	}
	if _, err := os.Stat(filepath.Join(m.Home, "modules", "zip_mod")); !os.IsNotExist(err) {
		t.Error("после отказа не должно остаться следов установки")
	}
}

func TestInvalidAndIncompleteModulesRefused(t *testing.T) {
	m := newManager(t)
	bad := makeModule(t, t.TempDir(), map[string]any{"name": "bad_mod", "kind": "service"}, nil)
	if _, err := m.Install(bad); err == nil {
		t.Error("service без command должен отклоняться")
	}
	missing := makeModule(t, t.TempDir(), map[string]any{"name": "miss_mod", "kind": "service",
		"run": map[string]any{"command": []string{"python3", "${module_dir}/absent.py"}}}, nil)
	if _, err := m.Install(missing); err == nil {
		t.Error("отсутствующий файл из command должен отклоняться")
	}
	if len(m.installedMap()) != 0 {
		t.Error("ни один из модулей не должен установиться")
	}
}

func TestEnableWithMissingDependencyChangesNothing(t *testing.T) {
	m := newManager(t)
	dep := makeModule(t, t.TempDir(), map[string]any{"name": "needs_mod", "requires": []string{"absent.cap"}}, nil)
	if _, err := m.Install(dep); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Enable("needs_mod"); !kernel.Is(err, kernel.KindDependency) {
		t.Fatalf("ожидали ошибку зависимости: %v", err)
	}
	if m.installedMap()["needs_mod"].Enabled {
		t.Error("модуль не должен включиться")
	}
}

func TestStartOrderAndCascadeStop(t *testing.T) {
	m := newManager(t)
	root := t.TempDir()
	base := makeModule(t, root, service("base_svc", "base.svc", "", "sleep", "30"), nil)
	client := makeModule(t, root, service("client_svc", "", "base.svc", "sleep", "30"), nil)
	for _, d := range []string{base, client} {
		if _, err := m.Install(d); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := m.Enable("base_svc"); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Enable("client_svc"); err != nil {
		t.Fatal(err)
	}
	if !m.IsRunning("base_svc", mustMod(t, m, "base_svc")) || !m.IsRunning("client_svc", mustMod(t, m, "client_svc")) {
		t.Fatal("оба сервиса должны работать")
	}
	if _, err := m.Disable("base_svc", false); !kernel.Is(err, kernel.KindDependency) {
		t.Fatalf("выключение без cascade должно отказывать: %v", err)
	}
	victims, err := m.Disable("base_svc", true)
	if err != nil || len(victims) != 2 {
		t.Fatalf("каскадное выключение: %v %v", victims, err)
	}
	if m.IsRunning("client_svc", mustMod(t, m, "client_svc")) {
		t.Error("зависимый сервис должен быть остановлен")
	}
}

func mustMod(t *testing.T, m *Manager, name string) *kernel.Manifest {
	t.Helper()
	mod, err := m.Manifest(name, "")
	if err != nil {
		t.Fatal(err)
	}
	return mod
}

func TestTwoModulesSameCapabilityConflict(t *testing.T) {
	m := newManager(t)
	root := t.TempDir()
	a := makeModule(t, root, map[string]any{"name": "cap_one", "provides": []string{"same.cap"}}, nil)
	b := makeModule(t, root, map[string]any{"name": "cap_two", "provides": []string{"same.cap"}}, nil)
	for _, d := range []string{a, b} {
		if _, err := m.Install(d); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := m.Enable("cap_one"); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Enable("cap_two"); !kernel.Is(err, kernel.KindConflict) {
		t.Fatalf("ожидали конфликт возможностей: %v", err)
	}
	if m.installedMap()["cap_two"].Enabled {
		t.Error("второй модуль не должен включиться")
	}
}

func TestUnknownConfigKeyRejectedAndRolledBack(t *testing.T) {
	m := newManager(t)
	dir := makeModule(t, t.TempDir(), map[string]any{"name": "cfg_mod", "config": map[string]any{"limit": 5}}, nil)
	if _, err := m.Install(dir); err != nil {
		t.Fatal(err)
	}
	if _, err := m.ConfigSet("cfg_mod", "limit", 7); err != nil {
		t.Fatalf("известный параметр: %v", err)
	}
	if _, err := m.ConfigSet("cfg_mod", "bogus", 1); err == nil {
		t.Fatal("неизвестный параметр должен отклоняться")
	}
	cfg, _ := m.Config("cfg_mod", "")
	if _, has := cfg["bogus"]; has || cfg["limit"].(float64) != 7 {
		t.Errorf("после отказа конфигурация должна остаться прежней: %v", cfg)
	}
}

func TestUninstallDataPolicy(t *testing.T) {
	m := newManager(t)
	keep := makeModule(t, t.TempDir(), map[string]any{"name": "keep_data"}, nil)
	del := makeModule(t, t.TempDir(), map[string]any{"name": "del_data", "data_policy": "delete"}, nil)
	for _, d := range []string{keep, del} {
		if _, err := m.Install(d); err != nil {
			t.Fatal(err)
		}
		_ = os.WriteFile(filepath.Join(m.Home, "data", filepath.Base(d), "f.txt"), []byte("x"), 0o644)
	}
	if purged, err := m.Uninstall("keep_data", nil, false, false); err != nil || purged {
		t.Fatalf("keep: %v %v", purged, err)
	}
	if _, err := os.Stat(filepath.Join(m.Home, "data", "keep_data")); err != nil {
		t.Error("данные по политике keep должны остаться")
	}
	if purged, err := m.Uninstall("del_data", nil, false, false); err != nil || !purged {
		t.Fatalf("delete: %v %v", purged, err)
	}
	if _, err := os.Stat(filepath.Join(m.Home, "data", "del_data")); !os.IsNotExist(err) {
		t.Error("данные по политике delete должны уйти")
	}
}

func TestInterruptedUninstallRollsBack(t *testing.T) {
	m := newManager(t)
	dir := makeModule(t, t.TempDir(), map[string]any{"name": "half_gone"}, nil)
	if _, err := m.Install(dir); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Uninstall("half_gone", nil, false, true); err == nil {
		t.Fatal("операция должна прерваться")
	}
	if _, ok := m.installedMap()["half_gone"]; !ok {
		t.Error("после прерывания модуль должен остаться установленным")
	}
	if _, err := os.Stat(filepath.Join(m.ModuleDir("half_gone", ""), "manifest.json")); err != nil {
		t.Errorf("код модуля должен вернуться: %v", err)
	}
}

func TestSwapAndRollbackLibrary(t *testing.T) {
	m := newManager(t)
	root := t.TempDir()
	v1 := makeModule(t, root, map[string]any{"name": "swap_mod", "version": "1.0.0"}, map[string]string{"v.txt": "one"})
	v2 := makeModule(t, root+"/v2", map[string]any{"name": "swap_mod", "version": "2.0.0"}, map[string]string{"v.txt": "two"})
	for _, d := range []string{v1, v2} {
		if _, err := m.Install(d); err != nil {
			t.Fatal(err)
		}
	}
	if _, _, err := m.Swap("swap_mod", "2.0.0"); err != nil {
		t.Fatalf("swap: %v", err)
	}
	raw, _ := os.ReadFile(filepath.Join(m.ModuleDir("swap_mod", ""), "v.txt"))
	if string(raw) != "two" {
		t.Errorf("после замены активна не та версия: %q", raw)
	}
	if _, _, err := m.Rollback("swap_mod"); err != nil {
		t.Fatalf("rollback: %v", err)
	}
	raw, _ = os.ReadFile(filepath.Join(m.ModuleDir("swap_mod", ""), "v.txt"))
	if string(raw) != "one" {
		t.Errorf("откат не вернул версию: %q", raw)
	}
}

func TestNewVersionFailsToStartOldKeepsWorking(t *testing.T) {
	m := newManager(t)
	root := t.TempDir()
	good := makeModule(t, root, service("swap_svc", "", "", "sleep", "30"), nil)
	if _, err := m.Install(good); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Enable("swap_svc"); err != nil {
		t.Fatal(err)
	}
	bad := makeModule(t, root+"/bad", map[string]any{"name": "swap_svc", "version": "2.0.0", "kind": "service",
		"run": map[string]any{"command": []string{"false"}, "start_timeout": 2}}, nil)
	if _, err := m.Install(bad); err != nil {
		t.Fatal(err)
	}
	if _, _, err := m.Swap("swap_svc", "2.0.0"); !kernel.Is(err, kernel.KindLifecycle) {
		t.Fatalf("новая версия не должна запуститься: %v", err)
	}
	if m.installedMap()["swap_svc"].Version != "1.0.0" {
		t.Error("активной должна остаться старая версия")
	}
	if _, ok := m.Runner.Pid("swap_svc", ""); !ok {
		t.Error("старая версия должна продолжать работать")
	}
}

func TestTrustLifecycle(t *testing.T) {
	home := t.TempDir()
	dir := makeModule(t, t.TempDir(), map[string]any{"name": "trust_mod"}, map[string]string{"a.md": "text"})
	st, _ := Verify(home, dir)
	if st.State != "unsigned" {
		t.Fatalf("без подписи: %s", st.State)
	}
	if _, err := Sign(home, dir); err != nil {
		t.Fatal(err)
	}
	if st, _ := Verify(home, dir); st.State != "trusted" {
		t.Fatalf("после подписи: %s", st.State)
	}
	_ = os.WriteFile(filepath.Join(dir, "a.md"), []byte("changed"), 0o644)
	if st, _ := Verify(home, dir); st.State != "modified" {
		t.Errorf("после правки: %s", st.State)
	}
	_ = os.WriteFile(filepath.Join(dir, "a.md"), []byte("text"), 0o644)
	if st, _ := Verify(home, dir); st.State != "trusted" {
		t.Errorf("возврат содержимого должен снова доверять: %s", st.State)
	}
	// другой ключ владельца — foreign
	_ = os.WriteFile(filepath.Join(home, "keys", "owner.key"), []byte(strings.Repeat("ab", 32)), 0o600)
	if st, _ := Verify(home, dir); st.State != "foreign" {
		t.Errorf("чужой ключ: %s", st.State)
	}
}

func TestApprovalIsBoundToContent(t *testing.T) {
	home := t.TempDir()
	dir := makeModule(t, t.TempDir(), map[string]any{"name": "appr_mod"}, map[string]string{"a.md": "x"})
	if err := Approve(home, "appr_mod", dir, "1.0.0"); err != nil {
		t.Fatal(err)
	}
	if st, _ := Status(home, "appr_mod", dir); !st.Allowed {
		t.Fatal("одобренная деталь должна быть разрешена")
	}
	_ = os.WriteFile(filepath.Join(dir, "a.md"), []byte("y"), 0o644)
	if st, _ := Status(home, "appr_mod", dir); st.Allowed {
		t.Error("после изменения содержимого одобрение не действует")
	}
	if ok, _ := Revoke(home, "appr_mod"); !ok {
		t.Error("одобрение должно сниматься")
	}
}

// setupBot создаёт каталог бота с промптами и модуль kuni, указывающий на него.
func setupBot(t *testing.T, m *Manager) string {
	t.Helper()
	bot := t.TempDir()
	prompts := filepath.Join(bot, "prompts")
	_ = os.MkdirAll(prompts, 0o755)
	_ = os.WriteFile(filepath.Join(prompts, "system.md"), []byte("Базовый промпт.\n"), 0o644)
	kuni := makeModule(t, t.TempDir(), map[string]any{"name": "kuni", "config": map[string]any{"kuni_dir": ""}}, nil)
	if _, err := m.Install(kuni); err != nil {
		t.Fatal(err)
	}
	if _, err := m.ConfigSet("kuni", "kuni_dir", bot); err != nil {
		t.Fatal(err)
	}
	return prompts
}

func patchModule(name string) (map[string]any, map[string]string) {
	mf := map[string]any{"name": name, "patches": []any{map[string]any{"key": "prompt.append", "id": "addon", "target": "system.md", "file": "addon.md"}}}
	return mf, map[string]string{"addon.md": "Дополнительное правило."}
}

func TestPatchAppliesOnlyWhenTrustedAndRestoresBytes(t *testing.T) {
	m := newManager(t)
	prompts := setupBot(t, m)
	original, _ := os.ReadFile(filepath.Join(prompts, "system.md"))
	mf, files := patchModule("patch_mod")
	dir := makeModule(t, t.TempDir(), mf, files)
	if _, err := m.Install(dir); err != nil {
		t.Fatal(err)
	}
	// без подписи: ждём доверия, файл не меняется
	if _, err := m.Enable("patch_mod"); err != nil {
		t.Fatal(err)
	}
	if raw, _ := os.ReadFile(filepath.Join(prompts, "system.md")); string(raw) != string(original) {
		t.Fatal("недоверенная деталь не должна менять промпты")
	}
	// подпись: блок появляется
	if _, err := Sign(m.Home, m.ModuleDir("patch_mod", "")); err != nil {
		t.Fatal(err)
	}
	m.RefreshExtensions()
	raw, _ := os.ReadFile(filepath.Join(prompts, "system.md"))
	if !strings.Contains(string(raw), "Дополнительное правило.") {
		t.Fatalf("добавка не появилась: %q", raw)
	}
	// повторное применение не дублирует
	m.RefreshExtensions()
	raw2, _ := os.ReadFile(filepath.Join(prompts, "system.md"))
	if string(raw2) != string(raw) {
		t.Error("повторное применение не должно менять файл")
	}
	// выключение: файл побайтно исходный
	if _, err := m.Disable("patch_mod", false); err != nil {
		t.Fatal(err)
	}
	restored, _ := os.ReadFile(filepath.Join(prompts, "system.md"))
	if string(restored) != string(original) {
		t.Errorf("после выключения файл должен быть побайтно исходным: %q", restored)
	}
}

func TestChangedAfterSigningLosesPatch(t *testing.T) {
	m := newManager(t)
	prompts := setupBot(t, m)
	mf, files := patchModule("drift_mod")
	dir := makeModule(t, t.TempDir(), mf, files)
	if _, err := m.Install(dir); err != nil {
		t.Fatal(err)
	}
	mdir := m.ModuleDir("drift_mod", "")
	if _, err := Sign(m.Home, mdir); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Enable("drift_mod"); err != nil {
		t.Fatal(err)
	}
	_ = os.WriteFile(filepath.Join(mdir, "addon.md"), []byte("подменено"), 0o644)
	m.RefreshExtensions()
	raw, _ := os.ReadFile(filepath.Join(prompts, "system.md"))
	if strings.Contains(string(raw), "подменено") || strings.Contains(string(raw), "zerocore:begin") {
		t.Errorf("изменённая после подписи добавка не должна действовать: %q", raw)
	}
}

func TestHookRunsOncePerEventAndRespectsCooldownAndPause(t *testing.T) {
	m := newManager(t)
	mf := map[string]any{"name": "hook_mod", "patches": []any{map[string]any{"key": "hook.event", "id": "react", "on": "message",
		"contains": "привет", "command": []string{"true"}, "cooldown_seconds": 5, "timeout_seconds": 3}}}
	dir := makeModule(t, t.TempDir(), mf, nil)
	if _, err := m.Install(dir); err != nil {
		t.Fatal(err)
	}
	if _, err := Sign(m.Home, m.ModuleDir("hook_mod", "")); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Enable("hook_mod"); err != nil {
		t.Fatal(err)
	}
	now := time.Unix(1_700_000_000, 0)
	clock := func() time.Time { return now }
	var calls int
	rc := 0
	run := func(argv []string, stdin, cwd string, env []string, timeout time.Duration) (int, string) {
		calls++
		return rc, ""
	}
	feed := []map[string]any{}
	get := func(since float64) []map[string]any { return feed }
	h := NewHookRunner(m, get, run, clock)

	feed = []map[string]any{{"t": float64(now.Unix()) + 1.0, "kind": "message", "level": "info", "text": "Привет, Марин"}}
	if n := h.Poll(); n != 1 || calls != 1 {
		t.Fatalf("событие должно запустить реакцию один раз: n=%d calls=%d", n, calls)
	}
	// то же событие не обрабатывается повторно
	if h.Poll(); calls != 1 {
		t.Errorf("повтор события не должен запускать реакцию: %d", calls)
	}
	// в пределах cooldown — пропуск
	now = now.Add(2 * time.Second)
	feed = []map[string]any{{"t": float64(now.Unix()) + 1.0, "kind": "message", "level": "info", "text": "привет ещё"}}
	h.Poll()
	if calls != 1 || h.Skipped["cooldown"] != 1 {
		t.Errorf("cooldown: calls=%d skipped=%v", calls, h.Skipped)
	}
	// не подходит по тексту и виду — не запускается
	now = now.Add(10 * time.Second)
	feed = []map[string]any{{"t": float64(now.Unix()) + 1.0, "kind": "llm", "level": "info", "text": "привет"}}
	h.Poll()
	if calls != 1 {
		t.Errorf("не то событие не должно запускать реакцию: %d", calls)
	}
	// пять сбоев подряд ставят реакцию на паузу
	rc = 1
	for i := 0; i < kernelPause(); i++ {
		now = now.Add(10 * time.Second)
		feed = []map[string]any{{"t": float64(now.Unix()) + 1.0, "kind": "message", "level": "info", "text": "привет"}}
		h.Poll()
	}
	paused := h.Status()["hooks"].([]map[string]any)[0]["paused"].(bool)
	if !paused {
		t.Error("после серии сбоев реакция должна стать на паузу")
	}
}

func kernelPause() int { return PauseAfterFailures }

func TestJobRunsWhenDueAndRecordsFailure(t *testing.T) {
	m := newManager(t)
	mf := map[string]any{"name": "job_mod", "kind": "job", "health": map[string]any{"type": "job"}, "run": map[string]any{"command": []string{"false"}, "schedule_seconds": 10}}
	dir := makeModule(t, t.TempDir(), mf, nil)
	if _, err := m.Install(dir); err != nil {
		t.Fatal(err)
	}
	if _, err := m.Enable("job_mod"); err != nil {
		t.Fatal(err)
	}
	actions := m.Tick(time.Now())
	found := false
	for _, a := range actions {
		if strings.Contains(a, "job_mod: задача выполнена, код 1") {
			found = true
		}
	}
	if !found {
		t.Fatalf("задача должна выполниться с кодом 1: %v", actions)
	}
	h, _ := m.Health("job_mod")
	if h.State != "unhealthy" {
		t.Errorf("после сбоя задачи здоровье должно быть unhealthy: %+v", h)
	}
}

func TestToolsExportSkipsDuplicateNames(t *testing.T) {
	m := newManager(t)
	tool := func(name, tname string) map[string]any {
		return map[string]any{"name": name, "tools": []any{map[string]any{"name": tname, "description": "d", "parameters": map[string]any{}, "command": []string{"true"}}}}
	}
	for _, mf := range []map[string]any{tool("tool_one", "same_tool"), tool("tool_two", "same_tool")} {
		dir := makeModule(t, t.TempDir(), mf, nil)
		if _, err := m.Install(dir); err != nil {
			t.Fatal(err)
		}
		if _, err := m.Enable(mf["name"].(string)); err != nil {
			t.Fatal(err)
		}
	}
	cat, err := m.ExportTools()
	if err != nil {
		t.Fatal(err)
	}
	if len(cat.Tools) != 1 || len(cat.Errors) != 1 {
		t.Fatalf("одно имя должно попасть в каталог, второе — в ошибки: %d %v", len(cat.Tools), cat.Errors)
	}
	raw, _ := os.ReadFile(m.ToolsPath())
	var doc map[string]any
	if json.Unmarshal(raw, &doc) != nil || doc["version"].(float64) != 1 {
		t.Errorf("tools.json должен быть версии 1: %s", raw)
	}
}

func TestSecretsReachOnlyTheirModule(t *testing.T) {
	m := newManager(t)
	if _, err := SetSecret(m.Home, "news_mod", "NEWS_KEY", "абв"); err != nil {
		t.Fatal(err)
	}
	if _, err := SetSecret(m.Home, "news_mod", "bad_name", "x"); err == nil {
		t.Fatal("имя секрета должно быть заглавными")
	}
	mod := &kernel.Manifest{Name: "news_mod"}
	env := m.envFor("news_mod", mod, t.TempDir(), false)
	other := m.envFor("other_mod", mod, t.TempDir(), false)
	has := func(list []string, kv string) bool {
		for _, x := range list {
			if x == kv {
				return true
			}
		}
		return false
	}
	if !has(env, "ZEROCORE_SECRET_NEWS_KEY=абв") {
		t.Error("секрет должен попасть в окружение своей детали")
	}
	if has(other, "ZEROCORE_SECRET_NEWS_KEY=абв") {
		t.Error("секрет не должен попадать в чужую деталь")
	}
	names := SecretNames(m.Home, "news_mod")
	if len(names) != 1 || names[0] != "NEWS_KEY" {
		t.Errorf("наружу уходят только имена: %v", names)
	}
}
