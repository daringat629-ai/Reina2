// Секреты деталей (порт part_secrets.py): каждый секрет достаётся только той детали, для которой внесён.
// Хранение: home/secrets/<деталь>.json (каталог 0700, файл 0600). Наружу уходят только имена.
package manager

import (
	"encoding/json"
	"os"
	"path/filepath"
	"regexp"
	"sort"

	"zcgo/internal/kernel"
)

const secretPrefix = "ZEROCORE_SECRET_"

var (
	secretNameRE = regexp.MustCompile(`^[A-Z][A-Z0-9_]{1,40}$`)
	secretModRE  = regexp.MustCompile(`^[a-z][a-z0-9_]{2,40}$`)
)

func secretFile(home, module string) string {
	return filepath.Join(home, "secrets", module+".json")
}

func loadSecrets(home, module string) map[string]string {
	out := map[string]string{}
	if raw, err := os.ReadFile(secretFile(home, module)); err == nil {
		_ = json.Unmarshal(raw, &out)
	}
	return out
}

// SecretNames — имена секретов детали (значения не возвращаются).
func SecretNames(home, module string) []string {
	m := loadSecrets(home, module)
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

// SetSecret сохраняет секрет. Пустое значение удаляет его.
func SetSecret(home, module, name, value string) ([]string, error) {
	if !secretNameRE.MatchString(name) {
		return nil, kernel.Newf(kernel.KindGeneric, "имя секрета: заглавные латинские буквы, цифры и _, например NEWS_KEY")
	}
	if !secretModRE.MatchString(module) {
		return nil, kernel.Newf(kernel.KindGeneric, "имя детали указано неверно")
	}
	data := loadSecrets(home, module)
	if value == "" {
		delete(data, name)
	} else {
		if len([]rune(value)) > 4000 || containsNewlineOrNul(value) {
			return nil, kernel.Newf(kernel.KindGeneric, "значение секрета: одна строка до 4000 символов")
		}
		data[name] = value
	}
	dir := filepath.Join(home, "secrets")
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return nil, err
	}
	_ = os.Chmod(dir, 0o700)
	raw, err := json.Marshal(data)
	if err != nil {
		return nil, err
	}
	if err := writePrivate(secretFile(home, module), raw); err != nil {
		return nil, err
	}
	return SecretNames(home, module), nil
}

func containsNewlineOrNul(s string) bool {
	for _, r := range s {
		if r == '\n' || r == 0 {
			return true
		}
	}
	return false
}

// secretEnv — переменные ZEROCORE_SECRET_<ИМЯ> одной детали.
func secretEnv(home, module string) map[string]string {
	out := map[string]string{}
	for k, v := range loadSecrets(home, module) {
		out[secretPrefix+k] = v
	}
	return out
}
