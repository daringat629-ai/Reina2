// Ключи доверия: подпись деталей ключом владельца и одобрения. Порт module_manager/trust.py.
//
// Деталь с «ключами» расширения (патчи, реакции) действует только если она:
//   - подписана ключом владельца этой машины (signature.json, HMAC-SHA256 по содержимому, ключ keys/owner.key 0600), или
//   - одобрена владельцем здесь (trust/approvals.json, привязано к отпечатку содержимого).
//
// Состояния подписи: trusted, unsigned, modified, foreign.
package manager

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

const (
	sigFile = "signature.json"
	domain  = "zerocore-signature-v1\x00"
)

func writePrivate(path string, data []byte) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	tmp := path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, 0o600)
	if err != nil {
		return err
	}
	if _, err := f.Write(data); err != nil {
		f.Close()
		return err
	}
	if err := f.Close(); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// OwnerKey читает ключ владельца; при create=true создаёт его при первом обращении.
func OwnerKey(home string, create bool) ([]byte, error) {
	path := filepath.Join(home, "keys", "owner.key")
	if raw, err := os.ReadFile(path); err == nil {
		if key, err := hex.DecodeString(strings.TrimSpace(string(raw))); err == nil {
			return key, nil
		}
	}
	if !create {
		return nil, nil
	}
	key := make([]byte, 32)
	if _, err := rand.Read(key); err != nil {
		return nil, err
	}
	if err := writePrivate(path, []byte(hex.EncodeToString(key))); err != nil {
		return nil, err
	}
	return key, nil
}

// KeyID — короткий идентификатор ключа (не сам ключ).
func KeyID(key []byte) string {
	h := sha256.Sum256(append([]byte("zerocore-key-id\x00"), key...))
	return hex.EncodeToString(h[:])[:12]
}

// FileHashes — отпечатки всех файлов детали (кроме подписи и кэша). Симлинк учитывается как ссылка.
func FileHashes(moduleDir string) (map[string]string, error) {
	out := map[string]string{}
	err := filepath.WalkDir(moduleDir, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, _ := filepath.Rel(moduleDir, p)
		rel = filepath.ToSlash(rel)
		if rel == "." {
			return nil
		}
		if rel == sigFile || strings.Contains("/"+rel+"/", "/__pycache__/") || strings.HasSuffix(rel, ".pyc") {
			if d.IsDir() && strings.Contains("/"+rel+"/", "/__pycache__/") {
				return filepath.SkipDir
			}
			return nil
		}
		if d.Type()&fs.ModeSymlink != 0 {
			target, err := os.Readlink(p)
			if err != nil {
				return err
			}
			out[rel] = "symlink:" + target
			return nil
		}
		if d.Type().IsRegular() {
			raw, err := os.ReadFile(p)
			if err != nil {
				return err
			}
			sum := sha256.Sum256(raw)
			out[rel] = hex.EncodeToString(sum[:])
		}
		return nil
	})
	return out, err
}

// ContentHash — общий отпечаток всех файлов.
func ContentHash(files map[string]string) string {
	keys := make([]string, 0, len(files))
	for k := range files {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	h := sha256.New()
	for _, rel := range keys {
		h.Write([]byte(rel + "\x00" + files[rel] + "\n"))
	}
	return hex.EncodeToString(h.Sum(nil))
}

func mac(key []byte, content string) string {
	m := hmac.New(sha256.New, key)
	m.Write([]byte(domain + content))
	return hex.EncodeToString(m.Sum(nil))
}

// Signature — содержимое signature.json.
type Signature struct {
	Alg      string `json:"alg"`
	KeyID    string `json:"key_id"`
	Content  string `json:"content"`
	Files    int    `json:"files"`
	SignedAt int64  `json:"signed_at"`
	Sig      string `json:"sig"`
}

// Sign подписывает деталь ключом владельца.
func Sign(home, moduleDir string) (Signature, error) {
	key, err := OwnerKey(home, true)
	if err != nil {
		return Signature{}, err
	}
	files, err := FileHashes(moduleDir)
	if err != nil {
		return Signature{}, err
	}
	ch := ContentHash(files)
	doc := Signature{Alg: "hmac-sha256", KeyID: KeyID(key), Content: ch, Files: len(files), SignedAt: time.Now().Unix(), Sig: mac(key, ch)}
	raw, _ := json.MarshalIndent(doc, "", " ")
	if err := os.WriteFile(filepath.Join(moduleDir, sigFile), append(raw, '\n'), 0o644); err != nil {
		return Signature{}, err
	}
	return doc, nil
}

// TrustState — итог проверки доверия детали.
type TrustState struct {
	State    string `json:"state"`
	Reason   string `json:"reason"`
	Content  string `json:"content"`
	Files    int    `json:"files"`
	KeyID    string `json:"key_id,omitempty"`
	Approved bool   `json:"approved"`
	Allowed  bool   `json:"allowed"`
}

// Verify сверяет подпись с текущим содержимым.
func Verify(home, moduleDir string) (TrustState, error) {
	files, err := FileHashes(moduleDir)
	if err != nil {
		return TrustState{}, err
	}
	ch := ContentHash(files)
	base := TrustState{Content: ch, Files: len(files)}
	raw, err := os.ReadFile(filepath.Join(moduleDir, sigFile))
	if os.IsNotExist(err) {
		base.State, base.Reason = "unsigned", "подписи нет"
		return base, nil
	}
	var doc Signature
	if err != nil || json.Unmarshal(raw, &doc) != nil {
		base.State, base.Reason = "modified", "файл подписи повреждён"
		return base, nil
	}
	key, _ := OwnerKey(home, false)
	if key == nil || doc.KeyID != KeyID(key) {
		base.State, base.KeyID, base.Reason = "foreign", doc.KeyID, "подписано другим ключом (не вашим)"
		return base, nil
	}
	if !hmac.Equal([]byte(doc.Sig), []byte(mac(key, ch))) {
		base.State, base.KeyID, base.Reason = "modified", doc.KeyID, "содержимое изменено после подписи"
		return base, nil
	}
	base.State, base.KeyID, base.Reason = "trusted", doc.KeyID, "подписано вашим ключом"
	return base, nil
}

type approval struct {
	Content string `json:"content"`
	Version string `json:"version"`
	TS      int64  `json:"ts"`
}

func approvalsPath(home string) string { return filepath.Join(home, "trust", "approvals.json") }

func loadApprovals(home string) map[string]approval {
	out := map[string]approval{}
	if raw, err := os.ReadFile(approvalsPath(home)); err == nil {
		_ = json.Unmarshal(raw, &out)
	}
	return out
}

func saveApprovals(home string, data map[string]approval) error {
	raw, err := json.MarshalIndent(data, "", " ")
	if err != nil {
		return err
	}
	return writePrivate(approvalsPath(home), raw)
}

// Approve одобряет деталь здесь и сейчас (привязано к текущему содержимому).
func Approve(home, name, moduleDir, version string) error {
	files, err := FileHashes(moduleDir)
	if err != nil {
		return err
	}
	data := loadApprovals(home)
	data[name] = approval{Content: ContentHash(files), Version: version, TS: time.Now().Unix()}
	return saveApprovals(home, data)
}

// Revoke снимает одобрение.
func Revoke(home, name string) (bool, error) {
	data := loadApprovals(home)
	if _, ok := data[name]; !ok {
		return false, nil
	}
	delete(data, name)
	return true, saveApprovals(home, data)
}

// Status — можно ли применять ключи детали (подписана вами или одобрена вами для этого содержимого).
func Status(home, name, moduleDir string) (TrustState, error) {
	v, err := Verify(home, moduleDir)
	if err != nil {
		return v, err
	}
	ap, has := loadApprovals(home)[name]
	v.Approved = has && ap.Content == v.Content
	v.Allowed = v.State == "trusted" || v.Approved
	return v, nil
}
