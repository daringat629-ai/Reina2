// Решатель зависимостей: версии, отсутствующие провайдеры, конфликты, циклы; порядок запуска. Порт dependency_solver.py.
package manager

import (
	"sort"
	"strings"

	"zcgo/internal/kernel"
)

type edgeSet map[string]map[string]bool

func buildEdges(manifests map[string]*kernel.Manifest, reg *kernel.Registry) (edgeSet, []string) {
	edges := edgeSet{}
	for n := range manifests {
		edges[n] = map[string]bool{}
	}
	var problems []string
	names := sortedKeys(manifests)
	for _, n := range names {
		m := manifests[n]
		for _, cap := range m.Requires {
			p := reg.Provider(cap)
			switch {
			case p == "":
				problems = append(problems, n+": нет модуля, предоставляющего "+cap)
			case p != n:
				edges[n][p] = true
			}
		}
		depNames := make([]string, 0, len(m.Depends))
		for d := range m.Depends {
			depNames = append(depNames, d)
		}
		sort.Strings(depNames)
		for _, dep := range depNames {
			cons := m.Depends[dep]
			d, ok := manifests[dep]
			if !ok {
				problems = append(problems, n+": требуется модуль "+dep+" "+cons+", но он не включён")
				continue
			}
			good, err := kernel.Satisfies(d.Version, cons)
			if err != nil || !good {
				problems = append(problems, n+": нужен "+dep+" "+cons+", а включена версия "+d.Version)
				continue
			}
			edges[n][dep] = true
		}
	}
	return edges, problems
}

func buildSoftEdges(manifests map[string]*kernel.Manifest, reg *kernel.Registry) edgeSet {
	soft := edgeSet{}
	for n := range manifests {
		soft[n] = map[string]bool{}
	}
	for _, n := range sortedKeys(manifests) {
		for _, cap := range manifests[n].OptionalRequires {
			p := reg.Provider(cap)
			if p != "" && p != n {
				soft[n][p] = true
			}
		}
	}
	return soft
}

// Solve возвращает порядок запуска (зависимости раньше) или ошибку.
func Solve(manifests map[string]*kernel.Manifest) ([]string, error) {
	reg, err := kernel.NewRegistry(manifests)
	if err != nil {
		return nil, err
	}
	for _, n := range sortedKeys(manifests) {
		for _, c := range manifests[n].Conflicts {
			if _, ok := manifests[c]; ok {
				return nil, kernel.Newf(kernel.KindConflict, "%s конфликтует с %s", n, c)
			}
		}
	}
	edges, problems := buildEdges(manifests, reg)
	if len(problems) > 0 {
		return nil, kernel.Newf(kernel.KindDependency, "%s", strings.Join(problems, "; "))
	}
	soft := buildSoftEdges(manifests, reg)
	left := map[string]map[string]bool{}
	softLeft := map[string]map[string]bool{}
	for n, d := range edges {
		left[n] = copySet(d)
		softLeft[n] = copySet(soft[n])
	}
	var order []string
	for len(left) > 0 {
		ready := readyNodes(left, softLeft, true)
		if len(ready) == 0 {
			ready = readyNodes(left, softLeft, false)
		}
		if len(ready) == 0 {
			names := make([]string, 0, len(left))
			for n := range left {
				names = append(names, n)
			}
			sort.Strings(names)
			return nil, kernel.Newf(kernel.KindDependency, "циклическая зависимость между модулями: %s", strings.Join(names, ", "))
		}
		for _, n := range ready {
			order = append(order, n)
			delete(left, n)
			delete(softLeft, n)
		}
		for _, d := range left {
			for _, r := range ready {
				delete(d, r)
			}
		}
		for _, d := range softLeft {
			for _, r := range ready {
				delete(d, r)
			}
		}
	}
	return order, nil
}

// readyNodes: узлы без зависимостей (и без мягких, если strict).
func readyNodes(left, softLeft map[string]map[string]bool, strict bool) []string {
	var out []string
	for n, d := range left {
		if len(d) != 0 {
			continue
		}
		if strict && len(softLeft[n]) != 0 {
			continue
		}
		out = append(out, n)
	}
	sort.Strings(out)
	return out
}

func copySet(s map[string]bool) map[string]bool {
	out := make(map[string]bool, len(s))
	for k := range s {
		out[k] = true
	}
	return out
}

// Dependents — все включённые модули, которые прямо или косвенно зависят от name.
func Dependents(name string, manifests map[string]*kernel.Manifest) map[string]bool {
	reg, err := kernel.NewRegistry(manifests)
	if err != nil {
		return map[string]bool{}
	}
	edges, _ := buildEdges(manifests, reg)
	result := map[string]bool{}
	frontier := map[string]bool{name: true}
	for len(frontier) > 0 {
		next := map[string]bool{}
		for n, deps := range edges {
			if result[n] || n == name {
				continue
			}
			for f := range frontier {
				if deps[f] {
					next[n] = true
					break
				}
			}
		}
		for n := range next {
			result[n] = true
		}
		frontier = next
	}
	return result
}

func sortedKeys[V any](m map[string]V) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
