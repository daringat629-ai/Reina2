// Патчи деталей («ключи»): добавки к промптам бота и реакции на события. Порт module_manager/patches.py.
//
// prompt.append: текст из файла детали вставляется в файл промпта бота внутри ОБРАТИМОГО блока с маркерами
//
//	<!-- zerocore:begin module=<деталь> patch=<id> --> ... <!-- zerocore:end module=<деталь> patch=<id> -->
//
// Блок убирается без следа: после снятия файл побайтно равен исходному.
// hook.event: реакция на событие; её исполняет HookRunner (hooks.go).
package manager

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"zcgo/internal/kernel"
)

const maxBlocksBytes = 16 * 1024

var beginRE = regexp.MustCompile(`<!-- zerocore:begin module=([a-z][a-z0-9_]*) patch=([a-z][a-z0-9_]*) -->\n`)

// span — один блок в тексте: [Start, End) вместе с переводом строки перед маркером (если был) и после закрытия.
type span struct {
	Start, End int
	Module, ID string
}

func beginLine(module, pid string) string {
	return fmt.Sprintf("<!-- zerocore:begin module=%s patch=%s -->", module, pid)
}

func endLine(module, pid string) string {
	return fmt.Sprintf("<!-- zerocore:end module=%s patch=%s -->", module, pid)
}

// findSpans находит все блоки. Закрывающий маркер ищется того же модуля и патча (как обратная ссылка в Python-регулярке).
func findSpans(text string) []span {
	var out []span
	pos := 0
	for pos < len(text) {
		loc := beginRE.FindStringSubmatchIndex(text[pos:])
		if loc == nil {
			break
		}
		start := pos + loc[0]
		bodyStart := pos + loc[1]
		module := text[pos+loc[2] : pos+loc[3]]
		pid := text[pos+loc[4] : pos+loc[5]]
		closing := "\n" + endLine(module, pid) + "\n"
		idx := strings.Index(text[bodyStart-1:], closing)
		if idx < 0 {
			pos = bodyStart
			continue
		}
		end := bodyStart - 1 + idx + len(closing)
		if start > 0 && text[start-1] == '\n' {
			start--
		}
		out = append(out, span{Start: start, End: end, Module: module, ID: pid})
		pos = end
	}
	return out
}

// removeBlocks убирает блоки детали (или все, если module пуст), кроме перечисленных в keep.
func removeBlocks(text, module string, keep map[[2]string]bool) string {
	var b strings.Builder
	last := 0
	for _, s := range findSpans(text) {
		if (module == "" || s.Module == module) && !keep[[2]string{s.Module, s.ID}] {
			b.WriteString(text[last:s.Start])
			last = s.End
		}
	}
	b.WriteString(text[last:])
	return b.String()
}

func chunkFor(module, pid, body, position string) string {
	block := beginLine(module, pid) + "\n" + strings.Trim(body, "\n") + "\n" + endLine(module, pid) + "\n"
	if position == "start" {
		return block
	}
	return "\n" + block
}

// putBlock ставит блок (заменяет прежний, не дублирует); блоки других деталей не трогает.
func putBlock(text, module, pid, body, position string) string {
	keep := map[[2]string]bool{}
	for _, s := range findSpans(text) {
		if !(s.Module == module && s.ID == pid) {
			keep[[2]string{s.Module, s.ID}] = true
		}
	}
	clean := removeBlocks(text, module, keep)
	chunk := chunkFor(module, pid, body, position)
	if position == "start" {
		return chunk + clean
	}
	return clean + chunk
}

func blocksSize(text string) int {
	n := 0
	for _, s := range findSpans(text) {
		n += len(text[s.Start:s.End])
	}
	return n
}

func writeAtomicKeepMode(path, text string) error {
	tmp := filepath.Join(filepath.Dir(path), "."+filepath.Base(path)+".zc.tmp")
	if err := os.WriteFile(tmp, []byte(text), 0o644); err != nil {
		return err
	}
	if st, err := os.Stat(path); err == nil {
		_ = os.Chmod(tmp, st.Mode().Perm())
	}
	return os.Rename(tmp, path)
}

// BotPromptsDir — каталог промптов бота (kuni_dir/prompts), если он есть.
func (m *Manager) BotPromptsDir() string {
	cfg, err := m.Config("kuni", "")
	if err != nil {
		return ""
	}
	base, _ := cfg["kuni_dir"].(string)
	if base == "" {
		return ""
	}
	d := filepath.Join(base, "prompts")
	if st, err := os.Stat(d); err == nil && st.IsDir() {
		return d
	}
	return ""
}

func targetFile(prompts, name string) (string, error) {
	if !inStrings(name, kernel.PromptTargets) {
		return "", kernel.Newf(kernel.KindGeneric, "%s: не файл промпта бота", name)
	}
	t := filepath.Join(prompts, name)
	st, err := os.Lstat(t)
	if err != nil || !st.Mode().IsRegular() {
		return "", kernel.Newf(kernel.KindGeneric, "файла %s нет в каталоге промптов бота", name)
	}
	return t, nil
}

func inStrings(v string, list []string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

func (m *Manager) backupOnce(target string) error {
	orig := filepath.Join(m.Home, "patches", "orig", filepath.Base(target))
	if _, err := os.Stat(orig); err == nil {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(orig), 0o755); err != nil {
		return err
	}
	raw, err := os.ReadFile(target)
	if err != nil {
		return err
	}
	return os.WriteFile(orig, raw, 0o644)
}

// applyOne ставит блок (идемпотентно). Возвращает true, если файл изменился.
func (m *Manager) applyOne(prompts, module string, patch map[string]any, body string) (bool, error) {
	if len(body) > kernel.MaxPromptBytes {
		return false, kernel.Newf(kernel.KindGeneric, "текст патча больше %d байт", kernel.MaxPromptBytes)
	}
	target, err := targetFile(prompts, stringOf(patch["target"]))
	if err != nil {
		return false, err
	}
	raw, err := os.ReadFile(target)
	if err != nil {
		return false, err
	}
	old := string(raw)
	pos := stringOf(patch["position"])
	if pos == "" {
		pos = "end"
	}
	next := putBlock(old, module, stringOf(patch["id"]), body, pos)
	if blocksSize(next) > maxBlocksBytes {
		return false, kernel.Newf(kernel.KindGeneric, "в %s слишком много добавок (больше %d КБ)", filepath.Base(target), maxBlocksBytes/1024)
	}
	if next == old {
		return false, nil
	}
	if err := m.backupOnce(target); err != nil {
		return false, err
	}
	return true, writeAtomicKeepMode(target, next)
}

// removeModuleBlocks убирает блоки детали из всех файлов промптов. Возвращает число изменённых файлов.
func removeModuleBlocks(prompts, module string, keep map[[2]string]bool) int {
	changed := 0
	for _, name := range kernel.PromptTargets {
		f := filepath.Join(prompts, name)
		st, err := os.Lstat(f)
		if err != nil || !st.Mode().IsRegular() {
			continue
		}
		raw, err := os.ReadFile(f)
		if err != nil {
			continue
		}
		old := string(raw)
		next := removeBlocks(old, module, keep)
		if next != old {
			if writeAtomicKeepMode(f, next) == nil {
				changed++
			}
		}
	}
	return changed
}

// removeOrphans убирает блоки деталей, которых больше нет в системе.
func removeOrphans(prompts string, installed map[string]*ModuleState) int {
	changed := 0
	for _, name := range kernel.PromptTargets {
		f := filepath.Join(prompts, name)
		st, err := os.Lstat(f)
		if err != nil || !st.Mode().IsRegular() {
			continue
		}
		raw, err := os.ReadFile(f)
		if err != nil {
			continue
		}
		old := string(raw)
		orphanMods := map[string]bool{}
		for _, s := range findSpans(old) {
			if _, ok := installed[s.Module]; !ok {
				orphanMods[s.Module] = true
			}
		}
		if len(orphanMods) == 0 {
			continue
		}
		next := old
		for mod := range orphanMods {
			next = removeBlocks(next, mod, nil)
		}
		if writeAtomicKeepMode(f, next) == nil {
			changed++
		}
	}
	return changed
}

// PatchState — состояние одного патча для панели и журнала.
type PatchState struct {
	ID     string `json:"id"`
	Key    string `json:"key"`
	Title  string `json:"title"`
	Status string `json:"status"`
	Detail string `json:"detail"`
	Target string `json:"target,omitempty"`
	On     string `json:"on,omitempty"`
}

func patchStatePath(m *Manager) string { return filepath.Join(m.Home, "patches", "state.json") }

// LoadPatchState читает последнее известное состояние патчей.
func (m *Manager) LoadPatchState() map[string]map[string]PatchState {
	out := map[string]map[string]PatchState{}
	if raw, err := os.ReadFile(patchStatePath(m)); err == nil {
		_ = jsonUnmarshal(raw, &out)
	}
	return out
}

func (m *Manager) savePatchState(state map[string]map[string]PatchState) error {
	raw, err := jsonMarshalIndent(state)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(patchStatePath(m)), 0o755); err != nil {
		return err
	}
	return kernel.AtomicWrite(patchStatePath(m), raw, 0o644)
}

// SyncPatches приводит патчи детали в соответствие с её состоянием: включена и доверена — действуют.
// prompts может быть пустым (каталог бота не найден).
func (m *Manager) SyncPatches(name, prompts string, state map[string]map[string]PatchState) ([]PatchState, error) {
	installed := m.installedMap()
	if _, ok := installed[name]; !ok {
		if prompts != "" {
			removeModuleBlocks(prompts, name, nil)
		}
		return nil, nil
	}
	mod, err := m.Manifest(name, "")
	if err != nil {
		return nil, err
	}
	mdir := m.ModuleDir(name, "")
	enabled := installed[name].Enabled
	var trust TrustState
	if len(mod.Patches) > 0 {
		trust, err = Status(m.Home, name, mdir)
		if err != nil {
			return nil, err
		}
	}
	keep := map[[2]string]bool{}
	var results []PatchState
	for _, p := range mod.Patches {
		key := stringOf(p["key"])
		id := stringOf(p["id"])
		title := stringOf(p["title"])
		if title == "" {
			title = kernel.PatchKeys[key]
		}
		r := PatchState{ID: id, Key: key, Title: title}
		if key == "prompt.append" {
			r.Target = stringOf(p["target"])
		} else {
			r.On = stringOf(p["on"])
		}
		switch {
		case !enabled:
			r.Status, r.Detail = "inactive", "деталь выключена"
		case !trust.Allowed:
			r.Status, r.Detail = "pending_trust", trust.Reason+": нужна подпись или одобрение"
		case key == "hook.event":
			r.Status, r.Detail = "active", "реагирует на события, пока деталь включена"
		case prompts == "":
			r.Status, r.Detail = "no_bot_dir", "каталог бота не найден (настройка kuni_dir модуля kuni)"
		default:
			body, rerr := os.ReadFile(filepath.Join(mdir, stringOf(p["file"])))
			if rerr != nil {
				r.Status, r.Detail = "error", rerr.Error()
				break
			}
			changed, aerr := m.applyOne(prompts, name, p, string(body))
			if aerr != nil {
				r.Status, r.Detail = "error", aerr.Error()
				break
			}
			keep[[2]string{name, id}] = true
			r.Status = "active"
			r.Detail = "добавлено в " + r.Target
			if changed {
				r.Detail += "; подействует после перезапуска бота"
			}
		}
		results = append(results, r)
	}
	if prompts != "" {
		removeModuleBlocks(prompts, name, keep)
	}
	prev := state[name]
	for _, r := range results {
		if prev[r.ID].Status == r.Status {
			continue
		}
		if r.Status == "inactive" && prev[r.ID].Status != "active" {
			continue
		}
		topic := map[string]string{"active": "patch.applied", "pending_trust": "patch.pending", "error": "patch.error"}[r.Status]
		if topic == "" {
			topic = "patch.removed"
		}
		detail := r.Detail
		if len(detail) > 120 {
			detail = detail[:120]
		}
		_, _ = m.Emit(topic, map[string]any{"module": name, "patch": r.ID, "key": r.Key, "detail": detail})
	}
	byID := map[string]PatchState{}
	for _, r := range results {
		byID[r.ID] = r
	}
	state[name] = byID
	return results, nil
}

// SyncAllPatches применяет и снимает патчи всех деталей. Вызывается после включения, выключения, замены, удаления.
func (m *Manager) SyncAllPatches() (map[string]map[string]PatchState, error) {
	prompts := m.BotPromptsDir()
	state := m.LoadPatchState()
	installed := m.installedMap()
	names := map[string]bool{}
	for n := range state {
		names[n] = true
	}
	for n := range installed {
		if mod, err := m.Manifest(n, ""); err == nil && len(mod.Patches) > 0 {
			names[n] = true
		}
	}
	sorted := make([]string, 0, len(names))
	for n := range names {
		sorted = append(sorted, n)
	}
	sort.Strings(sorted)
	for _, n := range sorted {
		if _, ok := installed[n]; !ok {
			for pid, r := range state[n] {
				if r.Status == "active" {
					_, _ = m.Emit("patch.removed", map[string]any{"module": n, "patch": pid, "key": r.Key, "detail": "деталь удалена"})
				}
			}
			delete(state, n)
		}
		if _, err := m.SyncPatches(n, prompts, state); err != nil {
			return nil, err
		}
		if _, ok := installed[n]; !ok {
			delete(state, n)
		}
	}
	if prompts != "" {
		removeOrphans(prompts, installed)
	}
	return state, m.savePatchState(state)
}

func stringOf(v any) string {
	s, _ := v.(string)
	return s
}
