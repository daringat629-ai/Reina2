package manager

import (
	"encoding/json"
	"os"
	"syscall"
)

func jsonUnmarshal(raw []byte, v any) error { return json.Unmarshal(raw, v) }

func jsonMarshalIndent(v any) ([]byte, error) { return json.MarshalIndent(v, "", " ") }

// tryLock берёт неблокирующую эксклюзивную блокировку файла.
func tryLock(f *os.File) bool {
	return syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB) == nil
}

func unlockFile(f *os.File) {
	_ = syscall.Flock(int(f.Fd()), syscall.LOCK_UN)
}
