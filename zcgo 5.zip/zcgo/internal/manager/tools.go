// Каталог инструментов для бота (tools.json). Порт export_tools/refresh_tools.
package manager

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"time"

	"zcgo/internal/kernel"
)

// ToolEntry — инструмент в каталоге для бота.
type ToolEntry struct {
	Module         string            `json:"module"`
	Name           string            `json:"name"`
	Description    string            `json:"description"`
	Parameters     map[string]any    `json:"parameters"`
	Command        []string          `json:"command"`
	Cwd            string            `json:"cwd"`
	Env            map[string]string `json:"env"`
	TimeoutSeconds int               `json:"timeout_seconds"`
	MaxOutput      int               `json:"max_output_bytes"`
}

// Catalog — tools.json (version 1).
type Catalog struct {
	Version int         `json:"version"`
	Tools   []ToolEntry `json:"tools"`
	Errors  []string    `json:"errors"`
}

// ToolsPath — файл каталога для бота.
func (m *Manager) ToolsPath() string { return filepath.Join(m.Home, "tools.json") }

func (m *Manager) toolEnv(name string, mod *kernel.Manifest, mdir string) map[string]string {
	data := filepath.Join(m.Home, "data", name)
	_ = os.MkdirAll(data, 0o755)
	env := map[string]string{"ZEROCORE_API": "1", "ZEROCORE_HOME": m.Home, "ZEROCORE_MODULE": name, "ZEROCORE_DATA_DIR": data}
	if runEnv, ok := mod.Run["env"].(map[string]any); ok {
		for k, v := range runEnv {
			if val := m.expandStr(v, name, mdir); val != "" {
				env[k] = val
			}
		}
	}
	return env
}

// BuildCatalog собирает каталог включённых модулей без записи на диск.
func (m *Manager) BuildCatalog() Catalog {
	cat := Catalog{Version: 1, Tools: []ToolEntry{}, Errors: []string{}}
	owner := map[string]string{}
	for _, name := range m.EnabledNames() {
		mod, err := m.Manifest(name, "")
		if err != nil {
			cat.Errors = append(cat.Errors, name+": "+err.Error())
			continue
		}
		mdir := m.ModuleDir(name, "")
		env := map[string]string{}
		if len(mod.Tools) > 0 {
			env = m.toolEnv(name, mod, mdir)
		}
		for _, t := range mod.Tools {
			if prev, dup := owner[t.Name]; dup {
				cat.Errors = append(cat.Errors, sprintfModule(name, "имя инструмента "+t.Name+" уже занято модулем "+prev))
				continue
			}
			owner[t.Name] = name
			params := t.Parameters
			if params == nil {
				params = map[string]map[string]any{}
			}
			required := t.Required
			if required == nil {
				required = []string{}
			}
			timeout, maxOut := 30, 8000
			if t.TimeoutSeconds != nil {
				timeout = *t.TimeoutSeconds
			}
			if t.MaxOutput != nil {
				maxOut = *t.MaxOutput
			}
			cat.Tools = append(cat.Tools, ToolEntry{
				Module: name, Name: t.Name, Description: t.Description,
				Parameters: map[string]any{"properties": params, "required": required},
				Command:    m.expandList(t.Command, name, mdir), Cwd: mdir, Env: env,
				TimeoutSeconds: timeout, MaxOutput: maxOut,
			})
		}
	}
	return cat
}

func sprintfModule(name, msg string) string { return name + ": " + msg }

// ExportTools пишет tools.json, если содержимое изменилось. Возвращает каталог.
func (m *Manager) ExportTools() (Catalog, error) {
	cat := m.BuildCatalog()
	path := m.ToolsPath()
	if raw, err := os.ReadFile(path); err == nil {
		var old map[string]any
		if json.Unmarshal(raw, &old) == nil {
			delete(old, "generated")
			var cur map[string]any
			curRaw, _ := json.Marshal(cat)
			_ = json.Unmarshal(curRaw, &cur)
			if reflect.DeepEqual(old, cur) {
				return cat, nil
			}
		}
	}
	doc := struct {
		Catalog
		Generated float64 `json:"generated"`
	}{cat, float64(time.Now().UnixNano()) / 1e9}
	raw, err := json.MarshalIndent(doc, "", " ")
	if err != nil {
		return cat, err
	}
	if err := kernel.AtomicWrite(path, raw, 0o644); err != nil {
		return cat, err
	}
	return cat, nil
}

// RefreshTools обновляет каталог после изменения набора модулей. Сбой не ломает основную операцию.
func (m *Manager) RefreshTools() {
	before := fileMTime(m.ToolsPath())
	cat, err := m.ExportTools()
	if err != nil {
		_, _ = m.Emit("tools.export_failed", map[string]any{"error": truncate(err.Error(), 300)})
		return
	}
	if before != fileMTime(m.ToolsPath()) {
		_, _ = m.Emit("tools.exported", map[string]any{"count": len(cat.Tools), "problems": len(cat.Errors)})
	}
}

func fileMTime(p string) int64 {
	st, err := os.Stat(p)
	if err != nil {
		return 0
	}
	return st.ModTime().UnixNano()
}

// RefreshExtensions обновляет каталог и патчи деталей.
func (m *Manager) RefreshExtensions() {
	m.RefreshTools()
	if _, err := m.SyncAllPatches(); err != nil {
		_, _ = m.Emit("patch.sync_failed", map[string]any{"error": truncate(err.Error(), 300)})
	}
}

func sortedToolNames(cat Catalog) []string {
	out := make([]string, 0, len(cat.Tools))
	for _, t := range cat.Tools {
		out = append(out, t.Name)
	}
	sort.Strings(out)
	return out
}
