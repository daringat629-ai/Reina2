package manager

import (
	"strings"

	"zcgo/internal/kernel"
)

// ExpandCommand подставляет ${module_dir}, ${data_dir} и т.д. в команду детали (виджеты панели).
func (m *Manager) ExpandCommand(name, mdir string, cmd []string) []string {
	return m.expandList(cmd, name, mdir)
}

// ModuleEnv — окружение запуска детали (ZEROCORE_*), как у её процессов.
func (m *Manager) ModuleEnv(name string, mod *kernel.Manifest, mdir string) []string {
	return m.envFor(name, mod, mdir, false)
}

// ModuleDirOf — каталог установленной версии детали.
func (m *Manager) ModuleDirOf(name string) (string, error) {
	st, ok := m.installedMap()[name]
	if !ok {
		return "", kernel.Newf(kernel.KindGeneric, "%s: не установлена", name)
	}
	return m.ModuleDir(name, st.Version), nil
}

// GetSecret — значение секрета детали (для панели и оповещений; наружу не отдаётся).
func GetSecret(home, module, name string) string {
	return loadSecrets(home, module)[name]
}

// BlockRef — блок, который ведёт ядро (патч детали) в тексте промпта.
type BlockRef struct {
	Module, Patch, Text string
}

// SplitBlocks отделяет блоки ядра от текста: plain — текст без блоков, blocks — сами блоки по порядку.
func SplitBlocks(text string) (plain string, blocks []BlockRef) {
	spans := findSpans(text)
	var b strings.Builder
	pos := 0
	for _, s := range spans {
		b.WriteString(text[pos:s.Start])
		blocks = append(blocks, BlockRef{Module: s.Module, Patch: s.ID, Text: text[s.Start:s.End]})
		pos = s.End
	}
	b.WriteString(text[pos:])
	return b.String(), blocks
}
