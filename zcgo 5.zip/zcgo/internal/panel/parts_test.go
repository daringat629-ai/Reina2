package panel

import (
	"archive/zip"
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// cfgModule ставит библиотеку с настройками по умолчанию.
func cfgModule(t *testing.T, srv *Server, name string) {
	t.Helper()
	src := filepath.Join(t.TempDir(), name)
	_ = os.MkdirAll(src, 0o755)
	mf := map[string]any{"name": name, "version": "1.0.0", "api": "1", "kind": "library",
		"config": map[string]any{"interval": 300, "ratio": 0.5, "enabled": false, "label": "метка"}}
	raw, _ := json.Marshal(mf)
	if err := os.WriteFile(filepath.Join(src, "manifest.json"), raw, 0o644); err != nil {
		t.Fatal(err)
	}
	if _, err := srv.M.Install(src); err != nil {
		t.Fatalf("install: %v", err)
	}
}

func TestConfigSetCoercesToDefaultTypes(t *testing.T) {
	srv, _ := newPanel(t)
	cfgModule(t, srv, "demo_cfg")
	if _, err := srv.configSet("demo_cfg", map[string]any{"key": "interval", "value": "600"}); err != nil {
		t.Fatalf("строка в число: %v", err)
	}
	if _, err := srv.configSet("demo_cfg", map[string]any{"key": "interval", "value": 7.5}); err == nil {
		t.Error("дробное для целой настройки должно отклоняться")
	}
	if _, err := srv.configSet("demo_cfg", map[string]any{"key": "enabled", "value": "да"}); err != nil {
		t.Fatalf("логическое из строки: %v", err)
	}
	out, err := srv.configSet("demo_cfg", map[string]any{"key": "label", "value": 42})
	if err != nil {
		t.Fatal(err)
	}
	cfg := out
	if cfg["interval"] != float64(600) || cfg["enabled"] != true || cfg["label"] != "42" {
		t.Errorf("значения: %v", cfg)
	}
	if _, err := srv.configSet("demo_cfg", map[string]any{"key": "nope", "value": 1}); err == nil || !strings.Contains(err.Error(), "доступны") {
		t.Errorf("неизвестный ключ: %v", err)
	}
}

func TestKuniCannotBeUninstalledFromPanel(t *testing.T) {
	srv, _ := newPanel(t)
	if _, err := srv.uninstallPart("kuni", map[string]any{"confirm": "kuni"}); err == nil || !strings.Contains(err.Error(), "защищённая") {
		t.Errorf("kuni должен быть защищён: %v", err)
	}
	cfgModule(t, srv, "demo_del")
	if _, err := srv.uninstallPart("demo_del", map[string]any{}); err == nil {
		t.Error("без подтверждения удаление не выполняется")
	}
	res, err := srv.uninstallPart("demo_del", map[string]any{"confirm": "demo_del"})
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := srv.installed()["demo_del"]; ok {
		t.Error("деталь осталась установленной")
	}
	backup, _ := res["backup"].(string)
	if backup == "" {
		t.Fatal("копия удалённой детали не сохранена")
	}
	if _, err := os.Stat(backup); err != nil {
		t.Errorf("копия не на диске: %v", err)
	}
}

func TestPackAndUploadRoundTrip(t *testing.T) {
	srv, ts := newPanel(t)
	cfgModule(t, srv, "demo_pack")
	req, _ := http.NewRequest("GET", ts.URL+"/api/modules/demo_pack/pack", nil)
	req.Header.Set("X-Token", token)
	resp, err := ts.Client().Do(req)
	if err != nil {
		t.Fatal(err)
	}
	data, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 200 || resp.Header.Get("Content-Type") != "application/zip" || !strings.Contains(resp.Header.Get("Content-Disposition"), "demo_pack-1.0.0.zip") {
		t.Fatalf("выгрузка: %d %s %s", resp.StatusCode, resp.Header.Get("Content-Type"), resp.Header.Get("Content-Disposition"))
	}
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		t.Fatal(err)
	}
	foundManifest := false
	for _, f := range zr.File {
		if f.Name == "manifest.json" {
			foundManifest = true
		}
	}
	if !foundManifest {
		t.Error("в архиве нет manifest.json")
	}
	// загрузка того же архива под другим именем невозможна: деталь уже стоит
	req2, _ := http.NewRequest("POST", ts.URL+"/api/modules/upload", bytes.NewReader(data))
	req2.Header.Set("X-Token", token)
	resp2, err := ts.Client().Do(req2)
	if err != nil {
		t.Fatal(err)
	}
	resp2.Body.Close()
	if resp2.StatusCode != 400 {
		t.Errorf("повторная установка должна отказать: %d", resp2.StatusCode)
	}
	req3, _ := http.NewRequest("POST", ts.URL+"/api/modules/upload", strings.NewReader("не zip"))
	req3.Header.Set("X-Token", token)
	resp3, err := ts.Client().Do(req3)
	if err != nil {
		t.Fatal(err)
	}
	resp3.Body.Close()
	if resp3.StatusCode != 400 {
		t.Errorf("не zip должен отказать: %d", resp3.StatusCode)
	}
}

func TestWireKuniCatalogEditsOnlyTheKey(t *testing.T) {
	dir := t.TempDir()
	cfg := filepath.Join(dir, "config.toml")
	original := "# конфиг бота\n[general]\nlockdown = \"yes\"\n\n[misc]\nname = \"marin\"\n\n[other]\nx = 1\n"
	if err := os.WriteFile(cfg, []byte(original), 0o600); err != nil {
		t.Fatal(err)
	}
	catalog := filepath.Join(dir, "tools.json")
	status, err := wireKuniCatalog(cfg, catalog)
	if err != nil || status != "added" {
		t.Fatalf("первая запись: %s %v", status, err)
	}
	raw, _ := os.ReadFile(cfg)
	if !strings.Contains(string(raw), "# конфиг бота") || !strings.Contains(string(raw), `name = "marin"`) || !strings.Contains(string(raw), `external_tools_catalog = "`) {
		t.Errorf("текст испорчен: %s", raw)
	}
	if backup, err := os.ReadFile(cfg + ".bak-zerocore"); err != nil || string(backup) != original {
		t.Errorf("копия до правки: %v", err)
	}
	if status, _ := wireKuniCatalog(cfg, catalog); status != "unchanged" {
		t.Errorf("повтор: %s", status)
	}
	if wiredCatalog(cfg) != catalog {
		t.Errorf("подключённый каталог: %q", wiredCatalog(cfg))
	}
	if status, _ := wireKuniCatalog(cfg, filepath.Join(dir, "other.json")); status != "updated" {
		t.Errorf("смена пути: %s", status)
	}
}

func TestDoctorAndAvailableRespond(t *testing.T) {
	srv, ts := newPanel(t)
	checks := srv.doctor("", 1)
	if len(checks) == 0 || checks[0].Title == "" {
		t.Fatal("проверки не выполнены")
	}
	code, out, _ := do(t, ts, "GET", "/api/system/doctor", token, "")
	if code != 200 || out["checks"] == nil {
		t.Errorf("doctor: %d %v", code, out)
	}
	code, out, _ = do(t, ts, "GET", "/api/available", token, "")
	if code != 200 || out["modules"] == nil {
		t.Errorf("available: %d %v", code, out)
	}
	code, out, _ = do(t, ts, "POST", "/api/wire-kuni", token, "")
	if code != 400 || !strings.Contains(out["error"].(string), "каталог бота не найден") {
		t.Errorf("wire-kuni без бота: %d %v", code, out)
	}
}

func TestSecretsRouteRefusesKuniAndUnknown(t *testing.T) {
	srv, ts := newPanel(t)
	cfgModule(t, srv, "demo_sec")
	code, out, _ := do(t, ts, "POST", "/api/secrets/demo_sec", token, `{"name":"NEWS_KEY","value":"abc"}`)
	if code != 200 || len(out["names"].([]any)) != 1 {
		t.Fatalf("секрет: %d %v", code, out)
	}
	code, out, _ = do(t, ts, "GET", "/api/secrets/demo_sec", token, "")
	if code != 200 {
		t.Fatalf("список: %d %v", code, out)
	}
	raw, _ := json.Marshal(out)
	if strings.Contains(string(raw), "abc") {
		t.Error("значение секрета не должно отдаваться")
	}
	if code, _, _ := do(t, ts, "POST", "/api/secrets/ghost", token, `{"name":"A_B","value":"x"}`); code != 400 {
		t.Errorf("неустановленная деталь: %d", code)
	}
}
