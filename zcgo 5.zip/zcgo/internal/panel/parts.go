package panel

// Управление деталями из панели: настройки, доверие (подпись и одобрение), удаление с копией, zip-упаковка и загрузка.
// Конструктор деталей (scaffold) и обновление ядра здесь не перенесены — см. README.

import (
	"archive/zip"
	"bytes"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"zcgo/internal/manager"
)

const (
	protectedModule = "kuni"
	maxUpload       = 8 * 1024 * 1024
	maxUnpacked     = 50 * 1024 * 1024
	maxZipFiles     = 500
)

// moduleDir — каталог установленной версии детали (пустой, если её нет).
func (s *Server) moduleDir(name string) string {
	d, _ := s.M.ModuleDirOf(name)
	return d
}

func installedSet(s *Server) map[string]*manager.ModuleState {
	return s.installed()
}

// configGet — описание детали и её настроек для панели.
func (s *Server) configGet(name string) (map[string]any, error) {
	if _, ok := installedSet(s)[name]; !ok {
		return nil, fmt.Errorf("%s: не установлен", name)
	}
	mf, err := s.M.Manifest(name, "")
	if err != nil {
		return nil, err
	}
	cfg, err := s.M.Config(name, "")
	if err != nil {
		return nil, err
	}
	trustState, _ := manager.Status(s.M.Home, name, s.moduleDir(name))
	patches := []any{}
	if ps, ok := s.M.LoadPatchState()[name]; ok {
		for _, p := range ps {
			patches = append(patches, p)
		}
	}
	versions := []string{}
	if entries, err := os.ReadDir(filepath.Join(s.M.ModuleRoot(name), "versions")); err == nil {
		for _, e := range entries {
			if e.IsDir() {
				versions = append(versions, e.Name())
			}
		}
		sort.Strings(versions)
	}
	return map[string]any{"name": name, "version": mf.Version, "kind": mf.Kind, "description": mf.Description,
		"provides": mf.Provides, "requires": mf.Requires, "optional_requires": mf.OptionalRequires,
		"config": cfg, "defaults": mf.Config, "protected": name == protectedModule,
		"trust": trustState, "patches": patches, "secrets": manager.SecretNames(s.M.Home, name), "versions": versions}, nil
}

// configSet меняет одну настройку; значение приводится к типу значения по умолчанию.
func (s *Server) configSet(name string, body map[string]any) (map[string]any, error) {
	if _, ok := installedSet(s)[name]; !ok {
		return nil, fmt.Errorf("%s: не установлен", name)
	}
	mf, err := s.M.Manifest(name, "")
	if err != nil {
		return nil, err
	}
	key, _ := body["key"].(string)
	def, ok := mf.Config[key]
	if !ok {
		names := make([]string, 0, len(mf.Config))
		for k := range mf.Config {
			names = append(names, k)
		}
		sort.Strings(names)
		avail := strings.Join(names, ", ")
		if avail == "" {
			avail = "нет настроек"
		}
		return nil, fmt.Errorf("%s: нет настройки %q; доступны: %s", name, key, avail)
	}
	value, err := coerceConfig(body["value"], def)
	if err != nil {
		return nil, fmt.Errorf("%s.%s: %v", name, key, err)
	}
	if _, err := s.M.ConfigSet(name, key, value); err != nil {
		return nil, err
	}
	return s.M.Config(name, "")
}

// coerceConfig приводит значение к типу значения по умолчанию (логический, целое, дробное, строка).
func coerceConfig(v any, def any) (any, error) {
	switch d := def.(type) {
	case bool:
		if b, ok := v.(bool); ok {
			return b, nil
		}
		switch strings.ToLower(strings.TrimSpace(fmt.Sprint(v))) {
		case "1", "true", "yes", "да", "on":
			return true, nil
		}
		return false, nil
	case float64:
		if d == float64(int64(d)) {
			switch x := v.(type) {
			case float64:
				if x != float64(int64(x)) {
					return nil, errors.New("ожидается целое число")
				}
				return x, nil
			case string:
				var f float64
				if _, err := fmt.Sscan(x, &f); err != nil || f != float64(int64(f)) {
					return nil, errors.New("ожидается целое число")
				}
				return f, nil
			}
			return nil, errors.New("ожидается целое число")
		}
		switch x := v.(type) {
		case float64:
			return x, nil
		case string:
			var f float64
			if _, err := fmt.Sscan(x, &f); err != nil {
				return nil, errors.New("ожидается число")
			}
			return f, nil
		}
		return nil, errors.New("ожидается число")
	}
	return fmt.Sprint(v), nil
}

// setTrust: sign — подписать ключом владельца, approve — одобрить здесь, revoke — снять одобрение.
func (s *Server) setTrust(name string, body map[string]any) (map[string]any, error) {
	if _, ok := installedSet(s)[name]; !ok {
		return nil, fmt.Errorf("%s: не установлен", name)
	}
	action, _ := body["action"].(string)
	mdir := s.moduleDir(name)
	switch action {
	case "sign":
		if _, err := manager.Sign(s.M.Home, mdir); err != nil {
			return nil, err
		}
	case "approve":
		mf, err := s.M.Manifest(name, "")
		if err != nil {
			return nil, err
		}
		if err := manager.Approve(s.M.Home, name, mdir, mf.Version); err != nil {
			return nil, err
		}
	case "revoke":
		if _, err := manager.Revoke(s.M.Home, name); err != nil {
			return nil, err
		}
	default:
		return nil, errors.New("действие: sign, approve или revoke")
	}
	s.hooks.ForgetTrust(name)
	s.M.RefreshExtensions()
	return s.configGet(name)
}

// uninstallPart удаляет деталь; перед удалением её код сохраняется в removed/ как zip.
func (s *Server) uninstallPart(name string, body map[string]any) (map[string]any, error) {
	if name == protectedModule {
		return nil, fmt.Errorf("%s: защищённая деталь, её нельзя удалить из панели", name)
	}
	if confirm, _ := body["confirm"].(string); confirm != name {
		return nil, fmt.Errorf("подтвердите удаление: передайте confirm=%s", name)
	}
	purge, _ := body["purge_data"].(bool)
	var backup any
	if _, ok := installedSet(s)[name]; ok {
		if fname, data, err := packPart(s.M, name); err == nil {
			out := filepath.Join(s.M.Home, "removed")
			if os.MkdirAll(out, 0o755) == nil && os.WriteFile(filepath.Join(out, fname), data, 0o644) == nil {
				backup = filepath.Join(out, fname)
			}
		}
	}
	if _, err := s.M.Uninstall(name, &purge, false, false); err != nil {
		return nil, err
	}
	return map[string]any{"removed": name, "data_deleted": purge, "backup": backup}, nil
}

// packPart упаковывает установленную деталь в zip: имя файла и содержимое.
func packPart(m *manager.Manager, name string) (string, []byte, error) {
	mf, err := m.Manifest(name, "")
	if err != nil {
		return "", nil, err
	}
	mdir, err := m.ModuleDirOf(name)
	if err != nil {
		return "", nil, err
	}
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	err = filepath.WalkDir(mdir, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		rel, rerr := filepath.Rel(mdir, p)
		if rerr != nil || rel == "." {
			return nil
		}
		if d.IsDir() {
			if d.Name() == "__pycache__" {
				return filepath.SkipDir
			}
			return nil
		}
		if !d.Type().IsRegular() {
			return nil
		}
		w, err := zw.Create(filepath.ToSlash(rel))
		if err != nil {
			return err
		}
		f, err := os.Open(p)
		if err != nil {
			return err
		}
		defer f.Close()
		_, err = io.Copy(w, f)
		return err
	})
	if err != nil {
		return "", nil, err
	}
	if err := zw.Close(); err != nil {
		return "", nil, err
	}
	return fmt.Sprintf("%s-%s.zip", name, mf.Version), buf.Bytes(), nil
}

// uploadPart ставит деталь из присланного zip (выключенной). Проверяет размер, формат и распаковку.
func (s *Server) uploadPart(data []byte) (map[string]any, error) {
	if len(data) == 0 || len(data) > maxUpload {
		return nil, fmt.Errorf("файл пустой или больше %d МБ", maxUpload/1048576)
	}
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, errors.New("это не zip-архив")
	}
	var total uint64
	for _, f := range zr.File {
		total += f.UncompressedSize64
	}
	if len(zr.File) > maxZipFiles || total > maxUnpacked {
		return nil, errors.New("архив слишком большой после распаковки")
	}
	tmpDir, err := os.MkdirTemp("", "zc_upload_")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(tmpDir)
	path := filepath.Join(tmpDir, "part.zip")
	if err := os.WriteFile(path, data, 0o600); err != nil {
		return nil, err
	}
	mf, err := s.M.Install(path)
	if err != nil {
		return nil, err
	}
	return map[string]any{"name": mf.Name, "version": mf.Version, "kind": mf.Kind, "installed": true, "enabled": false}, nil
}
