package panel

// Оповещения владельцу в Telegram: бот упал, пошли ошибки, мало места на диске, сбой копии.
// Отправка — обычный Bot API. Токен хранится как секрет детали alerts и нигде не показывается.
// Адрес Bot API можно заменить переменной ZEROCORE_TG_API (для проверок).
// Правило «самостоятельные детали Марин» не перенесено: оно читает журнал selfmod, который остаётся в Python.

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"zcgo/internal/manager"
)

const (
	alertSecretModule = "alerts"
	alertSecretName   = "TELEGRAM_BOT_TOKEN"
)

var (
	alertEvents = map[string]string{"bot_down": "бот остановился", "errors": "всплеск ошибок", "disk": "мало места на диске", "backup": "сбой резервной копии"}
	tokenRE     = regexp.MustCompile(`^[0-9]{5,15}:[A-Za-z0-9_-]{20,80}$`)
	chatRE      = regexp.MustCompile(`^-?[0-9]{1,20}$`)
)

type alertSettings struct {
	Enabled        bool            `json:"enabled"`
	ChatID         string          `json:"chat_id"`
	Events         map[string]bool `json:"events"`
	CooldownMin    int             `json:"cooldown_min"`
	ErrorThreshold int             `json:"error_threshold"`
	DiskPercent    int             `json:"disk_percent"`
}

func defaultAlerts() alertSettings {
	ev := map[string]bool{}
	for k := range alertEvents {
		ev[k] = true
	}
	return alertSettings{Events: ev, CooldownMin: 30, ErrorThreshold: 5, DiskPercent: 90}
}

func alertsFile(home string) string { return filepath.Join(home, "alerts.json") }
func alertsStateFile(home string) string {
	return filepath.Join(home, "alerts_state.json")
}

func loadAlerts(home string) alertSettings {
	s := defaultAlerts()
	raw, err := os.ReadFile(alertsFile(home))
	if err != nil {
		return s
	}
	var stored map[string]any
	if json.Unmarshal(raw, &stored) != nil {
		return s
	}
	if v, ok := stored["enabled"].(bool); ok {
		s.Enabled = v
	}
	if v, ok := stored["chat_id"].(string); ok {
		s.ChatID = v
	}
	for key, dst := range map[string]*int{"cooldown_min": &s.CooldownMin, "error_threshold": &s.ErrorThreshold, "disk_percent": &s.DiskPercent} {
		if f, ok := stored[key].(float64); ok {
			*dst = int(f)
		}
	}
	if ev, ok := stored["events"].(map[string]any); ok {
		for k, v := range ev {
			if _, known := alertEvents[k]; known {
				if b, ok := v.(bool); ok {
					s.Events[k] = b
				}
			}
		}
	}
	return s
}

func saveAlerts(home string, patch map[string]any) (map[string]any, error) {
	s := loadAlerts(home)
	if v, ok := patch["enabled"]; ok {
		b, ok := v.(bool)
		if !ok {
			return nil, errors.New("enabled: true или false")
		}
		s.Enabled = b
	}
	if v, ok := patch["chat_id"]; ok {
		cid := strings.TrimSpace(fmt.Sprint(v))
		if cid != "" && !chatRE.MatchString(cid) {
			return nil, errors.New("chat_id: число (для группы с минусом); узнать его можно у @userinfobot")
		}
		s.ChatID = cid
	}
	for key, bounds := range map[string][2]int{"cooldown_min": {1, 1440}, "error_threshold": {1, 1000}, "disk_percent": {50, 99}} {
		v, ok := patch[key]
		if !ok {
			continue
		}
		n, ok := asInt(v)
		if !ok {
			return nil, fmt.Errorf("%s: целое число", key)
		}
		if n < bounds[0] || n > bounds[1] {
			return nil, fmt.Errorf("%s: от %d до %d", key, bounds[0], bounds[1])
		}
		switch key {
		case "cooldown_min":
			s.CooldownMin = n
		case "error_threshold":
			s.ErrorThreshold = n
		default:
			s.DiskPercent = n
		}
	}
	if v, ok := patch["events"]; ok {
		ev, ok := v.(map[string]any)
		if !ok {
			return nil, errors.New("events: объект {имя: true или false}")
		}
		for k, val := range ev {
			b, isBool := val.(bool)
			if _, known := alertEvents[k]; !known || !isBool {
				return nil, errors.New("events: объект {имя: true или false}, имена: bot_down, errors, disk, backup")
			}
			s.Events[k] = b
		}
	}
	if s.Enabled && (s.ChatID == "" || manager.GetSecret(home, alertSecretModule, alertSecretName) == "") {
		return nil, errors.New("чтобы включить оповещения, задайте токен бота и chat_id")
	}
	raw, err := json.MarshalIndent(s, "", " ")
	if err != nil {
		return nil, err
	}
	if err := writeFileAtomic(alertsFile(home), raw, 0o644); err != nil {
		return nil, err
	}
	return alertsStatus(home), nil
}

func setAlertToken(home string, token string) (map[string]any, error) {
	token = strings.TrimSpace(token)
	if token != "" && !tokenRE.MatchString(token) {
		return nil, errors.New("токен не похож на токен бота от @BotFather (вид 123456789:AAAA...)")
	}
	if _, err := manager.SetSecret(home, alertSecretModule, alertSecretName, token); err != nil {
		return nil, err
	}
	if token == "" && loadAlerts(home).Enabled {
		if _, err := saveAlerts(home, map[string]any{"enabled": false}); err != nil {
			return nil, err
		}
	}
	return alertsStatus(home), nil
}

func alertsStatus(home string) map[string]any {
	s := loadAlerts(home)
	return map[string]any{"enabled": s.Enabled, "chat_id": s.ChatID, "events": s.Events, "cooldown_min": s.CooldownMin,
		"error_threshold": s.ErrorThreshold, "disk_percent": s.DiskPercent,
		"token_set": manager.GetSecret(home, alertSecretModule, alertSecretName) != "", "event_titles": alertEvents}
}

type alertSendError struct{ msg string }

func (e *alertSendError) Error() string { return e.msg }

// sendTelegram шлёт текст владельцу. Токен в тексте ошибок заменяется на ***.
func sendTelegram(home, text string) error {
	token := manager.GetSecret(home, alertSecretModule, alertSecretName)
	chat := loadAlerts(home).ChatID
	if token == "" || chat == "" {
		return &alertSendError{"не заданы токен бота или chat_id"}
	}
	base := strings.TrimRight(os.Getenv("ZEROCORE_TG_API"), "/")
	if base == "" {
		base = "https://api.telegram.org"
	}
	if r := []rune(text); len(r) > 3500 {
		text = string(r[:3500])
	}
	body, _ := json.Marshal(map[string]any{"chat_id": chat, "text": text, "disable_web_page_preview": true})
	client := &http.Client{Timeout: 15 * time.Second}
	resp, err := client.Post(base+"/bot"+token+"/sendMessage", "application/json", bytes.NewReader(body))
	if err != nil {
		return &alertSendError{"нет связи с Telegram: " + strings.ReplaceAll(err.Error(), token, "***")}
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	var reply struct {
		OK          bool   `json:"ok"`
		Description string `json:"description"`
	}
	if resp.StatusCode != 200 && json.Unmarshal(raw, &reply) != nil {
		return &alertSendError{fmt.Sprintf("Telegram ответил %d", resp.StatusCode)}
	}
	if json.Unmarshal(raw, &reply) != nil {
		return &alertSendError{"Telegram вернул не JSON"}
	}
	if resp.StatusCode != 200 {
		return &alertSendError{fmt.Sprintf("Telegram ответил %d: %s", resp.StatusCode, strings.ReplaceAll(reply.Description, token, "***"))}
	}
	if !reply.OK {
		return &alertSendError{"Telegram отклонил сообщение: " + strings.ReplaceAll(reply.Description, token, "***")}
	}
	return nil
}

type alertState struct {
	Last          map[string]float64 `json:"last"`
	DownSince     *float64           `json:"down_since,omitempty"`
	AnnouncedDown bool               `json:"announced_down,omitempty"`
}

func loadAlertState(home string) alertState {
	st := alertState{Last: map[string]float64{}}
	if raw, err := os.ReadFile(alertsStateFile(home)); err == nil {
		_ = json.Unmarshal(raw, &st)
		if st.Last == nil {
			st.Last = map[string]float64{}
		}
	}
	return st
}

func saveAlertState(home string, st alertState) {
	raw, _ := json.Marshal(st)
	_ = writeFileAtomic(alertsStateFile(home), raw, 0o600)
}

// notifyAlert шлёт оповещение, если оно включено и с прошлого такого прошло больше cooldown.
func notifyAlert(home, key, text string, now float64, send func(string, string) error) bool {
	s := loadAlerts(home)
	if !(s.Enabled && s.Events[key]) {
		return false
	}
	st := loadAlertState(home)
	if last, ok := st.Last[key]; ok && now-last < float64(s.CooldownMin*60) {
		return false
	}
	if err := send(home, text); err != nil {
		return false
	}
	st.Last[key] = now
	saveAlertState(home, st)
	return true
}

// checkAlerts проверяет правила (раз в минуту из фонового цикла). Возвращает отправленные тексты.
func checkAlerts(m *manager.Manager, now float64, send func(string, string) error, errorCount func() int, diskPercent func() (float64, bool)) []string {
	home := m.Home
	s := loadAlerts(home)
	if !s.Enabled {
		return nil
	}
	var sent []string
	deliver := func(key, text string) {
		if notifyAlert(home, key, text, now, send) {
			sent = append(sent, text)
		}
	}
	st := loadAlertState(home)
	running, known := kuniRunning(m)
	switch {
	case known && !running:
		if st.DownSince == nil {
			t := now
			st.DownSince = &t
		}
		if now-*st.DownSince >= 120 {
			before := len(sent)
			deliver("bot_down", "Бот Марин остановился (больше 2 минут). Откройте панель: «Плагины» → kuni → запустить.")
			if len(sent) > before {
				st.AnnouncedDown = true
			}
		}
	default:
		if known && running && st.AnnouncedDown {
			text := "Бот Марин снова работает."
			_ = send(home, text)
			sent = append(sent, text)
			st.AnnouncedDown = false
		}
		st.DownSince = nil
	}
	saveAlertState(home, st)
	if n := errorCount(); n >= s.ErrorThreshold {
		deliver("errors", fmt.Sprintf("Всплеск ошибок: %d за последние 10 минут. Откройте «Живой лог» в панели.", n))
	}
	d, ok := diskPercent()
	if ok && d >= float64(s.DiskPercent) {
		deliver("disk", fmt.Sprintf("Мало места на диске: занято %.0f%% (порог %d%%).", d, s.DiskPercent))
	}
	return sent
}

// kuniRunning — состояние бота: (запущен, известно). Если модуль не включён, состояние неизвестно.
func kuniRunning(m *manager.Manager) (bool, bool) {
	for _, r := range m.Status() {
		if r["name"] == "kuni" && r["enabled"] == true {
			running, _ := r["running"].(bool)
			return running, true
		}
	}
	return false, false
}

// asInt принимает целое из JSON (float64) или из кода (int).
func asInt(v any) (int, bool) {
	switch x := v.(type) {
	case int:
		return x, true
	case float64:
		if x == float64(int(x)) {
			return int(x), true
		}
	}
	return 0, false
}
