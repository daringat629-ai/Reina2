package panel

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// Каталог eco должен совпадать с Python: 4 набора, 10 деталей, 45 инструментов.
func TestEcoCatalogShape(t *testing.T) {
	if len(ecoCat.Sets) != 4 || len(ecoCat.Modules) != 10 || len(ecoCat.Tools) != 45 {
		t.Fatalf("каталог: наборов %d, деталей %d, инструментов %d", len(ecoCat.Sets), len(ecoCat.Modules), len(ecoCat.Tools))
	}
	for _, set := range ecoCat.Sets {
		for _, n := range set.Modules {
			if _, ok := ecoCat.Modules[n]; !ok {
				t.Fatalf("набор %s ссылается на неизвестную деталь %s", set.Key, n)
			}
		}
	}
	for name, mod := range ecoCat.Modules {
		for _, tn := range mod.Tools {
			tool, ok := ecoCat.Tools[tn]
			if !ok || tool.Module != name {
				t.Fatalf("инструмент %s не привязан к детали %s", tn, name)
			}
		}
	}
}

// Значение 242 получено той же формулой из Python estimate_tokens для eco_memory.
func TestEcoTokenEstimateMatchesPython(t *testing.T) {
	if got := ecoEstimateTokens(ecoCat.Modules["eco_memory"].Tools); got != 242 {
		t.Fatalf("eco_memory: токены %d, ожидалось 242", got)
	}
}

func TestEcoPayloadFreshHome(t *testing.T) {
	srv, _ := newPanel(t)
	status, out, ok := srv.getExtra([]string{"eco"}, nil)
	if !ok || status != 200 {
		t.Fatalf("GET eco: статус %d, ok %v", status, ok)
	}
	payload := out.(map[string]any)
	sets := payload["sets"].([]any)
	if len(sets) != 4 {
		t.Fatalf("наборов %d", len(sets))
	}
	first := sets[0].(map[string]any)
	if first["enabled"] != false {
		t.Fatalf("набор включён на пустой установке: %v", first["enabled"])
	}
	row := first["modules"].([]any)[0].(map[string]any)
	if row["installed"] != false || row["available"] != false {
		t.Fatalf("деталь на пустой установке: %v", row)
	}
	cat := payload["catalog"].(map[string]any)
	if cat["tools"] != 0 || cat["warn"] != false {
		t.Fatalf("каталог: %v", cat)
	}
}

// writeEcoModule кладёт готовую деталь в поставку ядра (CoreDir/modules), как в установке.
func writeEcoModule(t *testing.T, srv *Server, name string) {
	t.Helper()
	dir := filepath.Join(srv.M.CoreDir, "modules", name)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	raw, _ := json.Marshal(map[string]any{"name": name, "version": "1.0.0", "api": "1", "kind": "library"})
	if err := os.WriteFile(filepath.Join(dir, "manifest.json"), raw, 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestEcoSetUnknownKeyIsRejected(t *testing.T) {
	srv, _ := newPanel(t)
	status, out, _ := srv.postExtra([]string{"eco", "set"}, map[string]any{"key": "nope", "enabled": true})
	if status != 400 {
		t.Fatalf("статус %d", status)
	}
	if msg := out.(map[string]any)["error"].(string); msg != "набора nope нет" {
		t.Fatalf("текст ошибки: %q", msg)
	}
}

func TestEcoSetMissingPartIsExplained(t *testing.T) {
	srv, _ := newPanel(t)
	status, out, _ := srv.postExtra([]string{"eco", "set"}, map[string]any{"key": "base", "enabled": true})
	if status != 400 {
		t.Fatalf("статус %d, ожидалось 400", status)
	}
	if msg := out.(map[string]any)["error"].(string); msg != "eco_memory: нет среди готовых деталей этой установки; обновите ядро" {
		t.Fatalf("текст ошибки: %q", msg)
	}
}

func TestEcoSetEnablesThenDisablesSet(t *testing.T) {
	srv, _ := newPanel(t)
	writeEcoModule(t, srv, "eco_memory")
	writeEcoModule(t, srv, "eco_scheduler")

	status, out, _ := srv.postExtra([]string{"eco", "set"}, map[string]any{"key": "base", "enabled": true})
	if status != 200 {
		t.Fatalf("включение: статус %d, %v", status, out)
	}
	base := out.(map[string]any)["sets"].([]any)[0].(map[string]any)
	if base["enabled"] != true {
		t.Fatalf("набор base не включился: %v", base)
	}
	for _, r := range base["modules"].([]any) {
		row := r.(map[string]any)
		if row["installed"] != true || row["enabled"] != true {
			t.Fatalf("деталь не установлена/включена: %v", row)
		}
	}

	status, out, _ = srv.postExtra([]string{"eco", "set"}, map[string]any{"key": "base", "enabled": false})
	if status != 200 {
		t.Fatalf("выключение: статус %d, %v", status, out)
	}
	base = out.(map[string]any)["sets"].([]any)[0].(map[string]any)
	if base["enabled"] != false {
		t.Fatalf("набор base не выключился: %v", base)
	}
}
