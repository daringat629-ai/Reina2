package panel

import (
	"fmt"
	"os"
	"path/filepath"
	"unicode/utf8"
)

// writeFileAtomic пишет через временный файл и переименование: читатель не увидит половину файла.
func writeFileAtomic(path string, data []byte, perm os.FileMode) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	tmp := path + ".tmp-zc"
	if err := os.WriteFile(tmp, data, perm); err != nil {
		return err
	}
	if err := os.Chmod(tmp, perm); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// fmtSscan — разбор числа с плавающей точкой из строки.
func fmtSscan(s string, v *float64) (int, error) {
	return fmt.Sscan(s, v)
}

func utf8Valid(b []byte) bool { return utf8.Valid(b) }
