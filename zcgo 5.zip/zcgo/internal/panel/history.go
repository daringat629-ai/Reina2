package panel

// История метрик и расходов. Python-версия пишет в sqlite; в Go нет sqlite в стандартной библиотеке,
// поэтому хранение — файлы JSON-lines (history_metrics.jsonl, history_usage.jsonl) с тем же смыслом и сроками:
// метрики 14 дней, расходы 90 дней.

import (
	"bufio"
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
)

const (
	historyKeepDays = 14
	usageKeepDays   = 90
)

func metricsFile(home string) string { return filepath.Join(home, "history_metrics.jsonl") }
func usageFile(home string) string   { return filepath.Join(home, "history_usage.jsonl") }

// readHost — текущие показатели; чего нет на этой машине, то nil.
func readHost() map[string]any {
	h := hostMetrics()
	var disk any
	var st syscall.Statfs_t
	if err := syscall.Statfs("/", &st); err == nil && st.Blocks > 0 {
		total := float64(st.Blocks) * float64(st.Bsize)
		used := total - float64(st.Bfree)*float64(st.Bsize)
		disk = roundTo(100*used/total, 1)
	}
	var battery, temp any
	if caps, _ := filepath.Glob("/sys/class/power_supply/BAT*/capacity"); len(caps) > 0 {
		if raw, err := os.ReadFile(caps[0]); err == nil {
			var v float64
			if _, err := fmtSscan(strings.TrimSpace(string(raw)), &v); err == nil {
				battery = v
			}
		}
	}
	zones, _ := filepath.Glob("/sys/class/thermal/thermal_zone*/temp")
	max := math.Inf(-1)
	for _, z := range zones {
		raw, err := os.ReadFile(z)
		if err != nil {
			continue
		}
		var v float64
		if _, err := fmtSscan(strings.TrimSpace(string(raw)), &v); err == nil && v/1000 > max {
			max = v / 1000
		}
	}
	if !math.IsInf(max, -1) {
		temp = roundTo(max, 1)
	}
	return map[string]any{"load1": h["load1"], "mem": h["mem_pct"], "disk": disk, "battery": battery, "temp": temp}
}

type metricRow struct {
	T       int64    `json:"t"`
	Load1   *float64 `json:"load1"`
	Mem     *float64 `json:"mem"`
	Disk    *float64 `json:"disk"`
	Battery *float64 `json:"battery"`
	Temp    *float64 `json:"temp"`
}

func toPtr(v any) *float64 {
	if f, ok := v.(float64); ok {
		return &f
	}
	return nil
}

// readJSONL читает строки JSON; испорченные строки пропускаются.
func readJSONL(path string, into func(line []byte)) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 64*1024), 4*1024*1024)
	for sc.Scan() {
		into(sc.Bytes())
	}
}

func writeJSONL(path string, rows []json.RawMessage) error {
	var b strings.Builder
	for _, r := range rows {
		b.Write(r)
		b.WriteByte('\n')
	}
	return writeFileAtomic(path, []byte(b.String()), 0o600)
}

// sampleHistory пишет одну точку метрик и удаляет точки старше historyKeepDays.
func sampleHistory(home string, now time.Time, reader func() map[string]any) error {
	r := reader()
	t := now.Unix()
	row, err := json.Marshal(metricRow{T: t, Load1: toPtr(r["load1"]), Mem: toPtr(r["mem"]), Disk: toPtr(r["disk"]), Battery: toPtr(r["battery"]), Temp: toPtr(r["temp"])})
	if err != nil {
		return err
	}
	var keep []json.RawMessage
	cutoff := t - historyKeepDays*86400
	readJSONL(metricsFile(home), func(line []byte) {
		var m metricRow
		if json.Unmarshal(line, &m) == nil && m.T >= cutoff && m.T != t {
			keep = append(keep, append(json.RawMessage(nil), line...))
		}
	})
	keep = append(keep, row)
	return writeJSONL(metricsFile(home), keep)
}

// historySeries — ряды за последние часы, усреднённые в корзины (не больше points точек).
func historySeries(home string, hours float64, now time.Time, points int) map[string]any {
	hours = math.Min(math.Max(hours, 0.1), historyKeepDays*24)
	end := now.Unix()
	start := end - int64(hours*3600)
	var rows []metricRow
	readJSONL(metricsFile(home), func(line []byte) {
		var m metricRow
		if json.Unmarshal(line, &m) == nil && m.T >= start && m.T <= end {
			rows = append(rows, m)
		}
	})
	sort.Slice(rows, func(i, j int) bool { return rows[i].T < rows[j].T })
	out := map[string]any{"t": []any{}, "load1": []any{}, "mem": []any{}, "disk": []any{}, "battery": []any{}, "temp": []any{}}
	if len(rows) == 0 {
		return out
	}
	step := (len(rows) + points - 1) / points
	if step < 1 {
		step = 1
	}
	ts := []any{}
	series := map[string][]any{"load1": {}, "mem": {}, "disk": {}, "battery": {}, "temp": {}}
	for i := 0; i < len(rows); i += step {
		end := i + step
		if end > len(rows) {
			end = len(rows)
		}
		chunk := rows[i:end]
		ts = append(ts, chunk[len(chunk)/2].T)
		pick := func(get func(metricRow) *float64) any {
			sum, n := 0.0, 0
			for _, r := range chunk {
				if v := get(r); v != nil {
					sum += *v
					n++
				}
			}
			if n == 0 {
				return nil
			}
			return roundTo(sum/float64(n), 2)
		}
		series["load1"] = append(series["load1"], pick(func(r metricRow) *float64 { return r.Load1 }))
		series["mem"] = append(series["mem"], pick(func(r metricRow) *float64 { return r.Mem }))
		series["disk"] = append(series["disk"], pick(func(r metricRow) *float64 { return r.Disk }))
		series["battery"] = append(series["battery"], pick(func(r metricRow) *float64 { return r.Battery }))
		series["temp"] = append(series["temp"], pick(func(r metricRow) *float64 { return r.Temp }))
	}
	out["t"] = ts
	for k, v := range series {
		out[k] = v
	}
	return out
}

type usageRow struct {
	T          int64    `json:"t"`
	Source     string   `json:"source"`
	Model      string   `json:"model"`
	Prompt     int      `json:"prompt"`
	Completion int      `json:"completion"`
	Cost       *float64 `json:"cost"`
	Note       string   `json:"note"`
}

// recordUsage — запись расхода одного обращения к модели. Стоимость nil, если провайдер её не вернул.
func recordUsage(home, source, model string, prompt, completion int, cost *float64, note string, now time.Time) error {
	if r := []rune(model); len(r) > 120 {
		model = string(r[:120])
	}
	if r := []rune(note); len(r) > 200 {
		note = string(r[:200])
	}
	row, err := json.Marshal(usageRow{T: now.Unix(), Source: source, Model: model, Prompt: prompt, Completion: completion, Cost: cost, Note: note})
	if err != nil {
		return err
	}
	var keep []json.RawMessage
	cutoff := now.Unix() - usageKeepDays*86400
	readJSONL(usageFile(home), func(line []byte) {
		var u usageRow
		if json.Unmarshal(line, &u) == nil && u.T >= cutoff {
			keep = append(keep, append(json.RawMessage(nil), line...))
		}
	})
	keep = append(keep, row)
	return writeJSONL(usageFile(home), keep)
}

// usageSummary — по дням (местное время): запросы, токены, стоимость и число запросов без известной стоимости.
func usageSummary(home string, days int, now time.Time) map[string]any {
	if days < 1 {
		days = 1
	}
	if days > 90 {
		days = 90
	}
	cutoff := now.Unix() - int64(days)*86400
	per := map[string]map[string]any{}
	var tot = map[string]any{"requests": 0, "prompt": 0, "completion": 0, "cost": 0.0, "cost_unknown": 0}
	readJSONL(usageFile(home), func(line []byte) {
		var u usageRow
		if json.Unmarshal(line, &u) != nil || u.T < cutoff {
			return
		}
		d := time.Unix(u.T, 0).Format("2006-01-02")
		x, ok := per[d]
		if !ok {
			x = map[string]any{"day": d, "requests": 0, "prompt": 0, "completion": 0, "cost": 0.0, "cost_unknown": 0}
			per[d] = x
		}
		x["requests"] = x["requests"].(int) + 1
		x["prompt"] = x["prompt"].(int) + u.Prompt
		x["completion"] = x["completion"].(int) + u.Completion
		if u.Cost == nil {
			x["cost_unknown"] = x["cost_unknown"].(int) + 1
		} else {
			x["cost"] = roundTo(x["cost"].(float64)+*u.Cost, 6)
		}
	})
	keys := make([]string, 0, len(per))
	for k := range per {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	items := []any{}
	for _, k := range keys {
		x := per[k]
		items = append(items, x)
		tot["requests"] = tot["requests"].(int) + x["requests"].(int)
		tot["prompt"] = tot["prompt"].(int) + x["prompt"].(int)
		tot["completion"] = tot["completion"].(int) + x["completion"].(int)
		tot["cost"] = roundTo(tot["cost"].(float64)+x["cost"].(float64), 6)
		tot["cost_unknown"] = tot["cost_unknown"].(int) + x["cost_unknown"].(int)
	}
	return map[string]any{"days": items, "total": tot}
}
