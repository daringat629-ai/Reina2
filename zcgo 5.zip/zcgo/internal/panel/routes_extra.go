package panel

// Маршруты истории, оповещений, копий, промптов, реакций и действий виджетов.

import (
	"path/filepath"
	"strconv"
	"time"

	"zcgo/internal/manager"
)

func backupsPayload(s *Server) map[string]any {
	return map[string]any{"backups": listBackups(s.M.Home), "auto": autoBackupSettings(s.M.Home), "kuni_dir": s.kuniDir()}
}

func queryFloat(query map[string][]string, key string, def float64) float64 {
	if v, ok := query[key]; ok && len(v) > 0 {
		if f, err := strconv.ParseFloat(v[0], 64); err == nil {
			return f
		}
	}
	return def
}

func queryValue(query map[string][]string, key, def string) string {
	if v, ok := query[key]; ok && len(v) > 0 && v[0] != "" {
		return v[0]
	}
	return def
}

// getExtra — маршруты GET, которые не входят в основной список. ok=false: маршрута нет.
func (s *Server) getExtra(r []string, query map[string][]string) (int, any, bool) {
	switch {
	case eq(r, "eco"):
		return 200, s.ecoPayload(), true
	case eq(r, "history"):
		hours := queryFloat(query, "hours", 24)
		return 200, historySeries(s.M.Home, hours, time.Now(), 240), true
	case eq(r, "usage"):
		days := int(queryFloat(query, "days", 14))
		return 200, usageSummary(s.M.Home, days, time.Now()), true
	case eq(r, "alerts"):
		return 200, alertsStatus(s.M.Home), true
	case eq(r, "assistant"):
		st := s.asst.state()
		st["audit"] = s.asst.auditTail(15)
		return 200, st, true
	case eq(r, "system", "doctor"):
		port := 8767
		if v, ok := query["port"]; ok && len(v) > 0 {
			if p, err := strconv.Atoi(v[0]); err == nil {
				port = p
			}
		}
		checks := s.doctor(s.kuniDir(), port)
		bad, warn := 0, 0
		out := make([]map[string]any, 0, len(checks))
		for _, c := range checks {
			switch c.Status {
			case "fail":
				bad++
			case "warn":
				warn++
			}
			out = append(out, map[string]any{"status": c.Status, "title": c.Title, "detail": c.Detail, "fix": c.Fix})
		}
		return 200, map[string]any{"checks": out, "bad": bad, "warn": warn}, true
	case eq(r, "available"):
		return 200, s.availableParts(), true
	case eq(r, "templates"):
		return 200, templates, true
	case len(r) == 3 && r[0] == "modules" && r[2] == "config":
		out, err := s.configGet(r[1])
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case len(r) == 2 && r[0] == "secrets":
		if _, ok := s.installed()[r[1]]; !ok {
			return 400, map[string]any{"error": r[1] + ": не установлена"}, true
		}
		return 200, map[string]any{"names": manager.SecretNames(s.M.Home, r[1])}, true
	case eq(r, "backups"):
		return 200, backupsPayload(s), true
	case eq(r, "prompts"):
		files, err := listPrompts(s.kuniDir(), s.M.Home)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, map[string]any{"files": files}, true
	case len(r) == 2 && r[0] == "prompts":
		out, err := readPrompt(s.kuniDir(), s.M.Home, r[1])
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case len(r) == 3 && r[0] == "prompts" && r[2] == "diff":
		out, err := diffPrompts(s.kuniDir(), s.M.Home, r[1], queryValue(query, "a", "current"), queryValue(query, "b", "current"))
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	}
	return 0, nil, false
}

// postExtra — маршруты POST, которые не входят в основной список.
func (s *Server) postExtra(r []string, body map[string]any) (int, any, bool) {
	home := s.M.Home
	switch {
	case eq(r, "eco", "set"):
		out, err := s.ecoSet(body)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case eq(r, "alerts"):
		out, err := saveAlerts(home, body)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case eq(r, "alerts", "token"):
		tok, _ := body["token"].(string)
		out, err := setAlertToken(home, tok)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case eq(r, "alerts", "test"):
		if err := sendTelegram(home, "Проверка оповещений из панели «Нулевое ядро»: всё работает."); err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, map[string]any{"ok": true}, true
	case eq(r, "backups"):
		note, _ := body["note"].(string)
		res, err := createBackup(home, s.kuniDir(), note, time.Now())
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		_ = res
		return 200, backupsPayload(s), true
	case eq(r, "backups", "auto"):
		if _, err := setAutoBackup(home, body); err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, backupsPayload(s), true
	case len(r) == 3 && r[0] == "backups" && r[2] == "restore":
		if c, _ := body["confirm"].(bool); !c {
			return 400, map[string]any{"error": "восстановление заменяет файлы: передайте confirm: true"}, true
		}
		out, err := restoreBackup(home, r[1], s.kuniDir(), time.Now())
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		s.M.RefreshExtensions()
		for k, v := range backupsPayload(s) {
			out[k] = v
		}
		return 200, out, true
	case len(r) == 3 && r[0] == "backups" && r[2] == "delete":
		if err := deleteBackup(home, r[1]); err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, backupsPayload(s), true
	case len(r) == 2 && r[0] == "prompts":
		note, _ := body["note"].(string)
		text, _ := body["text"].(string)
		out, err := savePrompt(s.kuniDir(), home, r[1], text, note, time.Now())
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case len(r) == 3 && r[0] == "prompts" && r[2] == "restore":
		id, _ := body["id"].(string)
		out, err := restorePrompt(s.kuniDir(), home, r[1], id, time.Now())
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case eq(r, "assistant", "message"):
		text, _ := body["text"].(string)
		out, err := s.asst.message(text)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case eq(r, "assistant", "confirm"):
		id, _ := body["id"].(string)
		approve, _ := body["approve"].(bool)
		out, err := s.asst.confirm(id, approve)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case eq(r, "assistant", "stop"):
		s.asst.stop()
		return 200, map[string]any{"ok": true}, true
	case eq(r, "assistant", "reset"):
		if err := s.asst.reset(); err != nil {
			return 500, map[string]any{"error": err.Error()}, true
		}
		return 200, s.asst.state(), true
	case eq(r, "assistant", "settings"):
		if _, err := s.asst.setSettings(body); err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, s.asst.state(), true
	case eq(r, "wire-kuni"):
		kd := detectKuniDir(s.kuniDir())
		if kd == "" {
			return 400, map[string]any{"error": "каталог бота не найден: задайте kuni_dir в настройках модуля kuni"}, true
		}
		if _, err := s.M.ExportTools(); err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		status, err := wireKuniCatalog(filepath.Join(kd, "config.toml"), s.M.ToolsPath())
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, map[string]any{"result": status, "config": filepath.Join(kd, "config.toml")}, true
	case eq(r, "available", "install"):
		name, _ := body["name"].(string)
		out, err := s.installAvailable(name)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case len(r) == 3 && r[0] == "modules" && r[2] == "config":
		out, err := s.configSet(r[1], body)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case len(r) == 3 && r[0] == "modules" && r[2] == "trust":
		out, err := s.setTrust(r[1], body)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case len(r) == 3 && r[0] == "modules" && r[2] == "uninstall":
		out, err := s.uninstallPart(r[1], body)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, out, true
	case len(r) == 3 && r[0] == "modules" && r[2] == "rollback":
		from, to, err := s.M.Rollback(r[1])
		if err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, map[string]any{"from": from, "to": to}, true
	case len(r) == 2 && r[0] == "secrets":
		if _, ok := s.installed()[r[1]]; !ok {
			return 400, map[string]any{"error": r[1] + ": не установлена"}, true
		}
		if r[1] == "kuni" {
			return 400, map[string]any{"error": "для бота секреты здесь не задаются"}, true
		}
		name, _ := body["name"].(string)
		value, _ := body["value"].(string)
		if _, err := manager.SetSecret(s.M.Home, r[1], name, value); err != nil {
			return 400, map[string]any{"error": err.Error()}, true
		}
		return 200, map[string]any{"names": manager.SecretNames(s.M.Home, r[1])}, true
	case len(r) == 4 && r[0] == "hooks" && r[3] == "resume":
		if !s.hooks.Resume(r[1], r[2]) {
			return 400, map[string]any{"error": "эта реакция не приостановлена"}, true
		}
		return 200, map[string]any{"ok": true, "hooks": s.hooks.Status()}, true
	}
	return 0, nil, false
}

// widgetAction — POST /api/widget/<модуль>/<виджет>/action/<действие>.
func (s *Server) widgetAction(r []string) (int, any, bool) {
	if len(r) != 5 || r[0] != "widget" || r[3] != "action" {
		return 0, nil, false
	}
	out, err := s.runWidget(r[1], r[2], r[4])
	if err != nil {
		return 404, map[string]any{"error": err.Error()}, true
	}
	return 200, out, true
}
