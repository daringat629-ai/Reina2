package panel

// Клиент модели (формат chat/completions с вызовом инструментов): та же модель и тот же ключ, что у бота.
// Ключ читается из config.toml бота и никогда не выводится: ни в ответах, ни в ошибках.
// Для проверок можно задать ZEROCORE_LLM_URL, ZEROCORE_LLM_KEY, ZEROCORE_LLM_MODEL (они важнее config.toml).

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type llmCreds struct {
	URL, Key, Model string
}

var errLLM = errors.New("")

// llmCredentials — адрес, ключ и модель: из окружения или из config.toml бота.
func llmCredentials(kuniDir string) (llmCreds, error) {
	u, key, model := os.Getenv("ZEROCORE_LLM_URL"), os.Getenv("ZEROCORE_LLM_KEY"), os.Getenv("ZEROCORE_LLM_MODEL")
	if u == "" || key == "" || model == "" {
		raw, err := os.ReadFile(filepath.Join(kuniDir, "config.toml"))
		if err == nil {
			g, _ := parseTOML(string(raw))["general"].(map[string]any)
			llm, _ := g["llm"].(map[string]any)
			ep, _ := llm["endpoint"].(map[string]any)
			if u == "" {
				u = toStr(ep["baseUrl"])
			}
			if key == "" {
				key = toStr(ep["bearerKey"])
			}
			if model == "" {
				model = toStr(llm["model"])
			}
		}
	}
	if u == "" || key == "" || model == "" || strings.HasPrefix(model, "YOUR_") {
		return llmCreds{}, errors.New("настройки модели не найдены: в config.toml бота нужны general.llm (baseUrl, bearerKey, model)")
	}
	return llmCreds{URL: strings.TrimRight(u, "/"), Key: key, Model: model}, nil
}

// llmAvailable — доступна ли модель (без вывода ключа).
func llmAvailable(kuniDir string) map[string]any {
	c, err := llmCredentials(kuniDir)
	if err != nil {
		return map[string]any{"available": false, "error": err.Error()}
	}
	host := ""
	if pu, err := url.Parse(c.URL); err == nil {
		host = pu.Hostname()
	}
	return map[string]any{"available": true, "model": c.Model, "host": host}
}

type llmReply struct {
	Message map[string]any
	Model   string
	Prompt  int
	Compl   int
	Cost    any
}

// llmComplete — один запрос к модели.
func llmComplete(c llmCreds, messages []map[string]any, tools []any) (llmReply, error) {
	body := map[string]any{"model": c.Model, "messages": messages, "temperature": 0.7, "max_tokens": 1500}
	if len(tools) > 0 {
		body["tools"] = tools
		body["tool_choice"] = "auto"
	}
	if strings.Contains(c.URL, "openrouter") {
		body["usage"] = map[string]any{"include": true}
	}
	raw, err := json.Marshal(body)
	if err != nil {
		return llmReply{}, err
	}
	req, err := http.NewRequest("POST", c.URL+"/chat/completions", bytes.NewReader(raw))
	if err != nil {
		return llmReply{}, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+c.Key)
	req.Header.Set("User-Agent", "zerocore-panel/1.0")
	client := &http.Client{Timeout: 90 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return llmReply{}, fmt.Errorf("нет связи с моделью: %s", strings.ReplaceAll(err.Error(), c.Key, "***"))
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(io.LimitReader(resp.Body, 10<<20))
	if resp.StatusCode != 200 {
		detail := string(data)
		if len(detail) > 300 {
			detail = detail[:300]
		}
		return llmReply{}, fmt.Errorf("модель ответила %d: %s", resp.StatusCode, strings.ReplaceAll(detail, c.Key, "***"))
	}
	var parsed struct {
		Model   string `json:"model"`
		Choices []struct {
			Message map[string]any `json:"message"`
		} `json:"choices"`
		Usage map[string]any `json:"usage"`
	}
	if err := json.Unmarshal(data, &parsed); err != nil {
		return llmReply{}, errors.New("модель вернула не JSON")
	}
	if len(parsed.Choices) == 0 || parsed.Choices[0].Message == nil {
		return llmReply{}, errors.New("в ответе модели нет сообщения")
	}
	model := parsed.Model
	if model == "" {
		model = c.Model
	}
	r := llmReply{Message: parsed.Choices[0].Message, Model: model, Cost: parsed.Usage["cost"]}
	r.Prompt = intOf(parsed.Usage["prompt_tokens"])
	r.Compl = intOf(parsed.Usage["completion_tokens"])
	return r, nil
}

func intOf(v any) int {
	f, _ := v.(float64)
	return int(f)
}
