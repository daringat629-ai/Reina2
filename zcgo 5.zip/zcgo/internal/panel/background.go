package panel

// Фоновая работа панели: опрос событий для реакций деталей (каждые 3 с), раз в минуту —
// история метрик, проверка оповещений и автоматическая копия. Каждая часть защищена: сбой одной не останавливает остальные.

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"syscall"
	"time"
)

const (
	hookPollInterval = 3 * time.Second
	backgroundEvery  = time.Minute
)

// hookEvents отдаёт события бота и менеджера для реакций (тот же источник, что у схемы «Архитектура»).
func (s *Server) hookEvents(since float64) []map[string]any {
	now := float64(time.Now().UnixNano()) / 1e9
	from := since
	if from < now-300 {
		from = now - 300
	}
	if from > now {
		from = now
	}
	logs, _, console := s.kuniPaths()
	res := collectActivity(s.busRecent(100), logs, console, from, now)
	raw, _ := json.Marshal(res["events"])
	var out []map[string]any
	_ = json.Unmarshal(raw, &out)
	return out
}

// recentErrorCount — сколько ошибок бота за последние 10 минут.
func (s *Server) recentErrorCount(now float64) int {
	logs, _, console := s.kuniPaths()
	res := collectActivity(s.busRecent(100), logs, console, now-600, now)
	n := 0
	for _, e := range res["events"].([]actEvent) {
		if e.Level == "error" {
			n++
		}
	}
	return n
}

// diskUsedPercent — занято места на корневом разделе, %.
func diskUsedPercent() (float64, bool) {
	var st syscall.Statfs_t
	if err := syscall.Statfs("/", &st); err != nil || st.Blocks == 0 {
		return 0, false
	}
	total := float64(st.Blocks) * float64(st.Bsize)
	return 100 * (total - float64(st.Bfree)*float64(st.Bsize)) / total, true
}

// backgroundStep — один проход фоновой работы.
func (s *Server) backgroundStep(now time.Time) map[string]any {
	done := map[string]any{}
	if err := sampleHistory(s.M.Home, now, readHost); err != nil {
		done["history"] = err.Error()
	} else {
		done["history"] = true
	}
	ts := float64(now.UnixNano()) / 1e9
	sent := checkAlerts(s.M, ts, sendTelegram, func() int { return s.recentErrorCount(ts) }, diskUsedPercent)
	done["alerts"] = sent
	a := autoBackupSettings(s.M.Home)
	if a["enabled"] == true && backupDue(s.M.Home, a["hours"].(int), now) {
		res, err := createBackup(s.M.Home, s.kuniDir(), "автоматическая", now)
		if err != nil {
			done["backup"] = err.Error()
			notifyAlert(s.M.Home, "backup", "Автоматическая резервная копия не удалась: "+err.Error(), ts, sendTelegram)
		} else {
			done["backup"] = res["name"]
			pruneBackups(s.M.Home, a["keep"].(int))
		}
	}
	return done
}

// StartBackground запускает опрос реакций, фоновый цикл и замеры нагрузки.
func (s *Server) StartBackground() {
	s.bgMu.Lock()
	defer s.bgMu.Unlock()
	if s.bgStop != nil {
		return
	}
	s.bgStop = make(chan struct{})
	s.sampler.Start()
	stop := s.bgStop
	go func() {
		t := time.NewTicker(hookPollInterval)
		defer t.Stop()
		for {
			select {
			case <-stop:
				return
			case <-t.C:
				_ = s.hooks.Poll()
			}
		}
	}()
	go func() {
		t := time.NewTicker(backgroundEvery)
		defer t.Stop()
		for {
			select {
			case <-stop:
				return
			case now := <-t.C:
				_ = s.backgroundStep(now)
			}
		}
	}()
}

// StopBackground останавливает фоновую работу.
func (s *Server) StopBackground() {
	s.bgMu.Lock()
	defer s.bgMu.Unlock()
	if s.bgStop != nil {
		close(s.bgStop)
		s.bgStop = nil
	}
	s.sampler.Stop()
}

// kuniDir — каталог бота: из настроек модуля kuni или переменной ZEROCORE_KUNI_DIR.
func (s *Server) kuniDir() string {
	cfg, err := s.M.Config("kuni", "")
	if err != nil {
		cfg = map[string]any{}
	}
	if v := os.Getenv("ZEROCORE_KUNI_DIR"); v != "" {
		return v
	}
	return toStr(cfg["kuni_dir"])
}

func autoBackupPath(home string) string { return filepath.Join(home, "backup_auto.json") }

// autoBackupSettings — настройки автоматических копий: enabled, hours (1..720), keep (1..100).
func autoBackupSettings(home string) map[string]any {
	s := map[string]any{"enabled": false, "hours": 24, "keep": 10}
	if raw, err := os.ReadFile(autoBackupPath(home)); err == nil {
		var d map[string]any
		if json.Unmarshal(raw, &d) == nil {
			if v, ok := d["enabled"].(bool); ok {
				s["enabled"] = v
			}
			for _, k := range []string{"hours", "keep"} {
				if f, ok := d[k].(float64); ok {
					s[k] = int(f)
				}
			}
		}
	}
	return s
}

func setAutoBackup(home string, patch map[string]any) (map[string]any, error) {
	s := autoBackupSettings(home)
	if v, ok := patch["enabled"]; ok {
		b, ok := v.(bool)
		if !ok {
			return nil, errors.New("enabled: true или false")
		}
		s["enabled"] = b
	}
	for _, kb := range []struct {
		key    string
		lo, hi int
	}{{"hours", 1, 720}, {"keep", 1, 100}} {
		v, ok := patch[kb.key]
		if !ok {
			continue
		}
		n, ok := asInt(v)
		if !ok {
			return nil, errors.New(kb.key + ": целое число")
		}
		if n < kb.lo || n > kb.hi {
			return nil, errors.New(kb.key + ": от " + strconv.Itoa(kb.lo) + " до " + strconv.Itoa(kb.hi))
		}
		s[kb.key] = n
	}
	raw, _ := json.Marshal(s)
	if err := writeFileAtomic(autoBackupPath(home), raw, 0o644); err != nil {
		return nil, err
	}
	return s, nil
}
