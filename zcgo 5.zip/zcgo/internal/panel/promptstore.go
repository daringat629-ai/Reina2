package panel

// Редактор промптов бота: правка файлов <kuni>/prompts с историей версий, сравнением и откатом.
// Прежняя версия при каждом сохранении уходит в <дом>/prompt_history/<файл>/<время>.txt.
// Блоки, которые вставляет ядро (zerocore:begin ... end), менять нельзя: их ведут патчи деталей.

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"

	"zcgo/internal/manager"
)

var (
	promptNameRE = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]{0,60}\.(md|txt)$`)
	versionRE    = regexp.MustCompile(`^[0-9]{8}-[0-9]{6}(-[0-9]+)?$`)
	sidRE        = regexp.MustCompile(`^[0-9]{8}-[0-9]{6}(-[0-9]+)?$`)
)

const (
	promptMaxBytes = 200_000
	promptKeep     = 200
)

func promptsDir(kuniDir string) (string, error) {
	if kuniDir == "" {
		return "", errors.New("каталог бота не найден: задайте kuni_dir в настройках модуля kuni")
	}
	d := filepath.Join(kuniDir, "prompts")
	if st, err := os.Stat(d); err != nil || !st.IsDir() {
		return "", fmt.Errorf("нет папки промптов %s", d)
	}
	return d, nil
}

func promptPath(kuniDir, name string) (string, error) {
	if !promptNameRE.MatchString(name) {
		return "", errors.New("имя файла: латиница, цифры, _ . -, расширение md или txt")
	}
	d, err := promptsDir(kuniDir)
	if err != nil {
		return "", err
	}
	return filepath.Join(d, name), nil
}

func promptHistoryDir(home, name string) string {
	return filepath.Join(home, "prompt_history", name)
}

func blockTexts(text string) []string {
	_, bl := manager.SplitBlocks(text)
	out := make([]string, 0, len(bl))
	for _, b := range bl {
		out = append(out, b.Text)
	}
	return out
}

func sameStrings(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func listPrompts(kuniDir, home string) ([]map[string]any, error) {
	d, err := promptsDir(kuniDir)
	if err != nil {
		return nil, err
	}
	entries, err := os.ReadDir(d)
	if err != nil {
		return nil, err
	}
	out := []map[string]any{}
	for _, e := range entries {
		if e.IsDir() || !promptNameRE.MatchString(e.Name()) {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		raw, _ := os.ReadFile(filepath.Join(d, e.Name()))
		versions := 0
		if hs, err := os.ReadDir(promptHistoryDir(home, e.Name())); err == nil {
			for _, h := range hs {
				if strings.HasSuffix(h.Name(), ".json") {
					versions++
				}
			}
		}
		out = append(out, map[string]any{"name": e.Name(), "size": info.Size(), "mtime": info.ModTime().Unix(),
			"versions": versions, "blocks": len(blockTexts(string(raw)))})
	}
	return out, nil
}

func promptHistoryList(home, name string) []map[string]any {
	out := []map[string]any{}
	entries, err := os.ReadDir(promptHistoryDir(home, name))
	if err != nil {
		return out
	}
	var ids []string
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".json") {
			ids = append(ids, strings.TrimSuffix(e.Name(), ".json"))
		}
	}
	sort.Sort(sort.Reverse(sort.StringSlice(ids)))
	for _, id := range ids {
		raw, err := os.ReadFile(filepath.Join(promptHistoryDir(home, name), id+".json"))
		if err != nil {
			continue
		}
		var m struct {
			At   int64  `json:"at"`
			Note string `json:"note"`
			Size int    `json:"size"`
		}
		if json.Unmarshal(raw, &m) != nil {
			continue
		}
		out = append(out, map[string]any{"id": id, "at": m.At, "note": m.Note, "size": m.Size})
	}
	return out
}

func readPrompt(kuniDir, home, name string) (map[string]any, error) {
	p, err := promptPath(kuniDir, name)
	if err != nil {
		return nil, err
	}
	raw, err := os.ReadFile(p)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, fmt.Errorf("файла %s нет", name)
		}
		return nil, err
	}
	if !isUTF8(raw) {
		return nil, fmt.Errorf("%s: файл не в кодировке UTF-8", name)
	}
	text := string(raw)
	_, bl := manager.SplitBlocks(text)
	blocks := make([]map[string]any, 0, len(bl))
	for _, b := range bl {
		blocks = append(blocks, map[string]any{"module": b.Module, "patch": b.Patch})
	}
	return map[string]any{"name": name, "text": text, "history": promptHistoryList(home, name), "blocks": blocks}, nil
}

func isUTF8(b []byte) bool {
	return strings.ToValidUTF8(string(b), "�") == string(b) || validUTF8(b)
}

func validUTF8(b []byte) bool {
	return utf8Valid(b)
}

func snapshotPrompt(home, name, text, note string, now time.Time) (string, error) {
	d := promptHistoryDir(home, name)
	if err := os.MkdirAll(d, 0o755); err != nil {
		return "", err
	}
	base := now.Format("20060102-150405")
	sid := base
	for n := 1; ; n++ {
		if _, err := os.Stat(filepath.Join(d, sid+".json")); os.IsNotExist(err) {
			break
		}
		sid = fmt.Sprintf("%s-%d", base, n)
	}
	if err := writeFileAtomic(filepath.Join(d, sid+".txt"), []byte(text), 0o644); err != nil {
		return "", err
	}
	meta, _ := json.Marshal(map[string]any{"at": now.Unix(), "note": truncRunes(note, 200), "size": len(text)})
	if err := writeFileAtomic(filepath.Join(d, sid+".json"), meta, 0o644); err != nil {
		return "", err
	}
	ids := []string{}
	entries, _ := os.ReadDir(d)
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".json") {
			ids = append(ids, strings.TrimSuffix(e.Name(), ".json"))
		}
	}
	sort.Strings(ids)
	for i := 0; i < len(ids)-promptKeep; i++ {
		_ = os.Remove(filepath.Join(d, ids[i]+".json"))
		_ = os.Remove(filepath.Join(d, ids[i]+".txt"))
	}
	return sid, nil
}

func savePrompt(kuniDir, home, name, text, note string, now time.Time) (map[string]any, error) {
	if len(text) > promptMaxBytes {
		return nil, fmt.Errorf("текст: строка до %d КБ", promptMaxBytes/1000)
	}
	if strings.ContainsRune(text, 0) {
		return nil, errors.New("в тексте есть нулевые символы")
	}
	p, err := promptPath(kuniDir, name)
	if err != nil {
		return nil, err
	}
	var old string
	if raw, err := os.ReadFile(p); err == nil {
		old = string(raw)
	}
	if !sameStrings(blockTexts(old), blockTexts(text)) {
		return nil, errors.New("правка затрагивает блоки, которые ведёт ядро (zerocore:begin ... zerocore:end): их нельзя менять или удалять; правьте текст вокруг них")
	}
	if text == old {
		return nil, errors.New("текст не изменился")
	}
	var sid any
	if old != "" {
		s, err := snapshotPrompt(home, name, old, orDefault(note, "перед правкой"), now)
		if err != nil {
			return nil, err
		}
		sid = s
	}
	if err := writeFileAtomic(p, []byte(text), 0o644); err != nil {
		return nil, err
	}
	return map[string]any{"saved": name, "previous": sid}, nil
}

func orDefault(v, def string) string {
	if v == "" {
		return def
	}
	return v
}

func promptVersionText(kuniDir, home, name, v string) (string, error) {
	if v == "current" {
		p, err := promptPath(kuniDir, name)
		if err != nil {
			return "", err
		}
		raw, err := os.ReadFile(p)
		if err != nil {
			return "", fmt.Errorf("файла %s нет", name)
		}
		return string(raw), nil
	}
	if !versionRE.MatchString(v) {
		return "", errors.New("версия указана неверно")
	}
	raw, err := os.ReadFile(filepath.Join(promptHistoryDir(home, name), v+".txt"))
	if err != nil {
		return "", fmt.Errorf("версии %s нет", v)
	}
	return string(raw), nil
}

func diffPrompts(kuniDir, home, name, a, b string) (map[string]any, error) {
	ta, err := promptVersionText(kuniDir, home, name, a)
	if err != nil {
		return nil, err
	}
	tb, err := promptVersionText(kuniDir, home, name, b)
	if err != nil {
		return nil, err
	}
	text, added, removed := unifiedDiff(a, b, ta, tb)
	return map[string]any{"diff": text, "added": added, "removed": removed}, nil
}

// restorePrompt возвращает версию из истории. Блоки ядра остаются текущими, меняется только текст вокруг них.
func restorePrompt(kuniDir, home, name, version string, now time.Time) (map[string]any, error) {
	if !versionRE.MatchString(version) {
		return nil, errors.New("версия указана неверно")
	}
	old, err := promptVersionText(kuniDir, home, name, version)
	if err != nil {
		return nil, err
	}
	p, err := promptPath(kuniDir, name)
	if err != nil {
		return nil, err
	}
	var cur string
	if raw, err := os.ReadFile(p); err == nil {
		cur = string(raw)
	}
	if !sameStrings(blockTexts(cur), blockTexts(old)) {
		old = mergePromptBlocks(cur, old)
	}
	return savePrompt(kuniDir, home, name, old, "перед возвратом к "+version, now)
}

// mergePromptBlocks: текст вокруг блоков берётся из старой версии, блоки из текущей.
func mergePromptBlocks(current, old string) string {
	plain, _ := manager.SplitBlocks(old)
	curBlocks := blockTexts(current)
	if len(curBlocks) == 0 {
		return plain
	}
	var b strings.Builder
	b.WriteString(strings.TrimRight(plain, "\n"))
	b.WriteString("\n")
	for _, blk := range curBlocks {
		if strings.HasPrefix(blk, "\n") {
			b.WriteString(blk)
		} else {
			b.WriteString("\n" + blk)
		}
	}
	return b.String()
}
