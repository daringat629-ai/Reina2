// Package panel — HTTP-панель «Нулевое ядро» на стандартной библиотеке.
// Слушает 127.0.0.1; данные API закрыты токеном, статика открыта. Перенесена часть API;
// остальные маршруты отвечают 501, пока их логика не перенесена (см. README).
package panel

import (
	"crypto/rand"
	"crypto/subtle"
	"embed"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"zcgo/internal/kernel"
	"zcgo/internal/manager"
)

// kuniPaths — каталоги бота: логи, config.toml и консольный журнал (из настроек модуля kuni).
func (s *Server) kuniPaths() (logs, toml, console string) {
	cfg, err := s.M.Config("kuni", "")
	if err != nil {
		cfg = map[string]any{}
	}
	base := os.Getenv("ZEROCORE_KUNI_DIR")
	if base == "" {
		base = toStr(cfg["kuni_dir"])
	}
	if base != "" {
		logs = filepath.Join(base, "logs")
		toml = filepath.Join(base, "config.toml")
	}
	glob := toStr(cfg["console_log_glob"])
	if glob == "" {
		glob = "/tmp/aui.*.log"
	}
	console = newestFile(glob)
	return logs, toml, console
}

// busRecent — последние n событий шины ядра.
func (s *Server) busRecent(n int) []kernel.Event {
	events, err := kernel.NewEventBus(s.M.Home).Recent(n)
	if err != nil {
		return nil
	}
	return events
}

// loggedLines — число строк журнала из запроса (10..2000), по умолчанию из настроек.
func loggedLines(query map[string][]string, s *Server) int {
	n := 200
	if v, ok := loadSettings(s.M.Home)["log_lines"].(float64); ok {
		n = int(v)
	}
	if v, ok := query["n"]; ok && len(v) > 0 {
		if x, err := strconv.Atoi(v[0]); err == nil {
			n = x
		}
	}
	return min(max(n, 10), 2000)
}

//go:embed web
var webFS embed.FS

// Version — версия ядра, как в Python-панели (zerocore/__init__.py).
const Version = "0.1.0"

const maxBody = 100_000

var (
	moduleRE = regexp.MustCompile(`^[a-z][a-z0-9_]{1,31}$`)
	transRE  = regexp.MustCompile(`^(telegram|transport)\.`)
	actions  = map[string]bool{"enable": true, "disable": true, "start": true, "stop": true, "restart": true}
	static   = map[string]struct{ file, ctype string }{
		"/":                          {"index.html", "text/html; charset=utf-8"},
		"/index.html":                {"index.html", "text/html; charset=utf-8"},
		"/app.js":                    {"app.js", "text/javascript; charset=utf-8"},
		"/layout.js":                 {"layout.js", "text/javascript; charset=utf-8"},
		"/style.css":                 {"style.css", "text/css; charset=utf-8"},
		"/fonts/zcmono-regular.woff": {"fonts/zcmono-regular.woff", "font/woff"},
		"/fonts/zcmono-bold.woff":    {"fonts/zcmono-bold.woff", "font/woff"},
	}
)

const csp = "default-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"

// Server — состояние панели.
type Server struct {
	M       *manager.Manager
	started time.Time
	mu      sync.RWMutex
	token   string
	sampler *MetricsSampler
	hooks   *manager.HookRunner
	asst    *assistantState
	listen  int
	bgMu    sync.Mutex
	bgStop  chan struct{}
}

// New создаёт панель. Токен: ZEROCORE_PANEL_TOKEN или файл panel_token в home (права 0600).
func New(m *manager.Manager) (*Server, error) {
	tok, err := loadOrCreateToken(m.Home)
	if err != nil {
		return nil, err
	}
	srv := &Server{M: m, started: time.Now(), token: tok, sampler: NewMetricsSampler("kuni")}
	srv.hooks = manager.NewHookRunner(m, srv.hookEvents, nil, nil)
	srv.asst = newAssistant(srv)
	return srv, nil
}

func tokenPath(home string) string { return filepath.Join(home, "panel_token") }

func loadOrCreateToken(home string) (string, error) {
	if env := os.Getenv("ZEROCORE_PANEL_TOKEN"); env != "" {
		return env, nil
	}
	path := tokenPath(home)
	if raw, err := os.ReadFile(path); err == nil && len(strings.TrimSpace(string(raw))) > 0 {
		return strings.TrimSpace(string(raw)), nil
	}
	return writeNewToken(home)
}

func writeNewToken(home string) (string, error) {
	buf := make([]byte, 24)
	if _, err := rand.Read(buf); err != nil {
		return "", err
	}
	tok := base64.RawURLEncoding.EncodeToString(buf)
	if err := kernel.AtomicWrite(tokenPath(home), []byte(tok+"\n"), 0o600); err != nil {
		return "", err
	}
	return tok, nil
}

func (s *Server) currentToken() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.token
}

// Handler — маршрутизатор панели.
func (s *Server) Handler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if rec := recover(); rec != nil {
				fmt.Fprintf(os.Stderr, "panel: паника: %v\n", rec)
				sendJSON(w, 500, map[string]any{"error": "внутренняя ошибка панели"})
			}
		}()
		if st, ok := static[r.URL.Path]; ok {
			if r.Method != http.MethodGet && r.Method != http.MethodHead {
				sendJSON(w, 405, map[string]any{"error": "метод не разрешён"})
				return
			}
			s.serveStatic(w, st.file, st.ctype)
			return
		}
		if strings.HasPrefix(r.URL.Path, "/api/") {
			s.api(w, r)
			return
		}
		sendJSON(w, 404, map[string]any{"error": "not found"})
	})
}

func (s *Server) serveStatic(w http.ResponseWriter, file, ctype string) {
	data, err := webFS.ReadFile("web/" + file)
	if err != nil {
		sendJSON(w, 404, map[string]any{"error": "not found"})
		return
	}
	extra := map[string]string{}
	if strings.HasPrefix(ctype, "font/") {
		extra["Cache-Control"] = "public, max-age=604800"
	}
	writeBytes(w, 200, data, ctype, extra)
}

func writeBytes(w http.ResponseWriter, code int, data []byte, ctype string, extra map[string]string) {
	h := w.Header()
	h.Set("Content-Type", ctype)
	if _, ok := extra["Cache-Control"]; !ok {
		h.Set("Cache-Control", "no-store")
	}
	h.Set("X-Content-Type-Options", "nosniff")
	h.Set("Content-Security-Policy", csp)
	for k, v := range extra {
		h.Set(k, v)
	}
	h.Set("Content-Length", fmt.Sprint(len(data)))
	w.WriteHeader(code)
	_, _ = w.Write(data)
}

func sendJSON(w http.ResponseWriter, code int, payload any) {
	data, err := json.Marshal(payload)
	if err != nil {
		data = []byte(`{"error":"ошибка кодирования"}`)
		code = 500
	}
	writeBytes(w, code, data, "application/json; charset=utf-8", nil)
}

var packRE = regexp.MustCompile(`^/api/modules/([a-z][a-z0-9_]{1,31})/pack$`)

func (s *Server) api(w http.ResponseWriter, r *http.Request) {
	got := r.Header.Get("X-Token")
	if subtle.ConstantTimeCompare([]byte(got), []byte(s.currentToken())) != 1 {
		sendJSON(w, 401, map[string]any{"error": "нужен токен"})
		return
	}
	if m := packRE.FindStringSubmatch(r.URL.Path); m != nil && r.Method == http.MethodGet {
		fname, data, err := packPart(s.M, m[1])
		if err != nil {
			sendJSON(w, 404, map[string]any{"error": err.Error()})
			return
		}
		writeBytes(w, 200, data, "application/zip", map[string]string{"Content-Disposition": `attachment; filename="` + fname + `"`})
		return
	}
	if r.URL.Path == "/api/modules/upload" && r.Method == http.MethodPost {
		if r.ContentLength > maxUpload {
			r.Close = true
			sendJSON(w, 413, map[string]any{"error": "файл больше " + strconv.Itoa(maxUpload/1048576) + " МБ"})
			return
		}
		data, err := io.ReadAll(io.LimitReader(r.Body, maxUpload+1))
		if err != nil {
			sendJSON(w, 400, map[string]any{"error": "тело запроса не читается"})
			return
		}
		out, err := s.uploadPart(data)
		if err != nil {
			sendJSON(w, 400, map[string]any{"error": err.Error()})
			return
		}
		sendJSON(w, 200, out)
		return
	}
	var body any
	if r.Method == http.MethodPost {
		if r.ContentLength > maxBody {
			sendJSON(w, 413, map[string]any{"error": "слишком большой запрос"})
			return
		}
		raw, err := io.ReadAll(io.LimitReader(r.Body, maxBody+1))
		if err != nil {
			sendJSON(w, 400, map[string]any{"error": "тело запроса не читается"})
			return
		}
		body = map[string]any{}
		if len(strings.TrimSpace(string(raw))) > 0 {
			if err := json.Unmarshal(raw, &body); err != nil {
				sendJSON(w, 400, map[string]any{"error": "тело запроса не JSON"})
				return
			}
		}
	}
	code, payload := s.Handle(r.Method, r.URL.Path, r.URL.Query(), body)
	sendJSON(w, code, payload)
}

// Handle возвращает код и объект ответа. Без HTTP, поэтому тестируется напрямую.
func (s *Server) Handle(method, path string, query map[string][]string, body any) (int, any) {
	parts := strings.Split(strings.Trim(path, "/"), "/")
	if len(parts) == 0 || parts[0] != "api" {
		return 404, map[string]any{"error": "not found"}
	}
	r := parts[1:]
	switch method {
	case http.MethodGet:
		return s.get(r, query)
	case http.MethodPost:
		return s.post(r, body)
	}
	return 405, map[string]any{"error": "метод не разрешён"}
}

func notPorted(path string) (int, any) {
	return 501, map[string]any{"error": "пока не перенесено в Go-ядро: " + path}
}

func (s *Server) get(r []string, query map[string][]string) (int, any) {
	switch {
	case eq(r, "system"):
		return 200, map[string]any{"zerocore": Version, "runtime": "go " + runtime.Version(), "os": runtime.GOOS + " (" + runtime.GOARCH + ")",
			"pid": os.Getpid(), "home": s.M.Home, "uptime": int(time.Since(s.started).Seconds()),
			"modules": len(s.installed()), "enabled": len(s.M.EnabledNames()), "integrity": s.M.CheckIntegrity(), "host": hostMetrics()}
	case eq(r, "activity"):
		now := float64(time.Now().UnixNano()) / 1e9
		since := now - 3
		if v, ok := query["since"]; ok && len(v) > 0 {
			if f, err := strconv.ParseFloat(v[0], 64); err == nil {
				since = f
			}
		}
		since = math.Min(math.Max(since, now-300), now)
		logs, _, console := s.kuniPaths()
		events := s.busRecent(100)
		return 200, collectActivity(events, logs, console, since, now)
	case eq(r, "architecture"):
		_, toml, _ := s.kuniPaths()
		return 200, buildArchitecture(s.M, len(s.busRecent(1000)), toml)
	case eq(r, "log"):
		n := loggedLines(query, s)
		_, _, console := s.kuniPaths()
		return 200, liveLog(s.busRecent(n), console, n, time.Now())
	case eq(r, "stats"):
		logs, _, console := s.kuniPaths()
		return 200, stats(logs, console, time.Now())
	case eq(r, "tools"):
		logs, _, _ := s.kuniPaths()
		if logs == "" {
			return 200, []map[string]any{}
		}
		return 200, toolsFromQuery(logs, 120)
	case eq(r, "generation"):
		logs, _, _ := s.kuniPaths()
		if logs == "" {
			return 200, map[string]any{"known": false}
		}
		return 200, generationState(logs, time.Now())
	case eq(r, "llm"):
		_, toml, _ := s.kuniPaths()
		if toml == "" {
			return 200, map[string]any{"available": false, "error": "kuni_dir не задан"}
		}
		return 200, parseLLM(toml)
	case eq(r, "metrics"):
		return 200, s.sampler.Points()
	case eq(r, "modules"):
		return 200, s.modulesPayload()
	case eq(r, "settings"):
		return 200, loadSettings(s.M.Home)
	case eq(r, "transports"):
		var out []map[string]any
		for _, x := range s.M.Status() {
			if x["enabled"] != true {
				continue
			}
			provides, _ := x["provides"].([]string)
			for _, c := range provides {
				if transRE.MatchString(c) {
					out = append(out, map[string]any{"name": x["name"], "capability": c, "running": x["running"], "health": x["health"]})
				}
			}
		}
		if out == nil {
			out = []map[string]any{}
		}
		return 200, out
	case eq(r, "patches"):
		return 200, map[string]any{"keys": sortedPatchKeys(), "modules": s.M.LoadPatchState(), "hooks": s.hooks.Status()}
	case len(r) == 3 && r[0] == "widget":
		payload, err := s.runWidget(r[1], r[2], "")
		if err != nil {
			return 404, map[string]any{"error": err.Error()}
		}
		return 200, payload
	}
	if code, payload, ok := s.getExtra(r, query); ok {
		return code, payload
	}
	return notPorted("/api/" + strings.Join(r, "/"))
}

func (s *Server) post(r []string, body any) (int, any) {
	bodyMap, _ := body.(map[string]any)
	switch {
	case eq(r, "settings"):
		out, err := updateSettings(s.M.Home, body)
		if err != nil {
			return 400, map[string]any{"error": err.Error()}
		}
		return 200, out
	case len(r) == 3 && r[0] == "modules" && actions[r[2]]:
		return s.moduleAction(r[1], r[2], bodyMap)
	case eq(r, "token", "rotate"):
		tok, err := writeNewToken(s.M.Home)
		if err != nil {
			return 500, map[string]any{"error": err.Error()}
		}
		s.mu.Lock()
		s.token = tok
		s.mu.Unlock()
		return 200, map[string]any{"token": tok}
	}
	if code, payload, ok := s.postExtra(r, bodyMap); ok {
		return code, payload
	}
	if code, payload, ok := s.widgetAction(r); ok {
		return code, payload
	}
	if len(r) == 3 && r[0] == "modules" {
		return s.moduleAction(r[1], r[2], bodyMap)
	}
	return notPorted("/api/" + strings.Join(r, "/"))
}

func eq(r []string, want ...string) bool {
	if len(r) != len(want) {
		return false
	}
	for i := range r {
		if r[i] != want[i] {
			return false
		}
	}
	return true
}

func (s *Server) moduleAction(name, action string, body map[string]any) (int, any) {
	if !actions[action] {
		return 404, map[string]any{"error": "неизвестное действие"}
	}
	if _, ok := s.installed()[name]; !ok {
		return 404, map[string]any{"error": fmt.Sprintf("модуль %s не установлен", name)}
	}
	var (
		res any
		err error
	)
	switch action {
	case "enable":
		res, err = s.M.Enable(name)
	case "disable":
		cascade, _ := body["cascade"].(bool)
		res, err = s.M.Disable(name, cascade)
	case "start":
		res, err = s.M.Start(name)
	case "stop":
		res, err = s.M.Stop(name)
	default:
		res, err = s.M.Restart(name)
	}
	if err != nil {
		return 400, map[string]any{"error": err.Error()}
	}
	return 200, map[string]any{"ok": true, "result": res}
}

func (s *Server) modulesPayload() []map[string]any {
	rows := s.M.Status()
	if rows == nil {
		rows = []map[string]any{}
	}
	enabled := map[string]bool{}
	for _, n := range s.M.EnabledNames() {
		enabled[n] = true
	}
	for _, row := range rows {
		row["widgets"] = []map[string]any{}
		name, _ := row["name"].(string)
		if !enabled[name] {
			continue
		}
		mf, err := s.M.Manifest(name, "")
		if err != nil {
			continue
		}
		ws := []map[string]any{}
		for _, w := range mf.Widgets {
			refresh, ok := w["refresh_seconds"]
			if !ok {
				refresh = 10.0
			}
			size, ok := w["size"]
			if !ok {
				size = map[string]any{"w": 6.0, "h": 6.0}
			}
			ws = append(ws, map[string]any{"id": w["id"], "title": w["title"], "kind": w["kind"], "refresh": refresh, "size": size})
		}
		row["widgets"] = ws
	}
	return rows
}

func sortedPatchKeys() []map[string]string {
	keys := make([]string, 0, len(kernel.PatchKeys))
	for k := range kernel.PatchKeys {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out := make([]map[string]string, 0, len(keys))
	for _, k := range keys {
		out = append(out, map[string]string{"key": k, "title": kernel.PatchKeys[k]})
	}
	return out
}

func (s *Server) installed() map[string]*manager.ModuleState {
	m, err := s.M.Installed()
	if err != nil || m == nil {
		return map[string]*manager.ModuleState{}
	}
	return m
}

// port — порт, на котором слушает панель (для проверки портов в диагностике).
func (s *Server) port() int {
	if s.listen == 0 {
		return 8767
	}
	return s.listen
}

// SetListenPort запоминает порт прослушивания.
func (s *Server) SetListenPort(p int) { s.listen = p }
