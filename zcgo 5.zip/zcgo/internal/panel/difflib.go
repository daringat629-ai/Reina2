package panel

import (
	"fmt"
	"strings"
)

// unifiedDiff — построчное сравнение (LCS) в формате unified с двумя строками контекста.
// Возвращает текст, число добавленных и удалённых строк.
func unifiedDiff(fromName, toName, a, b string) (string, int, int) {
	la, lb := splitLines(a), splitLines(b)
	type op struct {
		kind byte // ' ', '+', '-'
		text string
	}
	n, m := len(la), len(lb)
	// LCS-таблица; для очень больших текстов сравниваем по префиксу и суффиксу без общей середины
	lcs := make([][]int, n+1)
	for i := range lcs {
		lcs[i] = make([]int, m+1)
	}
	for i := n - 1; i >= 0; i-- {
		for j := m - 1; j >= 0; j-- {
			if la[i] == lb[j] {
				lcs[i][j] = lcs[i+1][j+1] + 1
			} else if lcs[i+1][j] >= lcs[i][j+1] {
				lcs[i][j] = lcs[i+1][j]
			} else {
				lcs[i][j] = lcs[i][j+1]
			}
		}
	}
	var ops []op
	i, j := 0, 0
	for i < n && j < m {
		switch {
		case la[i] == lb[j]:
			ops = append(ops, op{' ', la[i]})
			i++
			j++
		case lcs[i+1][j] >= lcs[i][j+1]:
			ops = append(ops, op{'-', la[i]})
			i++
		default:
			ops = append(ops, op{'+', lb[j]})
			j++
		}
	}
	for ; i < n; i++ {
		ops = append(ops, op{'-', la[i]})
	}
	for ; j < m; j++ {
		ops = append(ops, op{'+', lb[j]})
	}
	added, removed := 0, 0
	for _, o := range ops {
		switch o.kind {
		case '+':
			added++
		case '-':
			removed++
		}
	}
	if added == 0 && removed == 0 {
		return "", 0, 0
	}
	const ctx = 2
	// отбираем строки, которые попадают в окно вокруг изменений
	keep := make([]bool, len(ops))
	for k, o := range ops {
		if o.kind != ' ' {
			for d := -ctx; d <= ctx; d++ {
				if k+d >= 0 && k+d < len(ops) {
					keep[k+d] = true
				}
			}
		}
	}
	var out strings.Builder
	fmt.Fprintf(&out, "--- %s\n+++ %s\n", fromName, toName)
	idxA, idxB := 0, 0
	k := 0
	for k < len(ops) {
		if !keep[k] {
			if ops[k].kind != '+' {
				idxA++
			}
			if ops[k].kind != '-' {
				idxB++
			}
			k++
			continue
		}
		start := k
		sa, sb := idxA, idxB
		for k < len(ops) && keep[k] {
			if ops[k].kind != '+' {
				idxA++
			}
			if ops[k].kind != '-' {
				idxB++
			}
			k++
		}
		fmt.Fprintf(&out, "@@ -%d,%d +%d,%d @@\n", sa+1, idxA-sa, sb+1, idxB-sb)
		for _, o := range ops[start:k] {
			out.WriteByte(o.kind)
			out.WriteString(o.text)
			out.WriteByte('\n')
		}
	}
	return strings.TrimRight(out.String(), "\n"), added, removed
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	return strings.Split(strings.TrimSuffix(s, "\n"), "\n")
}
