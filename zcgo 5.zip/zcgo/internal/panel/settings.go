package panel

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"

	"zcgo/internal/kernel"
)

// Настройки панели: тот же файл admin_state.json и те же значения по умолчанию, что у Python-панели.

const settingsPreset = 2

var (
	themes      = []string{"dark", "light", "black", "aurora", "neon", "paper"}
	idRE        = regexp.MustCompile(`^[A-Za-z0-9_:.\-]{1,80}$`)
	defaultHide = []string{"llm", "generation", "tools"}
)

func defaultSettings() map[string]any {
	return map[string]any{"language": "ru", "theme": "dark", "log_lines": 200.0, "gap": 14.0, "view": "panel",
		"layout": map[string]any{}, "hidden": []any{"llm", "generation", "tools"}, "preset": 0.0, "pro": false}
}

func settingsPath(home string) string { return filepath.Join(home, "admin_state.json") }

// loadSettings возвращает настройки с подстановкой умолчаний; повреждённый файл не ломает панель.
func loadSettings(home string) map[string]any {
	s := defaultSettings()
	raw, err := os.ReadFile(settingsPath(home))
	if err == nil {
		var stored map[string]any
		if json.Unmarshal(raw, &stored) == nil {
			for k := range s {
				if v, ok := stored[k]; ok {
					s[k] = v
				}
			}
		}
	}
	preset, _ := s["preset"].(float64)
	layout, _ := s["layout"].(map[string]any)
	hidden, _ := s["hidden"].([]any)
	if preset < settingsPreset && len(layout) == 0 && len(hidden) == 0 {
		h := make([]any, len(defaultHide))
		for i, x := range defaultHide {
			h[i] = x
		}
		s["hidden"] = h
	}
	return s
}

func intIn(v any, lo, hi int, name string) (int, error) {
	f, ok := v.(float64)
	if !ok || f != float64(int(f)) {
		return 0, fmt.Errorf("%s: нужно целое число", name)
	}
	n := int(f)
	if n < lo {
		n = lo
	}
	if n > hi {
		n = hi
	}
	return n, nil
}

func sanitizeLayout(raw any) (map[string]any, error) {
	m, ok := raw.(map[string]any)
	if !ok {
		return nil, fmt.Errorf("layout: объект {id: {x, y, w, h}}")
	}
	out := map[string]any{}
	for wid, rv := range m {
		r, ok := rv.(map[string]any)
		if !idRE.MatchString(wid) || !ok || len(out) >= 100 {
			continue
		}
		x, e1 := intIn(r["x"], 0, 23, "x")
		y, e2 := intIn(r["y"], 0, 400, "y")
		w, e3 := intIn(r["w"], 2, 24, "w")
		h, e4 := intIn(r["h"], 2, 60, "h")
		if e1 != nil || e2 != nil || e3 != nil || e4 != nil {
			continue
		}
		out[wid] = map[string]any{"x": x, "y": y, "w": w, "h": h}
	}
	return out, nil
}

// updateSettings применяет изменения; неверное значение отклоняется целиком.
func updateSettings(home string, patch any) (map[string]any, error) {
	p, ok := patch.(map[string]any)
	if !ok {
		return nil, fmt.Errorf("ожидается объект JSON")
	}
	s := loadSettings(home)
	if v, ok := p["language"]; ok {
		if v != "ru" && v != "en" {
			return nil, fmt.Errorf("language: ru или en")
		}
		s["language"] = v
	}
	if v, ok := p["theme"]; ok {
		okTheme := false
		for _, t := range themes {
			if v == t {
				okTheme = true
			}
		}
		if !okTheme {
			return nil, fmt.Errorf("theme: %v", themes)
		}
		s["theme"] = v
	}
	if v, ok := p["pro"]; ok {
		b, ok := v.(bool)
		if !ok {
			return nil, fmt.Errorf("pro: true или false")
		}
		s["pro"] = b
	}
	if v, ok := p["log_lines"]; ok {
		n, err := intIn(v, 20, 2000, "log_lines")
		if err != nil {
			return nil, err
		}
		s["log_lines"] = float64(n)
	}
	if v, ok := p["view"]; ok {
		if v != "panel" && v != "arch" {
			return nil, fmt.Errorf("view: panel или arch")
		}
		s["view"] = v
	}
	if v, ok := p["gap"]; ok {
		n, err := intIn(v, 0, 60, "gap")
		if err != nil {
			return nil, err
		}
		s["gap"] = float64(n)
	}
	if v, ok := p["layout"]; ok {
		l, err := sanitizeLayout(v)
		if err != nil {
			return nil, err
		}
		s["layout"] = l
	}
	if v, ok := p["hidden"]; ok {
		list, ok := v.([]any)
		if !ok || len(list) > 100 {
			return nil, fmt.Errorf("hidden: список идентификаторов виджетов")
		}
		for _, x := range list {
			str, ok := x.(string)
			if !ok || !idRE.MatchString(str) {
				return nil, fmt.Errorf("hidden: список идентификаторов виджетов")
			}
		}
		s["hidden"] = list
	}
	s["preset"] = float64(settingsPreset)
	raw, err := json.MarshalIndent(s, "", " ")
	if err != nil {
		return nil, err
	}
	if err := kernel.AtomicWrite(settingsPath(home), raw, 0o644); err != nil {
		return nil, err
	}
	return s, nil
}
