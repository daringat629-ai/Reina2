package panel

// Шаблоны конструктора деталей (список для панели; сам конструктор, создающий Python-код, не перенесён).
var templates = []map[string]any{
	{"id": "counter", "title": "Счётчик с кнопками", "title_en": "Counter with buttons", "desc": "виджет-счётчик: «+1» и «Сброс»", "desc_en": "counter widget with +1 and Reset", "kind": "library", "widget": "counter", "tool": ""},
	{"id": "note", "title": "Табло с текстом", "title_en": "Text board", "desc": "виджет с произвольным текстом", "desc_en": "widget with free text", "kind": "library", "widget": "text", "tool": ""},
	{"id": "status", "title": "Таблица состояния", "title_en": "Status table", "desc": "виджет «таблица» из двух столбцов", "desc_en": "two-column table widget", "kind": "library", "widget": "table", "tool": ""},
	{"id": "tool", "title": "Инструмент для бота", "title_en": "Tool for the bot", "desc": "бот получит новый инструмент без пересборки", "desc_en": "the bot gets a new tool without a rebuild", "kind": "library", "widget": "", "tool": "auto"},
	{"id": "service", "title": "Служба с проверкой здоровья", "title_en": "Service with health check", "desc": "маленький сервер: порт подберётся сам", "desc_en": "tiny server, the port is picked automatically", "kind": "service", "widget": "kv", "tool": ""},
	{"id": "job", "title": "Периодическая задача", "title_en": "Periodic job", "desc": "запускается по расписанию (раз в 5 минут)", "desc_en": "runs on a schedule (every 5 minutes)", "kind": "job", "widget": "kv", "tool": ""},
	{"id": "empty", "title": "Пустая деталь", "title_en": "Empty part", "desc": "только манифест и разъём, остальное вы добавите сами", "desc_en": "manifest and connector only", "kind": "library", "widget": "", "tool": ""},
	{"id": "prompt", "title": "Добавка к промптам Марин", "title_en": "Addition to Marin's prompts", "desc": "ваш текст добавляется к промпту бота, пока деталь включена (после перезапуска бота)", "desc_en": "your text is added to the bot prompt while the part is enabled (after a bot restart)", "kind": "library", "widget": "", "tool": "", "prompt_target": "system.md", "hook_on": ""},
	{"id": "reaction", "title": "Реакция на событие бота", "title_en": "Reaction to a bot event", "desc": "ваша команда запускается, когда в боте случается событие (например, ошибка)", "desc_en": "your command runs when a bot event happens (for example, an error)", "kind": "library", "widget": "", "tool": "", "prompt_target": "", "hook_on": "error"},
}
