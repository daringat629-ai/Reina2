package panel

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"zcgo/internal/manager"
)

const token = "test-token-123"

func newPanel(t *testing.T) (*Server, *httptest.Server) {
	t.Helper()
	t.Setenv("ZEROCORE_PANEL_TOKEN", token)
	m, err := manager.New(filepath.Join(t.TempDir(), "home"), t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	srv, err := New(m)
	if err != nil {
		t.Fatal(err)
	}
	ts := httptest.NewServer(srv.Handler())
	t.Cleanup(ts.Close)
	return srv, ts
}

// install ставит и включает библиотеку с заданным манифестом виджетов.
func install(t *testing.T, srv *Server, name string, widgets []any) {
	t.Helper()
	src := filepath.Join(t.TempDir(), name)
	if err := os.MkdirAll(src, 0o755); err != nil {
		t.Fatal(err)
	}
	mf := map[string]any{"name": name, "version": "1.0.0", "api": "1", "kind": "library"}
	if widgets != nil {
		mf["widgets"] = widgets
	}
	raw, _ := json.Marshal(mf)
	if err := os.WriteFile(filepath.Join(src, "manifest.json"), raw, 0o644); err != nil {
		t.Fatal(err)
	}
	if _, err := srv.M.Install(src); err != nil {
		t.Fatalf("install: %v", err)
	}
	if _, err := srv.M.Enable(name); err != nil {
		t.Fatalf("enable: %v", err)
	}
}

func do(t *testing.T, ts *httptest.Server, method, path, tok, body string) (int, map[string]any, http.Header) {
	t.Helper()
	req, _ := http.NewRequest(method, ts.URL+path, strings.NewReader(body))
	if tok != "" {
		req.Header.Set("X-Token", tok)
	}
	resp, err := ts.Client().Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var out map[string]any
	_ = json.NewDecoder(resp.Body).Decode(&out)
	return resp.StatusCode, out, resp.Header
}

func TestAPINeedsTokenStaticDoesNot(t *testing.T) {
	_, ts := newPanel(t)
	if code, _, _ := do(t, ts, "GET", "/api/modules", "", ""); code != 401 {
		t.Errorf("без токена: %d", code)
	}
	if code, _, _ := do(t, ts, "GET", "/api/modules", "wrong", ""); code != 401 {
		t.Errorf("неверный токен: %d", code)
	}
	req, _ := http.NewRequest("GET", ts.URL+"/api/modules", nil)
	req.Header.Set("X-Token", token)
	resp2, err := ts.Client().Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp2.Body.Close()
	var raw strings.Builder
	buf := make([]byte, 64)
	for {
		n, rerr := resp2.Body.Read(buf)
		raw.Write(buf[:n])
		if rerr != nil {
			break
		}
	}
	if resp2.StatusCode != 200 || strings.TrimSpace(raw.String()) != "[]" {
		t.Errorf("пустой список модулей должен быть [], получено %d %q", resp2.StatusCode, raw.String())
	}
	resp, err := ts.Client().Get(ts.URL + "/")
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if resp.StatusCode != 200 || !strings.Contains(resp.Header.Get("Content-Security-Policy"), "frame-ancestors 'none'") {
		t.Errorf("главная страница или CSP: %d %q", resp.StatusCode, resp.Header.Get("Content-Security-Policy"))
	}
	if resp.Header.Get("X-Content-Type-Options") != "nosniff" {
		t.Error("нет nosniff")
	}
}

func TestUnportedRoutesSaySo(t *testing.T) {
	_, ts := newPanel(t)
	code, out, _ := do(t, ts, "GET", "/api/selfmod", token, "")
	if code != 501 || !strings.Contains(out["error"].(string), "пока не перенесено") {
		t.Errorf("непереписанный маршрут: %d %v", code, out)
	}
}

func TestSettingsValidateAndPersist(t *testing.T) {
	_, ts := newPanel(t)
	if code, out, _ := do(t, ts, "POST", "/api/settings", token, `{"theme":"nope"}`); code != 400 {
		t.Errorf("неверная тема: %d %v", code, out)
	}
	if code, _, _ := do(t, ts, "POST", "/api/settings", token, `{"gap":"x"}`); code != 400 {
		t.Error("gap строкой должен отклоняться")
	}
	if code, _, _ := do(t, ts, "POST", "/api/settings", token, `{"theme":"neon","log_lines":5000}`); code != 200 {
		t.Fatal("верные настройки отклонены")
	}
	_, out, _ := do(t, ts, "GET", "/api/settings", token, "")
	if out["theme"] != "neon" || out["log_lines"] != float64(2000) {
		t.Errorf("сохранено не то: %v", out)
	}
	if _, out, _ := do(t, ts, "GET", "/api/settings", token, ""); out["preset"] != float64(2) {
		t.Errorf("preset после сохранения: %v", out["preset"])
	}
}

func TestModuleActions(t *testing.T) {
	srv, ts := newPanel(t)
	if code, _, _ := do(t, ts, "POST", "/api/modules/ghost/start", token, ""); code != 404 {
		t.Errorf("неустановленный модуль: %d", code)
	}
	install(t, srv, "demo_lib", nil)
	if code, _, _ := do(t, ts, "POST", "/api/modules/demo_lib/bogus", token, ""); code != 404 {
		t.Errorf("неизвестное действие: %d", code)
	}
	if code, out, _ := do(t, ts, "POST", "/api/modules/demo_lib/disable", token, ""); code != 200 || out["ok"] != true {
		t.Errorf("выключение: %d %v", code, out)
	}
	_, rows, _ := do(t, ts, "GET", "/api/modules", token, "")
	_ = rows
	found := false
	for _, n := range srv.M.EnabledNames() {
		if n == "demo_lib" {
			found = true
		}
	}
	if found {
		t.Error("модуль должен быть выключен")
	}
}

func TestWidgetRunsAndReportsBadOutput(t *testing.T) {
	srv, ts := newPanel(t)
	kvCmd := []any{"sh", "-c", `echo '{"items":[["кошка","мяу"]]}'`}
	badCmd := []any{"sh", "-c", `echo '[1,2]'`}
	crashCmd := []any{"sh", "-c", "echo oops >&2; exit 4"}
	install(t, srv, "demo_w", []any{
		map[string]any{"id": "good", "title": "Хорошо", "kind": "kv", "command": kvCmd},
		map[string]any{"id": "bad", "title": "Плохо", "kind": "counter", "command": badCmd},
		map[string]any{"id": "crash", "title": "Падает", "kind": "text", "command": crashCmd},
	})
	code, out, _ := do(t, ts, "GET", "/api/widget/demo_w/good", token, "")
	if code != 200 || out["ok"] != true {
		t.Fatalf("виджет: %d %v", code, out)
	}
	data := out["data"].(map[string]any)
	if len(data["items"].([]any)) != 1 {
		t.Errorf("данные виджета: %v", data)
	}
	if _, out, _ := do(t, ts, "GET", "/api/widget/demo_w/bad", token, ""); out["ok"] != false {
		t.Errorf("неверная форма должна быть ok=false: %v", out)
	}
	if _, out, _ := do(t, ts, "GET", "/api/widget/demo_w/crash", token, ""); out["ok"] != false || !strings.Contains(out["error"].(string), "кодом 4") {
		t.Errorf("падение команды: %v", out)
	}
	if code, _, _ := do(t, ts, "GET", "/api/widget/demo_w/none", token, ""); code != 404 {
		t.Errorf("нет такого виджета: %d", code)
	}
	if code, _, _ := do(t, ts, "GET", "/api/widget/ghost/good", token, ""); code != 404 {
		t.Errorf("модуль не установлен: %d", code)
	}
}

func TestBodyLimitsAndBadJSON(t *testing.T) {
	_, ts := newPanel(t)
	if code, _, _ := do(t, ts, "POST", "/api/settings", token, "{bad"); code != 400 {
		t.Errorf("битый JSON: %d", code)
	}
	big := `{"x":"` + strings.Repeat("a", maxBody+10) + `"}`
	if code, _, _ := do(t, ts, "POST", "/api/settings", token, big); code != 413 {
		t.Errorf("слишком большой запрос: %d", code)
	}
}

func TestTokenRotationInvalidatesOldToken(t *testing.T) {
	srv, ts := newPanel(t)
	t.Setenv("ZEROCORE_PANEL_TOKEN", "")
	code, out, _ := do(t, ts, "POST", "/api/token/rotate", token, "")
	if code != 200 {
		t.Fatalf("ротация: %d %v", code, out)
	}
	fresh := out["token"].(string)
	if fresh == token || fresh == "" {
		t.Fatal("новый токен не выдан")
	}
	if code, _, _ := do(t, ts, "GET", "/api/modules", token, ""); code != 401 {
		t.Errorf("старый токен должен перестать работать: %d", code)
	}
	if code, _, _ := do(t, ts, "GET", "/api/modules", fresh, ""); code != 200 {
		t.Errorf("новый токен: %d", code)
	}
	raw, err := os.ReadFile(tokenPath(srv.M.Home))
	if err != nil || strings.TrimSpace(string(raw)) != fresh {
		t.Errorf("токен не записан в файл: %v", err)
	}
}

func TestShapeProblemRules(t *testing.T) {
	if shapeProblem("kv", map[string]any{"items": []any{[]any{"a"}}}) == "" {
		t.Error("kv с одним элементом пары должен отклоняться")
	}
	if shapeProblem("table", map[string]any{"columns": []any{"a", "b"}, "rows": []any{[]any{"1"}}}) == "" {
		t.Error("table с неровной строкой должна отклоняться")
	}
	if shapeProblem("counter", map[string]any{"value": "5"}) == "" {
		t.Error("counter со строкой должен отклоняться")
	}
	if shapeProblem("text", map[string]any{"text": "ok"}) != "" {
		t.Error("верный text отклонён")
	}
}
