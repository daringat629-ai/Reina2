package panel

import (
	"strconv"
	"strings"
)

// parseTOML читает подмножество TOML, которое используется в config.toml бота:
// таблицы [a.b], ключи с точками, строки "..." и '...', числа, логические значения.
// Массивы и вложенные inline-таблицы пропускаются (им не нужны значения для панели),
// многострочные строки """...""" и ”'...”' тоже пропускаются. Ошибочная строка не ломает разбор остального.
func parseTOML(src string) map[string]any {
	root := map[string]any{}
	cur := root
	lines := strings.Split(src, "\n")
	for i := 0; i < len(lines); i++ {
		line := strings.TrimSpace(stripComment(lines[i]))
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "[[") {
			cur = map[string]any{} // массивы таблиц не нужны панели: пишем в отброшенную таблицу
			continue
		}
		if strings.HasPrefix(line, "[") {
			cur = ensureTable(root, strings.Trim(line, "[] "))
			continue
		}
		eq := strings.Index(line, "=")
		if eq <= 0 {
			continue
		}
		key := strings.TrimSpace(line[:eq])
		val := strings.TrimSpace(line[eq+1:])
		if strings.HasPrefix(val, `"""`) || strings.HasPrefix(val, `'''`) {
			delim := val[:3]
			if strings.Count(val, delim) >= 2 {
				continue
			}
			for i+1 < len(lines) && !strings.Contains(lines[i+1], delim) {
				i++
			}
			i++
			continue
		}
		if strings.HasPrefix(val, "[") || strings.HasPrefix(val, "{") {
			depth := bracketDepth(val)
			for depth > 0 && i+1 < len(lines) {
				i++
				depth += bracketDepth(stripComment(lines[i]))
			}
			continue
		}
		parent, leaf := descend(cur, key)
		if v, ok := scalar(val); ok {
			parent[leaf] = v
		}
	}
	return root
}

func ensureTable(root map[string]any, path string) map[string]any {
	cur := root
	for _, part := range splitKey(path) {
		next, ok := cur[part].(map[string]any)
		if !ok {
			next = map[string]any{}
			cur[part] = next
		}
		cur = next
	}
	return cur
}

func descend(cur map[string]any, key string) (map[string]any, string) {
	parts := splitKey(key)
	for _, p := range parts[:len(parts)-1] {
		next, ok := cur[p].(map[string]any)
		if !ok {
			next = map[string]any{}
			cur[p] = next
		}
		cur = next
	}
	return cur, parts[len(parts)-1]
}

func splitKey(key string) []string {
	var out []string
	for _, p := range strings.Split(key, ".") {
		p = strings.TrimSpace(p)
		p = strings.Trim(p, `"'`)
		if p != "" {
			out = append(out, p)
		}
	}
	if len(out) == 0 {
		out = []string{""}
	}
	return out
}

func scalar(v string) (any, bool) {
	switch {
	case v == "true":
		return true, true
	case v == "false":
		return false, true
	case strings.HasPrefix(v, `"`):
		return basicString(v)
	case strings.HasPrefix(v, `'`):
		end := strings.Index(v[1:], "'")
		if end < 0 {
			return nil, false
		}
		return v[1 : end+1], true
	}
	clean := strings.ReplaceAll(v, "_", "")
	if n, err := strconv.ParseInt(clean, 10, 64); err == nil {
		return float64(n), true
	}
	if f, err := strconv.ParseFloat(clean, 64); err == nil {
		return f, true
	}
	return nil, false
}

func basicString(v string) (any, bool) {
	var b strings.Builder
	for i := 1; i < len(v); i++ {
		c := v[i]
		if c == '"' {
			return b.String(), true
		}
		if c != '\\' {
			b.WriteByte(c)
			continue
		}
		i++
		if i >= len(v) {
			return nil, false
		}
		switch v[i] {
		case 'n':
			b.WriteByte('\n')
		case 't':
			b.WriteByte('\t')
		case 'r':
			b.WriteByte('\r')
		case '"', '\\':
			b.WriteByte(v[i])
		case 'u', 'U':
			n := 4
			if v[i] == 'U' {
				n = 8
			}
			if i+n >= len(v) {
				return nil, false
			}
			r, err := strconv.ParseInt(v[i+1:i+1+n], 16, 32)
			if err != nil {
				return nil, false
			}
			b.WriteRune(rune(r))
			i += n
		default:
			return nil, false
		}
	}
	return nil, false
}

// stripComment убирает комментарий после #, если он не внутри строки.
func stripComment(line string) string {
	inStr := byte(0)
	for i := 0; i < len(line); i++ {
		c := line[i]
		switch {
		case inStr != 0:
			if c == '\\' && inStr == '"' {
				i++
			} else if c == inStr {
				inStr = 0
			}
		case c == '"' || c == '\'':
			inStr = c
		case c == '#':
			return line[:i]
		}
	}
	return line
}

func bracketDepth(s string) int {
	d := 0
	inStr := byte(0)
	for i := 0; i < len(s); i++ {
		c := s[i]
		switch {
		case inStr != 0:
			if c == '\\' && inStr == '"' {
				i++
			} else if c == inStr {
				inStr = 0
			}
		case c == '"' || c == '\'':
			inStr = c
		case c == '[' || c == '{':
			d++
		case c == ']' || c == '}':
			d--
		}
	}
	return d
}
