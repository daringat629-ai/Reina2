package panel

// Инструменты Марин в панели: консоль, файлы, детали ядра, журнал, диагностика, каталог инструментов, промпты, копии.

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

// toolDefs — описания инструментов для модели (тот же набор, что в Python-версии).
func toolDefs() []any {
	var out []any
	if err := json.Unmarshal([]byte(assistantToolsJSON), &out); err != nil {
		panic("описание инструментов Марин повреждено: " + err.Error())
	}
	return out
}

const assistantToolsJSON = `[
{"type":"function","function":{"name":"shell","description":"Выполнить команду в консоли ноутбука (bash) и получить код возврата, stdout и stderr. Для длинных задач задай timeout_seconds.","parameters":{"type":"object","properties":{"command":{"type":"string","description":"команда bash"},"timeout_seconds":{"type":"integer","description":"сколько ждать, по умолчанию 60, не больше 300"}},"required":["command"]}}},
{"type":"function","function":{"name":"read_file","description":"Прочитать текстовый файл целиком или начало.","parameters":{"type":"object","properties":{"path":{"type":"string"},"max_bytes":{"type":"integer"}},"required":["path"]}}},
{"type":"function","function":{"name":"write_file","description":"Записать текст в файл (создаёт папки). append=true дописывает в конец.","parameters":{"type":"object","properties":{"path":{"type":"string"},"content":{"type":"string"},"append":{"type":"boolean"}},"required":["path","content"]}}},
{"type":"function","function":{"name":"modules","description":"Список деталей ядра: версия, вид, включена ли, запущена ли, здоровье.","parameters":{"type":"object","properties":{}}}},
{"type":"function","function":{"name":"module_action","description":"Включить, выключить, запустить, остановить или перезапустить деталь ядра (в том числе бота kuni).","parameters":{"type":"object","properties":{"name":{"type":"string"},"action":{"type":"string","enum":["enable","disable","start","stop","restart"]}},"required":["name","action"]}}},
{"type":"function","function":{"name":"logs","description":"Последние строки живого журнала: source core, kuni или all.","parameters":{"type":"object","properties":{"source":{"type":"string","enum":["core","kuni","all"]},"lines":{"type":"integer"}}}}},
{"type":"function","function":{"name":"doctor","description":"Диагностика системы: что в порядке, что нет и как исправить.","parameters":{"type":"object","properties":{}}}},
{"type":"function","function":{"name":"tool","description":"Вызвать один из твоих инструментов из каталога (память, заметки, задачи, расписание, календарь, погода, самостоятельные детали и т.д.). arguments: объект аргументов.","parameters":{"type":"object","properties":{"name":{"type":"string"},"arguments":{"type":"object"}},"required":["name"]}}},
{"type":"function","function":{"name":"prompt_list","description":"Список твоих файлов промптов.","parameters":{"type":"object","properties":{}}}},
{"type":"function","function":{"name":"prompt_read","description":"Прочитать файл промпта.","parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}}},
{"type":"function","function":{"name":"prompt_write","description":"Записать новую версию файла промпта (прежняя сохранится в истории). Блоки ядра zerocore:begin менять нельзя. Действует после перезапуска бота.","parameters":{"type":"object","properties":{"name":{"type":"string"},"text":{"type":"string"},"note":{"type":"string","description":"зачем правка"}},"required":["name","text"]}}},
{"type":"function","function":{"name":"backup_create","description":"Сделать резервную копию настроек, деталей, данных, промптов и config.toml бота.","parameters":{"type":"object","properties":{"note":{"type":"string"}}}}}
]`

// execute запускает инструмент; ошибка становится текстом для модели.
func (a *assistantState) execute(name string, args map[string]any) (bool, string) {
	var fn func(map[string]any) (string, error)
	switch name {
	case "shell":
		fn = a.toolShell
	case "read_file":
		fn = toolReadFile
	case "write_file":
		fn = toolWriteFile
	case "modules":
		fn = a.toolModules
	case "module_action":
		fn = a.toolModuleAction
	case "logs":
		fn = a.toolLogs
	case "doctor":
		fn = a.toolDoctor
	case "tool":
		fn = a.toolCatalog
	case "prompt_list":
		fn = a.toolPromptList
	case "prompt_read":
		fn = a.toolPromptRead
	case "prompt_write":
		fn = a.toolPromptWrite
	case "backup_create":
		fn = a.toolBackup
	default:
		return false, "ОШИБКА: нет инструмента " + name
	}
	out, err := fn(args)
	if err != nil {
		return false, "ОШИБКА: " + err.Error()
	}
	return true, out
}

func argStr(a map[string]any, key string) string { return toStr(a[key]) }

func argInt(a map[string]any, key string, def int) int {
	if n, ok := asInt(a[key]); ok && n != 0 {
		return n
	}
	if s, ok := a[key].(string); ok {
		if n, err := strconv.Atoi(s); err == nil && n != 0 {
			return n
		}
	}
	return def
}

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func killGroup(pid int) {
	_ = syscall.Kill(-pid, syscall.SIGKILL)
}

func (a *assistantState) cwd() string {
	kd := a.s.kuniDir()
	if kd != "" {
		if st, err := os.Stat(kd); err == nil && st.IsDir() {
			return kd
		}
	}
	return a.s.M.Home
}

func (a *assistantState) toolShell(args map[string]any) (string, error) {
	cmdText := strings.TrimSpace(argStr(args, "command"))
	if cmdText == "" {
		return "", errors.New("пустая команда")
	}
	timeout := clampInt(argInt(args, "timeout_seconds", a.intSetting("shell_timeout")), 1, 300)
	c := exec.Command("bash", "-lc", cmdText)
	c.Dir = a.cwd()
	c.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
	var outB, errB bytes.Buffer
	c.Stdout, c.Stderr = &outB, &errB
	if err := c.Start(); err != nil {
		return "", err
	}
	a.setProc(c.Process.Pid)
	defer a.setProc(0)
	done := make(chan error, 1)
	go func() { done <- c.Wait() }()
	t0 := time.Now()
	tick := time.NewTicker(250 * time.Millisecond)
	defer tick.Stop()
	for {
		select {
		case <-done:
			rc := c.ProcessState.ExitCode()
			return fmt.Sprintf("код возврата %d\n--- stdout ---\n%s\n--- stderr ---\n%s", rc,
				clip(outB.String(), outLimit), clip(errB.String(), errLimit)), nil
		case <-tick.C:
			if a.canceled.Load() {
				killGroup(c.Process.Pid)
				<-done
				return "команда остановлена владельцем", nil
			}
			if time.Since(t0) > time.Duration(timeout)*time.Second {
				killGroup(c.Process.Pid)
				<-done
				return fmt.Sprintf("команда остановлена: прошло %d с\n--- stdout ---\n%s\n--- stderr ---\n%s", timeout,
					clip(outB.String(), outLimit), clip(errB.String(), errLimit)), nil
			}
		}
	}
}

func toolReadFile(args map[string]any) (string, error) {
	p := filepath.Clean(expandHome(argStr(args, "path")))
	n := clampInt(argInt(args, "max_bytes", 20000), 1, 200000)
	st, err := os.Stat(p)
	if err != nil || !st.Mode().IsRegular() {
		return "", fmt.Errorf("файла %s нет", p)
	}
	f, err := os.Open(p)
	if err != nil {
		return "", err
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, int64(n)))
	if err != nil {
		return "", err
	}
	if bytes.IndexByte(data, 0) >= 0 {
		return "двоичный файл, показывать нечего", nil
	}
	out := string(data)
	if st.Size() > int64(n) {
		out += "\n…(показано начало)"
	}
	return out, nil
}

func toolWriteFile(args map[string]any) (string, error) {
	p := filepath.Clean(expandHome(argStr(args, "path")))
	content := argStr(args, "content")
	if len(content) > 1_000_000 {
		return "", errors.New("файл больше 1 МБ")
	}
	if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		return "", err
	}
	if app, _ := args["append"].(bool); app {
		f, err := os.OpenFile(p, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o644)
		if err != nil {
			return "", err
		}
		defer f.Close()
		if _, err := f.WriteString(content); err != nil {
			return "", err
		}
	} else if err := writeFileAtomic(p, []byte(content), 0o644); err != nil {
		return "", err
	}
	return fmt.Sprintf("записано %d символов в %s", len([]rune(content)), p), nil
}

func (a *assistantState) toolModules(map[string]any) (string, error) {
	var lines []string
	for _, r := range a.s.M.Status() {
		en, _ := r["enabled"].(bool)
		running, _ := r["running"].(bool)
		enText, runText := "выключена", "не запущена"
		if en {
			enText = "включена"
		}
		if running {
			runText = "запущена"
		}
		lines = append(lines, fmt.Sprintf("%v %v (%v): %s, %s, здоровье %v", r["name"], r["version"], r["kind"], enText, runText, r["health"]))
	}
	if len(lines) == 0 {
		return "деталей нет", nil
	}
	return strings.Join(lines, "\n"), nil
}

func (a *assistantState) toolModuleAction(args map[string]any) (string, error) {
	name, action := argStr(args, "name"), argStr(args, "action")
	if _, ok := a.s.installed()[name]; !ok {
		return "", fmt.Errorf("детали %s нет", name)
	}
	var err error
	switch action {
	case "enable":
		_, err = a.s.M.Enable(name)
	case "disable":
		_, err = a.s.M.Disable(name, true)
	case "start":
		_, err = a.s.M.Start(name)
	case "stop":
		_, err = a.s.M.Stop(name)
	case "restart":
		_, err = a.s.M.Restart(name)
	default:
		return "", errors.New("action: enable, disable, start, stop или restart")
	}
	if err != nil {
		return "", err
	}
	return name + ": " + action + " выполнено", nil
}

func (a *assistantState) toolLogs(args map[string]any) (string, error) {
	n := clampInt(argInt(args, "lines", 40), 5, 200)
	src := argStr(args, "source")
	if src == "" {
		src = "all"
	}
	_, _, console := a.s.kuniPaths()
	rows := liveLog(a.s.busRecent(n), console, n, a.now())
	var kept []string
	for _, r := range rows {
		rsrc := toStr(r["src"])
		if src != "all" && rsrc != src {
			continue
		}
		stamp := "??:??:??"
		if t, ok := r["t"].(float64); ok {
			stamp = time.Unix(int64(t), 0).Format("15:04:05")
		}
		kept = append(kept, fmt.Sprintf("%s [%s] %s", stamp, rsrc, toStr(r["text"])))
	}
	if len(kept) > n {
		kept = kept[len(kept)-n:]
	}
	if len(kept) == 0 {
		return "журнал пуст", nil
	}
	return strings.Join(kept, "\n"), nil
}

func (a *assistantState) toolDoctor(map[string]any) (string, error) {
	checks := a.s.doctor(a.s.kuniDir(), a.s.port())
	var lines []string
	for _, c := range checks {
		line := fmt.Sprintf("[%s] %s: %s", c.Status, c.Title, c.Detail)
		if c.Fix != "" && c.Status != "ok" {
			line += " -> " + c.Fix
		}
		lines = append(lines, line)
	}
	return strings.Join(lines, "\n"), nil
}

func (a *assistantState) toolCatalog(args map[string]any) (string, error) {
	name := argStr(args, "name")
	var cat struct {
		Tools []map[string]any `json:"tools"`
	}
	if raw, err := os.ReadFile(a.s.M.ToolsPath()); err == nil {
		_ = json.Unmarshal(raw, &cat)
	}
	var found map[string]any
	var names []string
	for _, t := range cat.Tools {
		names = append(names, toStr(t["name"]))
		if toStr(t["name"]) == name {
			found = t
		}
	}
	if found == nil {
		return "", fmt.Errorf("инструмента %s нет в каталоге; доступны: %s", name, truncRunes(strings.Join(names, ", "), 500))
	}
	var argv []string
	for _, c := range listOfStrings(found["command"]) {
		argv = append(argv, c)
	}
	if len(argv) == 0 {
		return "", errors.New("у инструмента нет команды")
	}
	timeout := argInt(found, "timeout_seconds", 30) + 5
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	payload, _ := json.Marshal(map[string]any{"tool": name, "arguments": argsOrEmpty(args["arguments"])})
	c := exec.CommandContext(ctx, argv[0], argv[1:]...)
	c.Stdin = bytes.NewReader(payload)
	if d := toStr(found["cwd"]); d != "" {
		c.Dir = d
	}
	env := os.Environ()
	if e, ok := found["env"].(map[string]any); ok {
		for k, v := range e {
			env = append(env, k+"="+toStr(v))
		}
	}
	c.Env = env
	var outB, errB bytes.Buffer
	c.Stdout, c.Stderr = &outB, &errB
	err := c.Run()
	if ctx.Err() == context.DeadlineExceeded {
		return "", errors.New("команда не уложилась во время")
	}
	rc := 0
	if err != nil {
		var ee *exec.ExitError
		if errors.As(err, &ee) {
			rc = ee.ExitCode()
		} else {
			return "", err
		}
	}
	text := strings.TrimSpace(outB.String())
	if text == "" {
		text = strings.TrimSpace(errB.String())
	}
	if text == "" {
		text = fmt.Sprintf("(пусто, код %d)", rc)
	}
	return clip(text, outLimit), nil
}

func argsOrEmpty(v any) any {
	if v == nil {
		return map[string]any{}
	}
	return v
}

func (a *assistantState) toolPromptList(map[string]any) (string, error) {
	files, err := listPrompts(a.s.kuniDir(), a.s.M.Home)
	if err != nil {
		return "", err
	}
	var lines []string
	for _, f := range files {
		lines = append(lines, fmt.Sprintf("%v: %v байт, версий в истории %v, блоков ядра %v", f["name"], f["size"], f["versions"], f["blocks"]))
	}
	if len(lines) == 0 {
		return "файлов нет", nil
	}
	return strings.Join(lines, "\n"), nil
}

func (a *assistantState) toolPromptRead(args map[string]any) (string, error) {
	out, err := readPrompt(a.s.kuniDir(), a.s.M.Home, argStr(args, "name"))
	if err != nil {
		return "", err
	}
	return toStr(out["text"]), nil
}

func (a *assistantState) toolPromptWrite(args map[string]any) (string, error) {
	note := truncRunes("Марин: "+argStr(args, "note"), 150)
	r, err := savePrompt(a.s.kuniDir(), a.s.M.Home, argStr(args, "name"), argStr(args, "text"), note, a.now())
	if err != nil {
		return "", err
	}
	prev := "нет"
	if p, ok := r["previous"].(string); ok {
		prev = p
	}
	return fmt.Sprintf("сохранено %s; прежняя версия %s; вступит в силу после перезапуска бота", toStr(r["saved"]), prev), nil
}

func (a *assistantState) toolBackup(args map[string]any) (string, error) {
	note := argStr(args, "note")
	if note == "" {
		note = "по просьбе Марин"
	}
	r, err := createBackup(a.s.M.Home, a.s.kuniDir(), note, a.now())
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("копия %v, %v файлов, %v байт", r["name"], r["files"], r["size"]), nil
}
