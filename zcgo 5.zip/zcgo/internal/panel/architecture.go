package panel

// Архитектура системы как граф: ядро, модули из реестра, процесс kuni и внешние системы.
// Узлы и связи строятся из живых данных; каждый узел получает место на сетке 24 колонки.

import (
	"encoding/json"
	"os"
	"sort"
	"strconv"
	"strings"
	"time"

	"zcgo/internal/kernel"
	"zcgo/internal/manager"
)

const archStep = 5

var archSlots = []int{10, 5, 15, 0, 20}

type archNode = map[string]any

var kuniInternals = []struct {
	id, title string
	lines     []string
}{
	{"k_telegram", "Telegram-клиент", []string{"TDLib: чаты, сообщения, медиа", "src/telegram, src/llmui"}},
	{"k_memory", "Память", []string{"дневник + поиск по смыслу (RAG)", "Diary, #ask"}},
	{"k_cognition", "Цикл ходов", []string{"AppBase: ход, охранник вызовов", "OpenAIChat, prompts"}},
	{"k_tools", "Инструменты LLM", []string{"shell, сообщения, внешние", "src/tools"}},
	{"k_media", "Зрение и голос", []string{"изображения, видео, TTS", "llmui, speech"}},
}

type staticEdge struct{ a, b, label, kind string }

var staticEdges = []staticEdge{
	{"telegram", "k_telegram", "TDLib", "ext"}, {"llm", "k_cognition", "OpenAI API", "ext"},
	{"k_telegram", "k_cognition", "события", "kuni"}, {"k_cognition", "k_memory", "RAG", "kuni"},
	{"k_cognition", "k_tools", "вызовы", "kuni"}, {"k_cognition", "k_media", "медиа", "kuni"},
	{"kuni", "k_cognition", "процесс", "kuni"}, {"k_tools", "catalog", "tools.json", "tools"},
	{"manager", "contracts", "манифест", "core"}, {"manager", "solver", "зависимости", "core"},
	{"manager", "installer", "замена версий", "core"}, {"manager", "state", "транзакции", "core"},
	{"manager", "lifecycle", "запуск", "core"}, {"manager", "events", "события", "core"},
	{"manager", "catalog", "каталог", "core"}, {"registry", "manager", "возможности", "core"},
	{"solver", "registry", "provides/requires", "core"}, {"panel", "manager", "управление", "core"},
	{"panel", "events", "журнал", "core"},
}

func node(id, title, group, status string, lines []string, extra map[string]any) archNode {
	if lines == nil {
		lines = []string{}
	}
	n := archNode{"id": id, "title": title, "group": group, "status": status, "lines": lines}
	for k, v := range extra {
		n[k] = v
	}
	return n
}

func pos(x, y, w, h int) map[string]any { return map[string]any{"x": x, "y": y, "w": w, "h": h} }

func buildArchitecture(m *manager.Manager, eventsCount int, tomlPath string) map[string]any {
	rows := map[string]map[string]any{}
	for _, r := range m.Status() {
		rows[r["name"].(string)] = r
	}
	enabledList := m.EnabledNames()
	enabled := map[string]bool{}
	for _, n := range enabledList {
		enabled[n] = true
	}
	manifests := map[string]*kernel.Manifest{}
	for name := range rows {
		if mf, err := m.Manifest(name, ""); err == nil {
			manifests[name] = mf
		} else {
			manifests[name] = nil
		}
	}
	problems := m.CheckIntegrity()
	var tools []json.RawMessage
	if raw, err := os.ReadFile(m.ToolsPath()); err == nil {
		var cat struct {
			Tools []json.RawMessage `json:"tools"`
		}
		if json.Unmarshal(raw, &cat) == nil {
			tools = cat.Tools
		}
	}
	kuniRow := rows["kuni"]
	kuniUp := kuniRow != nil && kuniRow["enabled"] == true && kuniRow["running"] == true

	var nodes []archNode
	var edges []map[string]any

	// модули: kuni первым, он займёт центральный слот
	names := make([]string, 0, len(rows))
	for n := range rows {
		names = append(names, n)
	}
	sort.Slice(names, func(i, j int) bool {
		if (names[i] == "kuni") != (names[j] == "kuni") {
			return names[i] == "kuni"
		}
		return names[i] < names[j]
	})
	modRows := (len(names) + len(archSlots) - 1) / len(archSlots)
	if modRows < 1 {
		modRows = 1
	}
	for i, name := range names {
		r, mf := rows[name], manifests[name]
		rowI, colI := i/len(archSlots), i%len(archSlots)
		slots := archSlots
		if rowI > 0 {
			slots = append(append([]int{}, archSlots[1:]...), archSlots[0])
		}
		health, _ := r["health"].(string)
		running, _ := r["running"].(bool)
		en, _ := r["enabled"].(bool)
		status := "idle"
		switch {
		case !en:
			status = "off"
		case health == "unhealthy" || health == "broken":
			status = "bad"
		case running || health == "healthy":
			status = "ok"
		}
		var lines []string
		if mf != nil {
			if len(mf.Provides) > 0 {
				lines = append(lines, "даёт: "+strings.Join(mf.Provides, ", "))
			}
			if len(mf.Requires) > 0 {
				lines = append(lines, "требует: "+strings.Join(mf.Requires, ", "))
			}
			if len(mf.OptionalRequires) > 0 {
				lines = append(lines, "желательно: "+strings.Join(mf.OptionalRequires, ", "))
			}
			if len(mf.Tools) > 0 {
				lines = append(lines, "инструментов: "+strconv.Itoa(len(mf.Tools)))
			}
			if len(mf.Widgets) > 0 {
				lines = append(lines, "виджетов: "+strconv.Itoa(len(mf.Widgets)))
			}
		}
		nodes = append(nodes, node("mod_"+name, name, "module", status, lines, map[string]any{
			"module": name, "version": r["version"], "kind": r["kind"], "enabled": en, "running": running, "health": health,
			"pos": pos(slots[colI], 2*archStep+rowI*archStep, 4, 4),
		}))
	}
	baseY := 2*archStep + modRows*archStep

	// внешние системы и процесс kuni
	llm := map[string]any{"available": false}
	if tomlPath != "" {
		llm = parseLLM(tomlPath)
	}
	nodes = append(nodes, node("telegram", "Telegram", "external", pick(kuniUp, "ok", "off"),
		[]string{"сеть Telegram (MTProto)", "через TDLib"}, map[string]any{"pos": pos(0, 0, 4, 4)}))
	llmAvail, _ := llm["available"].(bool)
	llmStatus, llmLines := "warn", []string{"конфигурация не найдена"}
	if llmAvail {
		llmStatus = "ok"
		host, _ := llm["host"].(string)
		host = strings.TrimPrefix(host, "https://")
		host = strings.TrimPrefix(host, "http://")
		second := toStr(llm["provider"])
		if host != "" {
			second = toStr(llm["provider"]) + " · " + host
		}
		llmLines = []string{strOr(toStr(llm["model"]), "—"), second}
	}
	nodes = append(nodes, node("llm", "LLM", "external", llmStatus, llmLines, map[string]any{"pos": pos(20, 0, 4, 4)}))
	xs := []int{0, 5, 10, 15, 20}
	for i, ki := range kuniInternals {
		nodes = append(nodes, node(ki.id, ki.title, "kuni", pick(kuniUp, "ok", "off"), ki.lines,
			map[string]any{"pos": pos(xs[i], archStep, 4, 4)}))
	}

	// ядро и менеджер
	caps, running := 0, 0
	widgetsN := 0
	for _, n := range enabledList {
		if mf := manifests[n]; mf != nil {
			caps += len(mf.Provides)
			widgetsN += len(mf.Widgets)
		}
		if rows[n]["running"] == true {
			running++
		}
	}
	versionsN := 0
	for _, r := range rows {
		if vs, ok := r["versions"].([]string); ok {
			versionsN += len(vs)
		}
	}
	integ := "целостность: ОК"
	solverStatus := "ok"
	if len(problems) > 0 {
		integ = problems[0]
		if len(integ) > 44 {
			integ = integ[:44]
		}
		solverStatus = "bad"
	}
	catStatus := "idle"
	if len(tools) > 0 || fileExists(m.ToolsPath()) {
		catStatus = "ok"
	}
	type kernelRow struct {
		id, title, group, status string
		lines                    []string
		col, krow                int
	}
	kernelRows := []kernelRow{
		{"state", "Состояние", "kernel", "ok", []string{"модулей: " + strconv.Itoa(len(rows)) + ", включено: " + strconv.Itoa(len(enabledList)), "kernel/txn.py"}, 0, 0},
		{"registry", "Реестр возможностей", "kernel", "ok", []string{"возможностей: " + strconv.Itoa(caps), "kernel/service_registry.py"}, 1, 0},
		{"manager", "Менеджер модулей", "manager", "ok", []string{"установлено: " + strconv.Itoa(len(rows)), "module_manager/manager.py"}, 2, 0},
		{"panel", "Веб-панель", "manager", "ok", []string{"WebUI, API с токеном", "internal/panel"}, 3, 0},
		{"catalog", "Каталог инструментов", "manager", catStatus, []string{"инструментов: " + strconv.Itoa(len(tools)), "tools.json → kuni"}, 4, 0},
		{"contracts", "Контракты", "kernel", "ok", []string{"виджетов: " + strconv.Itoa(widgetsN) + ", инструментов: " + strconv.Itoa(len(tools)), "kernel/contracts.go"}, 0, 1},
		{"solver", "Решатель зависимостей", "manager", solverStatus, []string{integ, "manager/solver.go"}, 1, 1},
		{"installer", "Установка и откат", "manager", "ok", []string{"версий в наличии: " + strconv.Itoa(versionsN), "manager/install.go"}, 2, 1},
		{"lifecycle", "Жизненный цикл", "kernel", "ok", []string{"запущено: " + strconv.Itoa(running) + " из " + strconv.Itoa(len(enabledList)), "kernel/lifecycle.go, health.go"}, 3, 1},
		{"events", "Шина событий", "kernel", "ok", []string{"в журнале: " + strconv.Itoa(eventsCount), "kernel/eventbus.go"}, 4, 1},
	}
	for _, k := range kernelRows {
		nodes = append(nodes, node(k.id, k.title, k.group, k.status, k.lines,
			map[string]any{"pos": pos(xs[k.col], baseY+k.krow*archStep, 4, 4)}))
	}

	// связи
	ids := map[string]bool{}
	status := map[string]string{}
	for _, n := range nodes {
		ids[n["id"].(string)] = true
		status[n["id"].(string)] = n["status"].(string)
	}
	alias := func(s string) string {
		if s == "kuni" {
			return "mod_kuni"
		}
		return s
	}
	for _, e := range staticEdges {
		a, b := alias(e.a), alias(e.b)
		if ids[a] && ids[b] {
			edges = append(edges, map[string]any{"a": a, "b": b, "label": e.label, "kind": e.kind})
		}
	}
	provider := map[string]string{}
	for _, n := range enabledList {
		if mf := manifests[n]; mf != nil {
			for _, c := range mf.Provides {
				provider[c] = n
			}
		}
	}
	for _, name := range names {
		edges = append(edges, map[string]any{"a": "manager", "b": "mod_" + name, "label": "управляет", "kind": "manage"})
		mf := manifests[name]
		if mf == nil {
			continue
		}
		for _, c := range mf.Requires {
			if p, ok := provider[c]; ok && p != name {
				edges = append(edges, map[string]any{"a": "mod_" + name, "b": "mod_" + p, "label": c, "kind": "dep"})
			}
		}
		for _, c := range mf.OptionalRequires {
			if p, ok := provider[c]; ok && p != name {
				edges = append(edges, map[string]any{"a": "mod_" + name, "b": "mod_" + p, "label": c + " (желательно)", "kind": "opt"})
			}
		}
		if len(mf.Tools) > 0 && enabled[name] {
			edges = append(edges, map[string]any{"a": "mod_" + name, "b": "catalog", "label": "инструменты", "kind": "tools"})
		}
		if len(mf.Widgets) > 0 && enabled[name] {
			edges = append(edges, map[string]any{"a": "mod_" + name, "b": "panel", "label": "виджеты", "kind": "widgets"})
		}
	}
	for _, e := range edges {
		a, b := e["a"].(string), e["b"].(string)
		e["off"] = status[a] == "off" || status[b] == "off"
	}
	if nodes == nil {
		nodes = []archNode{}
	}
	if edges == nil {
		edges = []map[string]any{}
	}
	return map[string]any{"nodes": nodes, "edges": edges, "generated": roundTo(float64(time.Now().UnixNano())/1e9, 1)}
}

func pick(c bool, a, b string) string {
	if c {
		return a
	}
	return b
}

func strOr(v, def string) string {
	if v == "" {
		return def
	}
	return v
}

func fileExists(p string) bool {
	_, err := os.Stat(p)
	return err == nil
}
