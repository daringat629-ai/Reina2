/* Панель «Нулевое ядро»: сетка перетаскиваемых виджетов. Без внешних библиотек и без innerHTML. */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.ZC = api;
    if (root.document && !root.__ZC_NO_BOOT) {
      api.boot({ document: root.document, window: root, fetch: root.fetch.bind(root), storage: root.localStorage,
                 setInterval: root.setInterval.bind(root), setTimeout: root.setTimeout.bind(root),
                 location: root.location, history: root.history,
                 Layout: root.ZCLayout, requestAnimationFrame: root.requestAnimationFrame && root.requestAnimationFrame.bind(root),
                 reducedMotion: !!(root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches) });
    }
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var ROW_H = 30, MIN_ROW_H = 20, SNUG_FROM = 28, FULL_CELL = 78, DEFAULT_GAP = 14;
  /* Полный вид (как на видео): ряды не ниже 28 и столбцы не уже 78 пикселей (экран от 1920 в ширину). Иначе компактный вид, чтобы ничего не обрезалось.
     Положения виджетов поставляемых деталей по умолчанию: в раскладке видео. */
  var DEFAULT_POS = { 'm:watchdog:status': { x: 0, y: 12, w: 6, h: 7 }, 'm:demo_counter:counter': { x: 17, y: 10, w: 6, h: 8 } };
  /* Цвета нитей (canvas не видит CSS-переменные) */
  var KIND_RGB = { dep: '61,220,132', tools: '255,183,77', widgets: '199,146,234', ext: '255,183,77', kuni: '199,146,234', opt: '150,170,210' };
  var THREAD_COLORS = {
    black: { line: 'rgba(110,168,255,0.55)', glow: 'rgba(110,168,255,0.12)', module: 'rgba(61,220,132,0.6)', pulse: 'rgba(200,225,255,0.95)', hot: 'rgba(170,205,255,0.95)', hotGlow: 'rgba(110,168,255,0.30)', label: 'rgba(175,195,235,0.95)', labelBg: 'rgba(0,0,0,0.78)', err: 'rgba(255,107,107,0.97)' },
    dark: { line: 'rgba(122,162,255,0.55)', glow: 'rgba(122,162,255,0.12)', module: 'rgba(88,214,141,0.6)', pulse: 'rgba(205,220,255,0.95)', hot: 'rgba(175,200,255,0.95)', hotGlow: 'rgba(122,162,255,0.30)', label: 'rgba(175,195,235,0.95)', labelBg: 'rgba(7,11,28,0.78)', err: 'rgba(255,107,107,0.97)' },
    aurora: { line: 'rgba(94,234,212,0.55)', glow: 'rgba(94,234,212,0.13)', module: 'rgba(74,222,128,0.62)', pulse: 'rgba(204,251,241,0.97)', hot: 'rgba(167,243,232,0.97)', hotGlow: 'rgba(94,234,212,0.32)', label: 'rgba(190,205,245,0.97)', labelBg: 'rgba(8,13,34,0.80)', err: 'rgba(251,113,133,0.97)' },
    neon: { line: 'rgba(57,255,156,0.55)', glow: 'rgba(57,255,156,0.12)', module: 'rgba(255,210,74,0.62)', pulse: 'rgba(220,255,236,0.98)', hot: 'rgba(160,255,208,0.98)', hotGlow: 'rgba(57,255,156,0.32)', label: 'rgba(170,240,205,0.97)', labelBg: 'rgba(5,6,10,0.82)', err: 'rgba(255,77,141,0.98)' },
    paper: { line: 'rgba(184,67,28,0.50)', glow: 'rgba(184,67,28,0.09)', module: 'rgba(77,124,15,0.62)', pulse: 'rgba(184,67,28,0.95)', hot: 'rgba(184,67,28,0.95)', hotGlow: 'rgba(184,67,28,0.24)', label: 'rgba(80,60,36,0.97)', labelBg: 'rgba(244,238,226,0.88)', err: 'rgba(185,28,28,0.97)' },
    light: { line: 'rgba(47,85,212,0.5)', glow: 'rgba(47,85,212,0.10)', module: 'rgba(30,142,78,0.6)', pulse: 'rgba(47,85,212,0.95)', hot: 'rgba(47,85,212,0.95)', hotGlow: 'rgba(47,85,212,0.25)', label: 'rgba(40,52,110,0.95)', labelBg: 'rgba(238,241,251,0.85)', err: 'rgba(192,57,43,0.97)' }
  };
  var I18N = {
    ru: { app: 'Нулевое ядро', system: 'Система', llm: 'LLM', transports: 'Транспорты', generation: 'Генерация',
          stats: 'Статистика', load: 'График нагрузки', log: 'Живой лог', plugins: 'Плагины', tools: 'Тулы',
          settings: 'Настройки', language: 'Язык', theme: 'Тема', dark: 'Тёмная', light: 'Светлая', black: 'Чёрная', aurora: 'Аврора', neon: 'Неон', paper: 'Бумага', gap: 'Отступ между виджетами', view_panel: 'Панель', view_arch: 'Архитектура', node_ok: 'в норме', node_idle: 'ожидает', node_warn: 'внимание', node_bad: 'ошибка', node_off: 'не активен', confirm_title: 'Подтверждение', log_lines: 'Строк в логе',
          save: 'Сохранить', cancel: 'Отмена', reset_layout: 'Сбросить раскладку', change_token: 'Сменить токен',
          token_title: 'Вход', token_hint: 'Токен панели (файл panel_token)', enter: 'Войти', hide: 'Скрыть',
          restore: 'Скрытые виджеты', nothing_hidden: 'Скрытых виджетов нет', close: 'Закрыть', show: 'Показать',
          version: 'версия', os: 'ОС', home: 'каталог', uptime: 'работает', modules: 'модулей', integrity: 'целостность',
          host: 'хост', provider: 'провайдер', model: 'модель', endpoint: 'адрес', embedding: 'эмбеддинги', lockdown: 'доступ',
          none: 'нет', no_data: 'нет данных', generating: 'идёт генерация', idle: 'нет активной генерации',
          last_gen: 'последняя', ago: 'назад', s: 'с', min: 'мин', h: 'ч',
          st_llm_today: 'запросов к LLM сегодня', st_shell: 'команд shell (сессия)', st_sent: 'сообщений отправлено (сессия)',
          st_external: 'вызовов внешних инструментов (сессия)', st_refused: 'отказов охранника (сессия)', st_http: 'ошибок LLM (сессия)', st_errors: 'ошибок (сессия)',
          running: 'работает', stopped: 'остановлен', enable: 'включить', disable: 'выключить', start: 'запустить',
          stop: 'остановить', restart: 'перезапустить', confirm: 'Выполнить', error: 'Ошибка', updated: 'обновлено',
          parts: 'Детали', parts_title: 'Детали: создать или загрузить', template: 'Заготовка', tpl_pick: '— выберите заготовку —', part_name: 'Имя (латиницей)',
          part_kind: 'Вид', part_widget: 'Виджет', part_tool: 'Инструмент для бота', part_tool_hint: 'auto или своё имя', part_provides: 'Даёт', part_requires: 'Нужно',
          part_optional: 'Желательно', part_desc: 'Описание', part_enable: 'включить сразу', part_create: 'Создать', upload_zip: 'или загрузить готовую деталь (zip)',
          kind_library: 'библиотека (виджет, инструмент)', kind_service: 'служба', kind_job: 'периодическая задача', name_required: 'укажите имя',
          part_created: 'деталь создана', part_not_enabled: 'создана, но не включена', uploaded: 'загружена (выключена)', uploading: 'загрузка', too_big: 'файл больше 8 МБ',
          module_settings: 'Настройки детали', no_settings: 'у детали нет настроек', download_zip: 'Скачать zip', remove: 'Удалить', remove_q: 'Удалить деталь',
          remove_note: 'Перед удалением копия сохранится в zip (папка removed); вернуть деталь можно загрузкой этого файла.', remove_data: 'удалить также данные детали',
          removed: 'удалена', protected_note: 'защищённая деталь: из панели не удаляется', saved_restart: 'сохранено; перезапустите деталь, чтобы настройки вступили в силу',
          provides_l: 'даёт', requires_l: 'нужно', optional_l: 'желательно',
          new_token: 'Новый токен', new_token_q: 'Выпустить новый токен? Старый перестанет работать.', new_token_title: 'Новый токен',
          new_token_note: 'Сохраните его: другим устройствам нужен новый токен. Киоск на ноутбуке перезапустите: sudo systemctl restart zerocore-kiosk.',
          chip_bot_title: 'состояние бота kuni', chip_no_bot: 'бота нет', chip_bot_on: 'бот работает', chip_bot_off: 'бот остановлен', chip_rate_title: 'событий бота за последнюю минуту', chip_per_min: 'событий/мин', chip_err_title: 'ошибок за 10 минут', chip_errors: 'ошибок',
          insp_min: 'событий за минуту', insp_in: 'входящих', insp_out: 'исходящих', insp_errs: 'ошибок за 10 мин', insp_recent: 'Последние события', insp_none: 'событий пока не было', spark_title: 'события за 10 минут',
          sm_open: 'Самостоятельные детали', sm_title: 'Самостоятельные детали Марин', sm_enable: 'Марин может сама писать себе детали', sm_enable_q: 'Включить? Марин сможет сама писать себе детали на Python: система проверит код, прогонит инструменты, подключит деталь, и бот сразу начнёт ею пользоваться, без твоего подтверждения. Всё записывается в журнал, остановить можно здесь одним нажатием.',
          sm_off_q: 'Выключить? Марин больше не сможет создавать детали; уже созданные продолжат работать.', sm_stop_all: 'Остановить всё', sm_stop_all_q: 'Выключить самостоятельность и отключить все детали, которые Марин написала сама?',
          sm_info: 'деталей', sm_hour: 'попыток за час', sm_walls: 'Жёсткие стены: Марин управляет только своими деталями; её детали без подписи владельца, поэтому не могут менять её промпты и реакции; код проверяется и запускается с лимитами памяти и времени, без ключей окружения.',
          sm_none: 'Деталей пока нет: Марин напишет, когда ей понадобится новый инструмент.', sm_code: 'Код', sm_hide_code: 'Скрыть код', sm_disable: 'Отключить', sm_enable_btn: 'Включить', sm_remove: 'Удалить', sm_remove_q: 'Удалить деталь? Её данные сохранятся.',
          sm_journal: 'Журнал', sm_journal_none: 'записей пока нет', sm_tools: 'инструменты', st_active: 'работает', st_disabled: 'отключена', st_removed: 'удалена', sm_off_note: 'Самостоятельность выключена: инструментов создания у бота нет.', sm_on_note: 'Включено: бот может создавать детали.',
          sys_open: 'Система и диагностика', sys_title: 'Система и диагностика', sys_doctor: 'Диагностика', sys_check: 'Проверить', sys_checking: 'проверяю…', sys_summary: 'Итог: ошибок {bad}, предупреждений {warn}', sys_fix: 'как исправить',
          sys_avail: 'Готовые детали из поставки', sys_install: 'Установить', sys_installed: 'установлена', sys_avail_none: 'все готовые детали установлены', sys_wire: 'Связь с ботом', sys_wire_btn: 'Подключить каталог инструментов к боту',
          sys_wire_note: 'Прописывает путь к каталогу инструментов в config.toml бота (с копией прежнего файла). Нужно один раз; бот подхватит инструменты сам.', sys_wire_done: 'config.toml', sys_wire_added: 'добавлено', sys_wire_updated: 'обновлено', sys_wire_unchanged: 'без изменений',
          btn_rollback: 'Откатить версию', rollback_q: 'Вернуть предыдущую версию детали? Текущая останется для обратного переключения.', rollback_done: 'версия', versions_label: 'версии',
          eco_open: 'Экосистема', eco_title: 'Экосистема деталей', eco_catalog: 'Описания инструментов бота', eco_tools: 'инструментов', eco_tokens: 'токенов', eco_warn: 'Много: каждое описание занимает место в контексте модели, ответы могут ухудшиться и подорожать. Выключите наборы, которыми не пользуетесь.',
          eco_ok: 'Объём в норме.', eco_set_on_q: 'Включить набор «{n}»? Недостающие детали будут установлены, их инструменты сразу появятся у бота.', eco_set_rule_q: ' Набор «Основа» ещё добавит в промпт Марин правило о том, как пользоваться расписанием и экосистемой (отозвать можно в ⚙ у детали eco_scheduler).',
          eco_set_off_q: 'Выключить набор «{n}»? Инструменты исчезнут у бота; данные сохранятся.', eco_state_on: 'включена', eco_state_off: 'выключена', eco_state_missing: 'не установлена', eco_pending: 'правило промпта ждёт одобрения',
          eco_note: 'Деталь «Контент-план» сама ничего не публикует: черновики и очередь хранит она, а публикует Марин своим инструментом Telegram.',
          sec_title: 'Секреты', sec_note: 'Ключи доступа для этой детали. После сохранения значение не показывается; деталь получает его как переменную ZEROCORE_SECRET_<ИМЯ>, другие детали и бот его не видят.', sec_set: 'задан', sec_name: 'ИМЯ (например NEWS_KEY)', sec_value: 'значение', sec_save: 'Сохранить секрет', sec_delete: 'Удалить', sec_saved: 'секрет сохранён', sec_need: 'укажите имя и значение',
          pro_label: 'Расширенный вид (датчики, плитки, бейджи)', pal_title: 'Командная палитра', pal_hint: 'Введите команду; ↑ ↓ выбор, Enter выполнить, Esc закрыть', pal_none: 'ничего не найдено', pal_open: 'Командная палитра (Ctrl+K)',
          pal_view: 'Открыть', pal_theme: 'Тема', pal_pro_on: 'Расширенный вид: включить', pal_pro_off: 'Расширенный вид: выключить', pal_refresh: 'Обновить данные', pal_mod_on: 'Включить', pal_mod_off: 'Выключить', pal_mod_restart: 'Перезапустить', pal_mod_cfg: 'Настройки детали',
          gauge_load: 'нагрузка', gauge_ram: 'память', st_tile_llm: 'запросов к LLM', st_tile_shell: 'команд shell', st_tile_sent: 'сообщений', st_tile_ext: 'внешних вызовов', st_tile_refused: 'отказов', st_tile_err: 'ошибок', log_search: 'поиск по логу', run_on: 'работает', run_off: 'остановлен',
          chat_open: 'Марин (чат)', chat_title: 'Марин', chat_ph: 'Напишите Марин… (Enter отправить, Shift+Enter новая строка)', chat_send: 'Отправить', chat_stop: 'Стоп', chat_think: 'Марин думает…', chat_reset: 'Начать заново', chat_reset_q: 'Начать разговор заново? Прежний будет стёрт (журнал действий останется).',
          chat_confirm_title: 'Марин просит подтверждения', chat_allow: 'Разрешить', chat_deny: 'Отклонить', chat_why: 'причина', chat_mode: 'Подтверждения', chat_mode_dangerous: 'опасное (по умолчанию)', chat_mode_always: 'всегда, кроме чтения', chat_mode_never: 'никогда: полный доступ',
          chat_mode_warn: 'Полный доступ: Марин выполняет всё сама, без вопросов (с правами пользователя панели).', chat_off: 'Чат выключен', chat_no_llm: 'Настройки модели не найдены в config.toml бота: чат не может отвечать.', chat_enabled: 'чат включён', chat_audit: 'Журнал действий Марин', chat_empty: 'Напишите что-нибудь: Марин может смотреть логи, управлять деталями, править промпты и выполнять команды.',
          chat_usage: 'сегодня', chat_model: 'модель', chat_steps: 'шагов',
          pr_open: 'Промпты Марин', pr_title: 'Промпты Марин', pr_file: 'Файл', pr_note: 'Заметка к правке', pr_save: 'Сохранить', pr_saved: 'Сохранено. Вступит в силу после перезапуска бота.', pr_restart: 'Перезапустить бота', pr_history: 'История версий', pr_none: 'правок ещё не было', pr_diff: 'Сравнить с текущим', pr_restore: 'Вернуть эту версию', pr_restore_q: 'Вернуть эту версию? Текущий текст сохранится в истории.',
          pr_blocks: 'Блоки ядра (править нельзя, они от деталей)', pr_lines: 'строк', pr_nodiff: 'различий нет',
          bk_open: 'Резервные копии', bk_title: 'Резервные копии', bk_create: 'Создать копию', bk_note: 'Заметка (необязательно)', bk_warn: 'В копии лежат настройки, секреты и config.toml бота: храните её как пароль (права только владельцу).', bk_restore: 'Восстановить', bk_restore_q: 'Восстановить из копии «{n}»? Файлы будут заменены; перед этим автоматически сделается копия текущего состояния. После этого перезапустите бота.',
          bk_delete: 'Удалить', bk_delete_q: 'Удалить копию «{n}»?', bk_auto: 'Автоматически', bk_every: 'каждые, ч', bk_keep: 'хранить', bk_save: 'Сохранить', bk_none: 'копий ещё нет', bk_done: 'копия создана', bk_restored: 'восстановлено файлов', bk_safety: 'страховочная копия', bk_files: 'файлов',
          al_open: 'Оповещения в Telegram', al_title: 'Оповещения в Telegram', al_how: 'Нужен отдельный бот от @BotFather (его токен, не токен Марин) и ваш числовой chat_id (узнать у @userinfobot). Напишите своему боту /start, иначе он не сможет писать вам.', al_enabled: 'Включить оповещения', al_token: 'Токен бота', al_token_set: 'токен задан', al_token_save: 'Сохранить токен',
          al_chat: 'chat_id', al_events: 'О чём сообщать', al_cooldown: 'Не чаще, мин', al_errors: 'Порог ошибок за 10 мин', al_disk: 'Порог диска, %', al_save: 'Сохранить', al_test: 'Отправить проверку', al_sent: 'проверочное сообщение отправлено', al_saved: 'сохранено',
          hs_open: 'История и расходы', hs_title: 'История за сутки и расходы на модель', hs_hours: 'период', hs_load: 'нагрузка', hs_mem: 'память %', hs_disk: 'диск %', hs_battery: 'батарея %', hs_temp: 'температура °C', hs_nodata: 'данных пока нет (история пишется раз в минуту)', hs_usage: 'Расходы на модель (чат панели)',
          hs_day: 'день', hs_req: 'запросов', hs_in: 'токенов вход', hs_out: 'токенов выход', hs_cost: 'стоимость', hs_total: 'всего', hs_unknown: 'стоимость известна не для всех', hs_bot: 'Запросы самого бота в этих числах не учтены: его журналы токенов не содержат.',
          short_on: 'вкл', short_off: 'выкл', update: 'Обновление', upd_title: 'Обновление ядра и бота', upd_core: 'Ядро (Нулевое ядро)', upd_bot: 'Бот (программа kuni)', upd_version: 'версия', upd_build: 'сборка',
          upd_backups: 'копий для отката', upd_pick_core: 'Архив с папкой zero_core (kuni-marin-integrated*.zip):', upd_pick_bot: 'Артефакт сборки (kuni-linux*.zip) или файл kuni:',
          upd_uploading: 'загрузка и проверка', upd_checked: 'Проверено', upd_selftest_ok: 'новый код запущен и ответил на проверке', upd_new_version: 'новая версия',
          upd_now: 'сейчас', upd_apply_core: 'Применить и перезапустить панель', upd_core_q: 'Заменить ядро новой версией? Прежняя сохранится для отката, панель перезапустится сама.',
          upd_rollback_core: 'Откатить ядро', upd_rollback_q: 'Вернуть прежнюю версию? Текущая тоже сохранится.', upd_apply_bot: 'Заменить программу бота', upd_bot_q: 'Заменить программу бота? Работающий бот не тронется до перезапуска; прежняя программа сохранится.',
          upd_rollback_bot: 'Откатить программу бота', upd_restart_bot: 'перезапустить бота сразу после замены', upd_restarting: 'Панель перезапускается…', upd_wait: 'Подождите несколько секунд: страница обновится сама.',
          upd_bot_replaced: 'Программа бота заменена; копия сохранена', upd_bot_still_old: 'Работающий бот ещё на прежней версии: перезапустите его, чтобы заработала новая.', upd_bot_restarted: 'бот перезапущен',
          upd_no_bot_dir: 'каталог бота не задан (настройка kuni_dir модуля kuni)', upd_running: 'бот работает', upd_stopped: 'бот остановлен', upd_program: 'программа', upd_changed: 'изменена', upd_mb: 'МБ',
          upd_ldd_ok: 'формат Linux, системных библиотек хватает', upd_no_staged: 'ничего не подготовлено', upd_done_core: 'Ядро заменено', upd_too_big: 'файл слишком большой',
          keys_title: 'Ключи и патчи', trust_trusted: 'подписана вашим ключом', trust_unsigned: 'не подписана', trust_modified: 'изменена после подписи', trust_foreign: 'подписана чужим ключом',
          trust_approved: 'одобрена вами здесь', trust_allowed: 'ключи этой детали действуют', trust_not_allowed: 'ключи этой детали не действуют, пока вы её не подпишете или не одобрите',
          trust_label: 'Доверие', btn_sign: 'Подписать моим ключом', btn_approve: 'Одобрить здесь', btn_revoke: 'Снять одобрение', btn_resume: 'Возобновить реакцию',
          patch_prompt_append: 'добавка к промпту', patch_hook_event: 'реакция на событие', pst_active: 'действует', pst_pending_trust: 'ждёт доверия', pst_inactive: 'деталь выключена',
          pst_no_bot_dir: 'нет каталога бота', pst_error: 'ошибка', pst_unknown: 'ещё не применялось', prompt_note: 'подействует после перезапуска бота', hook_paused: 'приостановлена после сбоев',
          part_prompt: 'Добавка к промпту (файл)', part_hook: 'Реакция на событие', ev_message: 'сообщение', ev_llm: 'запрос к LLM', ev_tool: 'инструмент', ev_tools: 'каталог инструментов',
          ev_guard: 'охранник', ev_manager: 'менеджер', ev_error: 'ошибка', trust_done: 'доверие обновлено',
          rss: 'память kuni', all: 'все', core_src: 'ядро', kuni_src: 'kuni', tools_count: 'инструментов' },
    en: { app: 'Zero Core', system: 'System', llm: 'LLM', transports: 'Transports', generation: 'Generation',
          stats: 'Statistics', load: 'Load graph', log: 'Live log', plugins: 'Plugins', tools: 'Tools',
          settings: 'Settings', language: 'Language', theme: 'Theme', dark: 'Dark', light: 'Light', black: 'Black', aurora: 'Aurora', neon: 'Neon', paper: 'Paper', gap: 'Widget spacing', view_panel: 'Panel', view_arch: 'Architecture', node_ok: 'healthy', node_idle: 'idle', node_warn: 'attention', node_bad: 'error', node_off: 'inactive', confirm_title: 'Confirmation', log_lines: 'Log lines',
          save: 'Save', cancel: 'Cancel', reset_layout: 'Reset layout', change_token: 'Change token',
          token_title: 'Sign in', token_hint: 'Panel token (panel_token file)', enter: 'Enter', hide: 'Hide',
          restore: 'Hidden widgets', nothing_hidden: 'No hidden widgets', close: 'Close', show: 'Show',
          version: 'version', os: 'OS', home: 'home', uptime: 'uptime', modules: 'modules', integrity: 'integrity',
          host: 'host', provider: 'provider', model: 'model', endpoint: 'endpoint', embedding: 'embeddings', lockdown: 'access',
          none: 'none', no_data: 'no data', generating: 'generating', idle: 'no active generation',
          last_gen: 'last', ago: 'ago', s: 's', min: 'min', h: 'h',
          st_llm_today: 'LLM requests today', st_shell: 'shell commands (session)', st_sent: 'messages sent (session)',
          st_external: 'external tool calls (session)', st_refused: 'guard refusals (session)', st_http: 'LLM errors (session)', st_errors: 'errors (session)',
          running: 'running', stopped: 'stopped', enable: 'enable', disable: 'disable', start: 'start',
          stop: 'stop', restart: 'restart', confirm: 'Run', error: 'Error', updated: 'updated',
          parts: 'Parts', parts_title: 'Parts: create or upload', template: 'Template', tpl_pick: '— pick a template —', part_name: 'Name (latin)',
          part_kind: 'Kind', part_widget: 'Widget', part_tool: 'Tool for the bot', part_tool_hint: 'auto or your own name', part_provides: 'Provides', part_requires: 'Requires',
          part_optional: 'Optional', part_desc: 'Description', part_enable: 'enable right away', part_create: 'Create', upload_zip: 'or upload a ready part (zip)',
          kind_library: 'library (widget, tool)', kind_service: 'service', kind_job: 'periodic job', name_required: 'enter a name',
          part_created: 'part created', part_not_enabled: 'created, but not enabled', uploaded: 'uploaded (disabled)', uploading: 'uploading', too_big: 'file is larger than 8 MB',
          module_settings: 'Part settings', no_settings: 'this part has no settings', download_zip: 'Download zip', remove: 'Remove', remove_q: 'Remove part',
          remove_note: 'A zip copy is saved before removal (removed folder); upload that file to bring the part back.', remove_data: 'also delete the part data',
          removed: 'removed', protected_note: 'protected part: cannot be removed from the panel', saved_restart: 'saved; restart the part to apply the settings',
          provides_l: 'provides', requires_l: 'requires', optional_l: 'optional',
          new_token: 'New token', new_token_q: 'Issue a new token? The old one will stop working.', new_token_title: 'New token',
          new_token_note: 'Save it: other devices need the new token. Restart the laptop kiosk: sudo systemctl restart zerocore-kiosk.',
          chip_bot_title: 'kuni bot state', chip_no_bot: 'no bot', chip_bot_on: 'bot running', chip_bot_off: 'bot stopped', chip_rate_title: 'bot events in the last minute', chip_per_min: 'events/min', chip_err_title: 'errors in 10 minutes', chip_errors: 'errors',
          insp_min: 'events per minute', insp_in: 'in', insp_out: 'out', insp_errs: 'errors in 10 min', insp_recent: 'Recent events', insp_none: 'no events yet', spark_title: 'events in 10 minutes',
          sm_open: 'Self-made parts', sm_title: 'Marin\'s self-made parts', sm_enable: 'Marin may write parts for herself', sm_enable_q: 'Turn on? Marin will be able to write her own Python parts: the system checks the code, runs the tools, connects the part and the bot starts using it right away, with no confirmation from you. Everything is logged and you can stop it here with one click.',
          sm_off_q: 'Turn off? Marin will no longer be able to create parts; existing ones keep working.', sm_stop_all: 'Stop everything', sm_stop_all_q: 'Turn off self-modification and disable all parts Marin wrote herself?',
          sm_info: 'parts', sm_hour: 'attempts per hour', sm_walls: 'Hard walls: Marin manages only her own parts; they carry no owner signature, so they cannot change her prompts or reactions; code is checked and runs with memory and time limits and no environment keys.',
          sm_none: 'No parts yet: Marin will write one when she needs a new tool.', sm_code: 'Code', sm_hide_code: 'Hide code', sm_disable: 'Disable', sm_enable_btn: 'Enable', sm_remove: 'Remove', sm_remove_q: 'Remove the part? Its data is kept.',
          sm_journal: 'Journal', sm_journal_none: 'no entries yet', sm_tools: 'tools', st_active: 'running', st_disabled: 'disabled', st_removed: 'removed', sm_off_note: 'Self-modification is off: the bot has no creation tools.', sm_on_note: 'On: the bot can create parts.',
          sys_open: 'System and diagnostics', sys_title: 'System and diagnostics', sys_doctor: 'Diagnostics', sys_check: 'Check', sys_checking: 'checking…', sys_summary: 'Result: {bad} errors, {warn} warnings', sys_fix: 'how to fix',
          sys_avail: 'Ready-made parts shipped with the core', sys_install: 'Install', sys_installed: 'installed', sys_avail_none: 'all ready-made parts are installed', sys_wire: 'Link with the bot', sys_wire_btn: 'Connect the tool catalog to the bot',
          sys_wire_note: 'Writes the path of the tool catalog into the bot config.toml (with a backup of the old file). Needed once; the bot picks tools up by itself.', sys_wire_done: 'config.toml', sys_wire_added: 'added', sys_wire_updated: 'updated', sys_wire_unchanged: 'unchanged',
          btn_rollback: 'Roll back version', rollback_q: 'Return to the previous version of the part? The current one stays for switching back.', rollback_done: 'version', versions_label: 'versions',
          eco_open: 'Ecosystem', eco_title: 'Parts ecosystem', eco_catalog: 'Bot tool descriptions', eco_tools: 'tools', eco_tokens: 'tokens', eco_warn: 'That is a lot: every description takes space in the model context, answers may get worse and more expensive. Turn off the sets you do not use.',
          eco_ok: 'Size is fine.', eco_set_on_q: 'Turn on the set "{n}"? Missing parts will be installed and their tools appear for the bot at once.', eco_set_rule_q: ' The Base set also adds a rule to Marin\'s prompt about using the schedule and the ecosystem (you can revoke it in the eco_scheduler part dialog).',
          eco_set_off_q: 'Turn off the set "{n}"? Its tools disappear for the bot; data is kept.', eco_state_on: 'on', eco_state_off: 'off', eco_state_missing: 'not installed', eco_pending: 'prompt rule waits for approval',
          eco_note: 'The Channel plan part never publishes by itself: it keeps drafts and the queue, and Marin publishes with her own Telegram tool.',
          sec_title: 'Secrets', sec_note: 'Access keys for this part. After saving the value is never shown; the part gets it as the variable ZEROCORE_SECRET_<NAME>, other parts and the bot cannot see it.', sec_set: 'set', sec_name: 'NAME (for example NEWS_KEY)', sec_value: 'value', sec_save: 'Save secret', sec_delete: 'Delete', sec_saved: 'secret saved', sec_need: 'enter a name and a value',
          pro_label: 'Advanced look (gauges, tiles, badges)', pal_title: 'Command palette', pal_hint: 'Type a command; ↑ ↓ to choose, Enter to run, Esc to close', pal_none: 'nothing found', pal_open: 'Command palette (Ctrl+K)',
          pal_view: 'Open', pal_theme: 'Theme', pal_pro_on: 'Advanced look: turn on', pal_pro_off: 'Advanced look: turn off', pal_refresh: 'Refresh data', pal_mod_on: 'Enable', pal_mod_off: 'Disable', pal_mod_restart: 'Restart', pal_mod_cfg: 'Part settings',
          gauge_load: 'load', gauge_ram: 'memory', st_tile_llm: 'LLM requests', st_tile_shell: 'shell commands', st_tile_sent: 'messages', st_tile_ext: 'external calls', st_tile_refused: 'refusals', st_tile_err: 'errors', log_search: 'search the log', run_on: 'running', run_off: 'stopped',
          chat_open: 'Marin (chat)', chat_title: 'Marin', chat_ph: 'Write to Marin… (Enter sends, Shift+Enter new line)', chat_send: 'Send', chat_stop: 'Stop', chat_think: 'Marin is thinking…', chat_reset: 'Start over', chat_reset_q: 'Start the conversation over? The old one is erased (the action journal stays).',
          chat_confirm_title: 'Marin asks for confirmation', chat_allow: 'Allow', chat_deny: 'Deny', chat_why: 'reason', chat_mode: 'Confirmations', chat_mode_dangerous: 'dangerous things (default)', chat_mode_always: 'always, except reading', chat_mode_never: 'never: full access',
          chat_mode_warn: 'Full access: Marin does everything herself without asking (with the rights of the panel user).', chat_off: 'Chat is off', chat_no_llm: 'Model settings not found in the bot config.toml: the chat cannot answer.', chat_enabled: 'chat enabled', chat_audit: 'Marin action journal', chat_empty: 'Write something: Marin can read logs, manage parts, edit prompts and run commands.',
          chat_usage: 'today', chat_model: 'model', chat_steps: 'steps',
          pr_open: 'Marin prompts', pr_title: 'Marin prompts', pr_file: 'File', pr_note: 'Note for the edit', pr_save: 'Save', pr_saved: 'Saved. Takes effect after the bot restarts.', pr_restart: 'Restart the bot', pr_history: 'Version history', pr_none: 'no edits yet', pr_diff: 'Compare with current', pr_restore: 'Restore this version', pr_restore_q: 'Restore this version? The current text is kept in the history.',
          pr_blocks: 'Core blocks (cannot be edited, they belong to parts)', pr_lines: 'lines', pr_nodiff: 'no differences',
          bk_open: 'Backups', bk_title: 'Backups', bk_create: 'Create backup', bk_note: 'Note (optional)', bk_warn: 'A backup holds settings, secrets and the bot config.toml: keep it like a password (owner-only permissions).', bk_restore: 'Restore', bk_restore_q: 'Restore from the backup "{n}"? Files will be replaced; a backup of the current state is made first. Restart the bot afterwards.',
          bk_delete: 'Delete', bk_delete_q: 'Delete the backup "{n}"?', bk_auto: 'Automatic', bk_every: 'every, h', bk_keep: 'keep', bk_save: 'Save', bk_none: 'no backups yet', bk_done: 'backup created', bk_restored: 'files restored', bk_safety: 'safety backup', bk_files: 'files',
          al_open: 'Telegram alerts', al_title: 'Telegram alerts', al_how: 'You need a separate bot from @BotFather (its token, not Marin\'s) and your numeric chat_id (ask @userinfobot). Send /start to your bot first, otherwise it cannot write to you.', al_enabled: 'Enable alerts', al_token: 'Bot token', al_token_set: 'token set', al_token_save: 'Save token',
          al_chat: 'chat_id', al_events: 'What to report', al_cooldown: 'No more often than, min', al_errors: 'Error threshold per 10 min', al_disk: 'Disk threshold, %', al_save: 'Save', al_test: 'Send a test', al_sent: 'test message sent', al_saved: 'saved',
          hs_open: 'History and costs', hs_title: 'Daily history and model costs', hs_hours: 'period', hs_load: 'load', hs_mem: 'memory %', hs_disk: 'disk %', hs_battery: 'battery %', hs_temp: 'temperature °C', hs_nodata: 'no data yet (history is written once a minute)', hs_usage: 'Model costs (panel chat)',
          hs_day: 'day', hs_req: 'requests', hs_in: 'tokens in', hs_out: 'tokens out', hs_cost: 'cost', hs_total: 'total', hs_unknown: 'cost is not known for all', hs_bot: 'Requests of the bot itself are not counted here: its logs contain no tokens.',
          short_on: 'on', short_off: 'off', update: 'Update', upd_title: 'Update core and bot', upd_core: 'Core (Zero Core)', upd_bot: 'Bot (kuni program)', upd_version: 'version', upd_build: 'build',
          upd_backups: 'rollback copies', upd_pick_core: 'Archive with the zero_core folder (kuni-marin-integrated*.zip):', upd_pick_bot: 'Build artifact (kuni-linux*.zip) or the kuni file:',
          upd_uploading: 'uploading and checking', upd_checked: 'Checked', upd_selftest_ok: 'the new code was started and answered the check', upd_new_version: 'new version',
          upd_now: 'now', upd_apply_core: 'Apply and restart the panel', upd_core_q: 'Replace the core with the new version? The old one is kept for rollback and the panel restarts itself.',
          upd_rollback_core: 'Roll back the core', upd_rollback_q: 'Restore the previous version? The current one is kept too.', upd_apply_bot: 'Replace the bot program', upd_bot_q: 'Replace the bot program? The running bot is untouched until restart; the old program is kept.',
          upd_rollback_bot: 'Roll back the bot program', upd_restart_bot: 'restart the bot right after replacing', upd_restarting: 'The panel is restarting…', upd_wait: 'Wait a few seconds: the page reloads by itself.',
          upd_bot_replaced: 'Bot program replaced; copy saved', upd_bot_still_old: 'The running bot is still on the old version: restart it to use the new one.', upd_bot_restarted: 'bot restarted',
          upd_no_bot_dir: 'bot directory is not set (kuni_dir setting of the kuni module)', upd_running: 'bot is running', upd_stopped: 'bot is stopped', upd_program: 'program', upd_changed: 'changed', upd_mb: 'MB',
          upd_ldd_ok: 'Linux format, system libraries are present', upd_no_staged: 'nothing prepared', upd_done_core: 'Core replaced', upd_too_big: 'file is too large',
          keys_title: 'Keys and patches', trust_trusted: 'signed with your key', trust_unsigned: 'not signed', trust_modified: 'changed after signing', trust_foreign: 'signed with a foreign key',
          trust_approved: 'approved by you here', trust_allowed: 'the keys of this part are active', trust_not_allowed: 'the keys of this part are inactive until you sign or approve it',
          trust_label: 'Trust', btn_sign: 'Sign with my key', btn_approve: 'Approve here', btn_revoke: 'Revoke approval', btn_resume: 'Resume reaction',
          patch_prompt_append: 'prompt addition', patch_hook_event: 'event reaction', pst_active: 'active', pst_pending_trust: 'waiting for trust', pst_inactive: 'part is disabled',
          pst_no_bot_dir: 'no bot directory', pst_error: 'error', pst_unknown: 'not applied yet', prompt_note: 'takes effect after the bot restarts', hook_paused: 'paused after failures',
          part_prompt: 'Prompt addition (file)', part_hook: 'Event reaction', ev_message: 'message', ev_llm: 'LLM request', ev_tool: 'tool', ev_tools: 'tool catalog',
          ev_guard: 'guard', ev_manager: 'manager', ev_error: 'error', trust_done: 'trust updated',
          rss: 'kuni memory', all: 'all', core_src: 'core', kuni_src: 'kuni', tools_count: 'tools' }
  };

  function h(doc, tag, attrs, children) {
    var el = doc.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'on') Object.keys(v).forEach(function (ev) { el.addEventListener(ev, v[ev]); });
      else if (k === 'style') Object.keys(v).forEach(function (s) { el.style[s] = v[s]; });
      else if (k === 'value') el.value = v;
      else if (k === 'disabled') el.disabled = !!v;
      else el.setAttribute(k, v);
    });
    (children || []).forEach(function (c) {
      if (c === null || c === undefined) return;
      el.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c);
    });
    return el;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmtTime(sec) {
    if (sec === null || sec === undefined) return '--:--:--';
    var d = new Date(sec * 1000);
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function boot(env) {
    var doc = env.document, L = env.Layout;
    /* Токен из адреса вида http://127.0.0.1:8767/#token=...: нужен киоску на экране ноутбука (без ввода с клавиатуры). Сохраняется и убирается из адреса. */
    var hashMatch = /[#&]token=([^&]+)/.exec((env.location && env.location.hash) || '');
    if (hashMatch) {
      try { env.storage.setItem('zc_token', decodeURIComponent(hashMatch[1])); } catch (e) { /* хранилище недоступно: токен спросят окном */ }
      if (env.history && env.history.replaceState) env.history.replaceState(null, '', env.location.pathname + (env.location.search || ''));
    }
    var board = doc.getElementById('board'), topbar = doc.getElementById('topbar'), overlay = doc.getElementById('overlay');
    var S = { fx: (function () { try { return env.storage.getItem('zc_fx') || ''; } catch (e) { return ''; } })(), rowH: ROW_H, token: env.storage.getItem('zc_token') || '', settings: { language: 'ru', theme: 'dark', log_lines: 200, gap: DEFAULT_GAP, view: 'panel', layout: {}, hidden: [] },
              defs: [], nodes: {}, layout: {}, modules: [], stacked: false, cellW: 50, logFilter: 'all', statusTimer: null,
              threads: [], dragId: null, shock: null, animating: false, lastDraw: 0, reduced: !!env.reducedMotion, staticDirty: true, staticDragId: null, dragPx: null, frameAvg: 0, frameAt: 0, frameGap: 0, level: 0, badSince: 0, goodSince: 0, goodNeeded: 3000, promotedAt: 0, warmUntil: 0, dpr: 1, cssW: 0, cssH: 0, hoverId: null, boardClass: '', boardH: 0,
              archDefs: [], arch: null, archById: {}, archNext: 0, bursts: [], activitySince: 0, activityNext: 0, hist: [], traffic: {}, trafficQ: {}, focusId: null, justDragged: false, logSearch: '' };
    var statusEl = null, chips = null;

    function t(key) { return (I18N[S.settings.language] || I18N.ru)[key] || key; }

    // ---------- сеть ----------
    function api(path, opts) {
      opts = opts || {};
      var init = { method: opts.method || 'GET', headers: { 'X-Token': S.token } };
      if (opts.body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
      return env.fetch(path, init).then(function (resp) {
        return resp.json().then(function (data) {
          if (resp.status === 401) { showLogin(); throw new Error('401'); }
          if (!resp.ok) throw new Error((data && data.error) || String(resp.status));
          return data;
        });
      });
    }
    function setStatus(msg, isErr) {
      if (!statusEl) return;
      statusEl.textContent = msg;
      statusEl.className = 'status' + (isErr ? ' err' : '');
      if (S.statusTimer && env.clearTimeout) env.clearTimeout(S.statusTimer);
      if (isErr && env.setTimeout) S.statusTimer = env.setTimeout(function () { statusEl.className = 'status'; }, 8000);
    }
    function saveSettings(patch) {
      return api('/api/settings', { method: 'POST', body: patch }).then(function (s) { S.settings = s; return s; })
        .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }

    // ---------- окна ----------
    function closeOverlay() { overlay.hidden = true; clear(overlay); }
    function openModal(title, content, buttons) {
      clear(overlay);
      overlay.hidden = false;
      overlay.appendChild(h(doc, 'div', { class: 'modal' }, [h(doc, 'h3', { text: title })].concat(content)
        .concat([h(doc, 'div', { class: 'buttons' }, buttons)])));
    }
    function showLogin() {
      var input = h(doc, 'input', { type: 'password', id: 'token-input', placeholder: t('token_hint') });
      function submit() {
        var v = (input.value || '').trim();
        if (!v) return;
        S.token = v;
        env.storage.setItem('zc_token', v);
        closeOverlay();
        start();
      }
      openModal(t('token_title'), [h(doc, 'div', { class: 'dim', text: t('token_hint') }), input],
                [h(doc, 'button', { class: 'btn', id: 'token-submit', text: t('enter'), on: { click: submit } })]);
    }
    function showSettings() {
      var lang = h(doc, 'select', { id: 's-lang' }, [h(doc, 'option', { value: 'ru', text: 'Русский' }), h(doc, 'option', { value: 'en', text: 'English' })]);
      var theme = h(doc, 'select', { id: 's-theme' }, [h(doc, 'option', { value: 'dark', text: t('dark') }), h(doc, 'option', { value: 'light', text: t('light') }),
        h(doc, 'option', { value: 'black', text: t('black') }), h(doc, 'option', { value: 'aurora', text: t('aurora') }), h(doc, 'option', { value: 'neon', text: t('neon') }),
        h(doc, 'option', { value: 'paper', text: t('paper') })]);
      var lines = h(doc, 'input', { type: 'number', id: 's-lines' });
      var gapIn = h(doc, 'input', { type: 'number', id: 's-gap' });
      var proBox = h(doc, 'input', { type: 'checkbox', id: 's-pro' });
      proBox.checked = !!S.settings.pro;
      lang.value = S.settings.language; theme.value = S.settings.theme; lines.value = S.settings.log_lines; gapIn.value = gapOf();
      openModal(t('settings'), [
        h(doc, 'label', {}, [t('language'), lang]), h(doc, 'label', {}, [t('theme'), theme]), h(doc, 'label', {}, [t('log_lines'), lines]), h(doc, 'label', {}, [t('gap'), gapIn]), labelled(t('pro_label'), proBox)
      ], [
        h(doc, 'button', { class: 'btn danger', text: t('change_token'), on: { click: function () { env.storage.setItem('zc_token', ''); S.token = ''; showLogin(); } } }),
        h(doc, 'button', { class: 'btn danger', id: 's-newtoken', text: t('new_token'), on: { click: rotateToken } }),
        h(doc, 'button', { class: 'btn', id: 's-update', text: t('update'), on: { click: function () { showUpdate(); } } }),
        h(doc, 'button', { class: 'btn', id: 's-selfmod', text: t('sm_open'), on: { click: function () { showSelfmod(); } } }),
        h(doc, 'button', { class: 'btn', id: 's-system', text: t('sys_open'), on: { click: function () { showSystem(); } } }),
        h(doc, 'button', { class: 'btn', id: 's-eco', text: t('eco_open'), on: { click: function () { showEco(); } } }),
        h(doc, 'button', { class: 'btn', id: 's-prompts', text: t('pr_open'), on: { click: function () { showPrompts(); } } }),
        h(doc, 'button', { class: 'btn', id: 's-backups', text: t('bk_open'), on: { click: function () { showBackups(); } } }),
        h(doc, 'button', { class: 'btn', id: 's-alerts', text: t('al_open'), on: { click: function () { showAlerts(); } } }),
        h(doc, 'button', { class: 'btn', id: 's-history', text: t('hs_open'), on: { click: function () { showHistory(); } } }),
        h(doc, 'button', { class: 'btn danger', id: 's-reset', text: t('reset_layout'), on: { click: function () {
          S.settings.layout = {}; closeOverlay(); saveSettings({ layout: {} }).then(function () { relayout(); }); } } }),
        h(doc, 'button', { class: 'btn', text: t('cancel'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn', id: 's-save', text: t('save'), on: { click: function () {
          var g = parseInt(gapIn.value, 10);
          saveSettings({ language: lang.value, theme: theme.value, log_lines: parseInt(lines.value, 10) || 200, gap: isNaN(g) ? DEFAULT_GAP : g, pro: !!proBox.checked }).then(function () {
            closeOverlay(); applyTheme(); buildTopbar(); rebuildAll(); refreshAll(); }); } } })   // обновление сразу, а не на следующем «тике»
      ]);
    }
    function showHidden() {
      var hidden = S.settings.hidden, rows = [];
      if (!hidden.length) rows.push(h(doc, 'div', { class: 'dim', text: t('nothing_hidden') }));
      hidden.forEach(function (id) {
        var def = S.defs.concat(S.archDefs).filter(function (d) { return d.id === id; })[0];
        rows.push(h(doc, 'div', { class: 'row' }, [h(doc, 'span', { class: 'grow', text: def ? title(def) : id }),
          h(doc, 'button', { class: 'btn', text: t('show'), on: { click: function () {
            S.settings.hidden = S.settings.hidden.filter(function (x) { return x !== id; });
            saveSettings({ hidden: S.settings.hidden }).then(function () { closeOverlay(); rebuildAll(); }); } } })]));
      });
      openModal(t('restore'), rows, [h(doc, 'button', { class: 'btn', text: t('close'), on: { click: closeOverlay } })]);
    }

    // ---------- детали: конструктор, заготовки, настройки, упаковка, загрузка, удаление ----------
    var MAX_UPLOAD = 8 * 1024 * 1024;
    var PROMPT_FILES = ['system.md', 'character_base.md', 'character_appearance.md', 'photo_to_text.md', 'sticker_to_text.md', 'anti_repeat.md', 'diary_save.md', 'sleep_consolidator.md', 'record_audio_speech.md', 'messages_epilogue.md'];
    var EVENT_KINDS = ['message', 'llm', 'tool', 'tools', 'guard', 'manager', 'error'];
    function labelled(label, input) { return h(doc, 'label', {}, [label, input]); }
    function options(list) { return list.map(function (o) { return h(doc, 'option', { value: o[0], text: o[1] }); }); }
    function afterPartsChange() {
      return syncModules().catch(function () {}).then(function () {
        return S.settings.view === 'arch' ? syncArchitecture().catch(function () {}) : null;
      }).then(function () { rebuildAll(); return refreshAll(); });
    }
    function showParts() {
      api('/api/templates').then(function (tpls) {
        var ru = S.settings.language !== 'en';
        var tpl = h(doc, 'select', { id: 'p-template' }, [h(doc, 'option', { value: '', text: t('tpl_pick') })].concat(tpls.map(function (x) {
          return h(doc, 'option', { value: x.id, text: ru ? x.title : x.title_en }); })));
        var hint = h(doc, 'div', { class: 'dim', id: 'p-hint', text: '' });
        var name = h(doc, 'input', { type: 'text', id: 'p-name', placeholder: 'moya_detal' });
        var kind = h(doc, 'select', { id: 'p-kind' }, options([['library', t('kind_library')], ['service', t('kind_service')], ['job', t('kind_job')]]));
        var widget = h(doc, 'select', { id: 'p-widget' }, options([['', t('none')], ['kv', 'kv'], ['table', 'table'], ['text', 'text'], ['counter', 'counter']]));
        var tool = h(doc, 'input', { type: 'text', id: 'p-tool', placeholder: t('part_tool_hint') });
        var prompt = h(doc, 'select', { id: 'p-prompt' }, options([['', t('none')]].concat(PROMPT_FILES.map(function (f) { return [f, f]; }))));
        var hook = h(doc, 'select', { id: 'p-hook' }, options([['', t('none')]].concat(EVENT_KINDS.map(function (k) { return [k, t('ev_' + k)]; }))));
        var provides = h(doc, 'input', { type: 'text', id: 'p-provides', placeholder: 'moya_detal.main' });
        var requires = h(doc, 'input', { type: 'text', id: 'p-requires', placeholder: 'telegram.bot' });
        var optional = h(doc, 'input', { type: 'text', id: 'p-optional', placeholder: 'world.state' });
        var desc = h(doc, 'input', { type: 'text', id: 'p-desc' });
        var enable = h(doc, 'input', { type: 'checkbox', id: 'p-enable' });
        enable.checked = true;
        var file = h(doc, 'input', { type: 'file', id: 'p-file', accept: '.zip' });
        var err = h(doc, 'div', { class: 'err', id: 'p-err', text: '' });
        tpl.addEventListener('change', function () {   // заготовка заполняет форму: дальше её можно поправить
          var x = tpls.filter(function (q) { return q.id === tpl.value; })[0];
          hint.textContent = x ? (ru ? x.desc : x.desc_en) : '';
          if (x) { kind.value = x.kind; widget.value = x.widget || ''; tool.value = x.tool || ''; prompt.value = x.prompt_target || ''; hook.value = x.hook_on || ''; }
        });
        file.addEventListener('change', function () { uploadZip(file.files && file.files[0]); });
        function create() {
          var n = (name.value || '').trim();
          if (!n) { err.textContent = t('name_required'); return; }
          err.textContent = '';
          api('/api/parts/new', { method: 'POST', body: { name: n, kind: kind.value, widget: widget.value, tool: (tool.value || '').trim(), provides: (provides.value || '').trim(),
            requires: (requires.value || '').trim(), optional: (optional.value || '').trim(), description: (desc.value || '').trim(), prompt_target: prompt.value || '', hook_on: hook.value || '', enable: !!enable.checked, install: true } })
            .then(function (r) {
              closeOverlay();
              return afterPartsChange().then(function () {
                setStatus('OK: ' + t('part_created') + ' ' + r.name + (r.enable_error ? ' (' + t('part_not_enabled') + ': ' + r.enable_error + ')' : ''), !!r.enable_error);
              });
            }).catch(function (e) { err.textContent = t('error') + ': ' + e.message; });
        }
        openModal(t('parts_title'), [labelled(t('template'), tpl), hint, labelled(t('part_name'), name), labelled(t('part_kind'), kind), labelled(t('part_widget'), widget),
          labelled(t('part_tool'), tool), labelled(t('part_prompt'), prompt), labelled(t('part_hook'), hook), labelled(t('part_provides'), provides), labelled(t('part_requires'), requires), labelled(t('part_optional'), optional),
          labelled(t('part_desc'), desc), labelled(t('part_enable'), enable), h(doc, 'div', { class: 'dim section', text: t('upload_zip') }), file, err], [
          h(doc, 'button', { class: 'btn', id: 'p-close', text: t('close'), on: { click: closeOverlay } }),
          h(doc, 'button', { class: 'btn', id: 'p-create', text: t('part_create'), on: { click: create } })]);
      }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function uploadZip(file) {
      if (!file) return;
      if (file.size > MAX_UPLOAD) { setStatus(t('error') + ': ' + t('too_big'), true); return; }
      setStatus(t('uploading') + '…', false);
      file.arrayBuffer().then(function (buf) {
        return env.fetch('/api/modules/upload', { method: 'POST', headers: { 'X-Token': S.token, 'Content-Type': 'application/zip' }, body: buf });
      }).then(function (resp) {
        return resp.json().then(function (d) {
          if (resp.status === 401) { showLogin(); throw new Error('401'); }
          if (!resp.ok) throw new Error((d && d.error) || String(resp.status));
          return d;
        });
      }).then(function (d) {
        closeOverlay();
        return afterPartsChange().then(function () { setStatus('OK: ' + d.name + ' ' + d.version + ' — ' + t('uploaded'), false); });
      }).catch(function (e) { if (e.message !== '401') setStatus(t('error') + ': ' + e.message, true); });
    }
    function defaultDownload(blob, filename) {
      var url = env.window.URL.createObjectURL(blob), a = doc.createElement('a');
      a.href = url; a.download = filename; doc.body.appendChild(a); a.click(); doc.body.removeChild(a);
      env.setTimeout(function () { env.window.URL.revokeObjectURL(url); }, 4000);
    }
    function downloadZip(name) {
      env.fetch('/api/modules/' + name + '/pack', { method: 'GET', headers: { 'X-Token': S.token } }).then(function (resp) {
        if (!resp.ok) return resp.json().then(function (d) { throw new Error((d && d.error) || String(resp.status)); });
        var cd = (resp.headers && resp.headers.get && resp.headers.get('Content-Disposition')) || '', m = /filename="([^"]+)"/.exec(cd), fname = m ? m[1] : name + '.zip';
        return resp.blob().then(function (b) { (env.download || defaultDownload)(b, fname); setStatus('OK: ' + fname, false); });
      }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function removeModule(name) {
      var data = h(doc, 'input', { type: 'checkbox', id: 'rm-data' });
      openModal(t('remove_q') + ' ' + name + '?', [h(doc, 'div', { class: 'dim', text: t('remove_note') }), labelled(t('remove_data'), data)], [
        h(doc, 'button', { class: 'btn', id: 'rm-no', text: t('cancel'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn danger', id: 'rm-yes', text: t('remove'), on: { click: function () {
          api('/api/modules/' + name + '/uninstall', { method: 'POST', body: { confirm: name, purge_data: !!data.checked } }).then(function (r) {
            closeOverlay();
            return afterPartsChange().then(function () { setStatus('OK: ' + name + ' ' + t('removed') + (r.backup ? ' (' + r.backup + ')' : ''), false); });
          }).catch(function (e) { closeOverlay(); setStatus(t('error') + ': ' + e.message, true); });
        } } })]);
    }
    function showModule(name) {
      api('/api/modules/' + name + '/config').then(function (d) {
        var inputs = {}, rows = [];
        if (d.description) rows.push(h(doc, 'div', { class: 'dim', text: d.description }));
        rows.push(h(doc, 'div', { class: 'dim', text: d.version + ' · ' + d.kind }));
        [['provides_l', d.provides], ['requires_l', d.requires], ['optional_l', d.optional_requires]].forEach(function (c) {
          if (c[1] && c[1].length) rows.push(h(doc, 'div', { class: 'dim', text: t(c[0]) + ': ' + c[1].join(', ') }));
        });
        var keys = Object.keys(d.defaults || {});
        if (!keys.length) rows.push(h(doc, 'div', { class: 'dim', text: t('no_settings') }));
        keys.forEach(function (k) {
          var def = d.defaults[k], isBool = typeof def === 'boolean';
          var inp = h(doc, 'input', { type: isBool ? 'checkbox' : (typeof def === 'number' ? 'number' : 'text'), id: 'c-' + k });
          if (isBool) inp.checked = !!d.config[k]; else inp.value = d.config[k] === undefined || d.config[k] === null ? '' : String(d.config[k]);
          inputs[k] = { el: inp, bool: isBool, orig: isBool ? !!d.config[k] : String(inp.value) };
          rows.push(labelled(k, inp));
        });
        if (d.protected) rows.push(h(doc, 'div', { class: 'dim', text: t('protected_note') }));
        if (!d.protected) {   // секреты детали: имена видны, значения никогда
          rows.push(h(doc, 'div', { class: 'section', text: t('sec_title') }));
          rows.push(h(doc, 'div', { class: 'dim', text: t('sec_note') }));
          (d.secrets || []).forEach(function (sn) {
            rows.push(h(doc, 'div', { class: 'row bt', id: 'm-secret-' + sn }, [h(doc, 'span', { class: 'grow', text: sn + ' · ' + t('sec_set') }),
              h(doc, 'button', { class: 'btn danger', id: 'm-secret-del-' + sn, text: t('sec_delete'), on: { click: function () {
                api('/api/secrets/' + name, { method: 'POST', body: { name: sn, value: '' } }).then(function () { showModule(name); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); }); } } })]));
          });
          var sName = h(doc, 'input', { type: 'text', id: 'm-secret-name', placeholder: t('sec_name') }), sVal = h(doc, 'input', { type: 'password', id: 'm-secret-value', placeholder: t('sec_value'), autocomplete: 'off' });
          rows.push(h(doc, 'div', { class: 'row' }, [sName, sVal, h(doc, 'button', { class: 'btn', id: 'm-secret-save', text: t('sec_save'), on: { click: function () {
            var n = (sName.value || '').trim(), v = sVal.value || '';
            if (!n || !v) { setStatus(t('sec_need'), true); return; }
            api('/api/secrets/' + name, { method: 'POST', body: { name: n, value: v } }).then(function () { setStatus('OK: ' + t('sec_saved'), false); showModule(name); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
          } } })]));
        }
        var tr = d.trust || {}, trustButtons = [];
        if (d.patches && d.patches.length) {   // раздел «Ключи и патчи»: что деталь приносит с собой и доверяет ли ей ядро
          rows.push(h(doc, 'div', { class: 'section', text: t('keys_title') }));
          rows.push(h(doc, 'div', { class: tr.allowed ? '' : 'err', id: 'm-trust', text: t('trust_label') + ': ' + t('trust_' + tr.state) + (tr.approved && tr.state !== 'trusted' ? ' · ' + t('trust_approved') : '') }));
          rows.push(h(doc, 'div', { class: 'dim', id: 'm-trust-note', text: tr.allowed ? t('trust_allowed') : t('trust_not_allowed') }));
          d.patches.forEach(function (p) {
            var what = t('patch_' + String(p.key).replace('.', '_')) + (p.target ? ' → ' + p.target : (p.on ? ' ← ' + t('ev_' + p.on) : ''));
            var note = p.status === 'active' && p.key === 'prompt.append' ? ' (' + t('prompt_note') + ')' : (p.status === 'error' || p.status === 'no_bot_dir' ? ' (' + (p.detail || '') + ')' : '');
            rows.push(h(doc, 'div', { class: p.status === 'error' ? 'err' : 'dim', id: 'm-patch-' + p.id, text: '• ' + what + ': ' + t('pst_' + p.status) + note }));
          });
          (d.hooks || []).forEach(function (hk) {
            if (hk.paused) {
              rows.push(h(doc, 'div', { class: 'err', text: '• ' + hk.id + ': ' + t('hook_paused') }));
              trustButtons.push(h(doc, 'button', { class: 'btn', id: 'm-resume-' + hk.id, text: t('btn_resume') + ' ' + hk.id, on: { click: function () {
                api('/api/hooks/' + name + '/' + hk.id + '/resume', { method: 'POST', body: {} }).then(function () { showModule(name); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); }); } } }));
            }
          });
          var act = function (action) {
            return function () { api('/api/modules/' + name + '/trust', { method: 'POST', body: { action: action } }).then(function () { setStatus('OK: ' + t('trust_done'), false); showModule(name); })
              .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); }); };
          };
          if (tr.state !== 'trusted') trustButtons.push(h(doc, 'button', { class: 'btn', id: 'm-sign', text: t('btn_sign'), on: { click: act('sign') } }));
          if (tr.state !== 'trusted' && !tr.approved) trustButtons.push(h(doc, 'button', { class: 'btn', id: 'm-approve', text: t('btn_approve'), on: { click: act('approve') } }));
          if (tr.state !== 'trusted' && tr.approved) trustButtons.push(h(doc, 'button', { class: 'btn', id: 'm-revoke', text: t('btn_revoke'), on: { click: act('revoke') } }));
        }
        function save() {
          var changed = keys.filter(function (k) { var i = inputs[k]; return i.bool ? !!i.el.checked !== i.orig : String(i.el.value) !== i.orig; });
          var chain = Promise.resolve();
          changed.forEach(function (k) {
            var i = inputs[k];
            chain = chain.then(function () { return api('/api/modules/' + name + '/config', { method: 'POST', body: { key: k, value: i.bool ? !!i.el.checked : i.el.value } }); });
          });
          chain.then(function () { closeOverlay(); setStatus(changed.length ? 'OK: ' + t('saved_restart') : 'OK', false); })
            .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
        }
        var buttons = [h(doc, 'button', { class: 'btn', id: 'm-close', text: t('close'), on: { click: closeOverlay } }),
          h(doc, 'button', { class: 'btn', id: 'm-download', text: t('download_zip'), on: { click: function () { downloadZip(name); } } })];
        if (!d.protected) buttons.push(h(doc, 'button', { class: 'btn danger', id: 'm-remove', text: t('remove'), on: { click: function () { removeModule(name); } } }));
        if (!d.protected && d.versions && d.versions.length > 1) {   // деталь стояла в нескольких версиях: можно откатиться (и вернуться обратно)
          rows.push(h(doc, 'div', { class: 'dim', id: 'm-versions', text: t('versions_label') + ': ' + d.versions.join(', ') + ' (' + d.version + ')' }));
          trustButtons.push(h(doc, 'button', { class: 'btn', id: 'm-rollback', text: t('btn_rollback'), on: { click: function () {
            confirmAction(t('rollback_q'), function () {
              api('/api/modules/' + name + '/rollback', { method: 'POST', body: {} }).then(function (r) { showModule(name); return refreshAll().then(function () { setStatus('OK: ' + name + ' ' + r.from + ' → ' + r.to, false); }); })   // сообщение после обновления, иначе его затирает «обновлено»
                .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
            });
          } } }));
        }
        trustButtons.forEach(function (b) { buttons.push(b); });
        if (keys.length) buttons.push(h(doc, 'button', { class: 'btn', id: 'm-save', text: t('save'), on: { click: save } }));
        openModal(name, rows, buttons);
      }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function rotateToken() {
      confirmAction(t('new_token_q'), function () {
        api('/api/token/rotate', { method: 'POST', body: {} }).then(function (d) {
          S.token = d.token;
          env.storage.setItem('zc_token', d.token);
          var box = h(doc, 'input', { type: 'text', id: 'new-token', readonly: 'readonly' });
          box.value = d.token;
          openModal(t('new_token_title'), [h(doc, 'div', { class: 'dim', text: t('new_token_note') }), box],
            [h(doc, 'button', { class: 'btn', id: 'new-token-ok', text: t('close'), on: { click: closeOverlay } })]);
        }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
      });
    }

    // ---------- обновление ядра и бота из панели ----------
    var UPDATE_LIMIT = { core: 30 * 1024 * 1024, bot: 450 * 1024 * 1024 };
    function fmtDate(sec) { var d = new Date(sec * 1000); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
    function showUpdate(msg, isErr) {
      api('/api/update/status').then(function (st) { renderUpdate(st, msg, isErr); })
        .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function uploadUpdate(kind, file) {
      if (!file) return;
      if (file.size > UPDATE_LIMIT[kind]) { showUpdate(t('upd_too_big') + ' (' + Math.round(UPDATE_LIMIT[kind] / 1048576) + ' ' + t('upd_mb') + ')', true); return; }
      var note = doc.getElementById('u-msg');
      if (note) note.textContent = t('upd_uploading') + ' · ' + Math.round(file.size / 1048576 * 10) / 10 + ' ' + t('upd_mb') + '…';
      env.fetch('/api/update/' + kind + '/upload', { method: 'POST', headers: { 'X-Token': S.token, 'Content-Type': 'application/octet-stream' }, body: file }).then(function (resp) {
        return resp.json().then(function (d) {
          if (resp.status === 401) { showLogin(); throw new Error('401'); }
          if (!resp.ok) throw new Error((d && d.error) || String(resp.status));
          return d;
        });
      }).then(function (info) {
        showUpdate(t('upd_checked') + (kind === 'core' ? ': ' + t('upd_selftest_ok') : ': ' + info.mb + ' ' + t('upd_mb') + ', ' + t('upd_ldd_ok')), false);
      }).catch(function (e) { if (e.message !== '401') showUpdate(t('error') + ': ' + e.message, true); });
    }
    function waitForRestart(tries) {   // панель перезапускается на месте: ждём, пока она снова ответит с новым временем работы, и перезагружаем страницу
      tries = tries === undefined ? 40 : tries;
      env.setTimeout(function () {
        env.fetch('/api/system', { method: 'GET', headers: { 'X-Token': S.token } }).then(function (resp) { return resp.ok ? resp.json() : null; }).then(function (d) {
          if (d && d.uptime < 20) { if (env.location && env.location.reload) env.location.reload(); else { closeOverlay(); start(); } return; }
          if (tries > 0) waitForRestart(tries - 1); else { closeOverlay(); setStatus(t('error') + ': ' + t('upd_restarting'), true); }
        }).catch(function () { if (tries > 0) waitForRestart(tries - 1); });
      }, 2000);
    }
    function restartingDialog() {
      openModal(t('upd_restarting'), [h(doc, 'div', { class: 'dim', id: 'u-wait', text: t('upd_wait') })], []);
      waitForRestart();
    }
    function botRestartIfAsked(box) {
      if (!box || !box.checked) return Promise.resolve(null);
      return api('/api/modules/kuni/restart', { method: 'POST', body: {} }).then(function () { return t('upd_bot_restarted'); });
    }
    function renderUpdate(st, msg, isErr) {
      var core = st.core, bot = st.bot, sc = st.staged && st.staged.core, sb = st.staged && st.staged.bot, rows = [];
      rows.push(h(doc, 'div', { class: (isErr ? 'err' : 'dim') + ' section', id: 'u-msg', text: msg || '' }));
      // ----- ядро -----
      rows.push(h(doc, 'div', { class: 'section', text: t('upd_core') }));
      rows.push(h(doc, 'div', { class: 'dim', id: 'u-core-info', text: t('upd_version') + ' ' + core.version + ' · ' + t('upd_build') + ' ' + core.build + ' · ' + t('upd_backups') + ': ' + core.backups.length }));
      var coreFile = h(doc, 'input', { type: 'file', id: 'u-core-file', accept: '.zip' });
      coreFile.addEventListener('change', function () { uploadUpdate('core', coreFile.files && coreFile.files[0]); });
      rows.push(h(doc, 'div', { class: 'dim', text: t('upd_pick_core') }), coreFile);
      var buttons = [h(doc, 'button', { class: 'btn', id: 'u-close', text: t('close'), on: { click: closeOverlay } })];
      if (sc) {
        rows.push(h(doc, 'div', { id: 'u-core-staged', text: t('upd_new_version') + ' ' + sc.version + ' · ' + t('upd_build') + ' ' + sc.build + ' (' + t('upd_now') + ' ' + core.build + ')' }));
        buttons.push(h(doc, 'button', { class: 'btn danger', id: 'u-core-apply', text: t('upd_apply_core'), on: { click: function () {
          confirmAction(t('upd_core_q'), function () {
            api('/api/update/core/apply', { method: 'POST', body: { confirm: 'core', id: sc.id } }).then(function (r) { if (r.restarting) restartingDialog(); else showUpdate(t('upd_done_core') + ' ' + r.version, false); })
              .catch(function (e) { showUpdate(t('error') + ': ' + e.message, true); });
          });
        } } }));
      }
      if (core.backups.length) {
        buttons.push(h(doc, 'button', { class: 'btn', id: 'u-core-rollback', text: t('upd_rollback_core'), on: { click: function () {
          confirmAction(t('upd_rollback_q'), function () {
            api('/api/update/core/rollback', { method: 'POST', body: { confirm: 'core' } }).then(function (r) { if (r.restarting) restartingDialog(); else showUpdate(t('upd_done_core') + ' ' + r.version, false); })
              .catch(function (e) { showUpdate(t('error') + ': ' + e.message, true); });
          });
        } } }));
      }
      // ----- бот -----
      rows.push(h(doc, 'div', { class: 'section', text: t('upd_bot') }));
      if (!bot.path) {
        rows.push(h(doc, 'div', { class: 'dim', id: 'u-bot-info', text: t('upd_no_bot_dir') }));
      } else {
        rows.push(h(doc, 'div', { class: 'dim', id: 'u-bot-info', text: t('upd_program') + ': ' + (bot.exists ? bot.size_mb + ' ' + t('upd_mb') + ', ' + t('upd_changed') + ' ' + fmtDate(bot.mtime) : '—') +
          ' · ' + t('upd_backups') + ': ' + bot.backups.length + ' · ' + (bot.running ? t('upd_running') : t('upd_stopped')) }));
        var botFile = h(doc, 'input', { type: 'file', id: 'u-bot-file', accept: '.zip,.gz,.tgz' });
        botFile.addEventListener('change', function () { uploadUpdate('bot', botFile.files && botFile.files[0]); });
        var restartBox = h(doc, 'input', { type: 'checkbox', id: 'u-bot-restart' });
        rows.push(h(doc, 'div', { class: 'dim', text: t('upd_pick_bot') }), botFile, labelled(t('upd_restart_bot'), restartBox));
        function botDone(text) {
          return botRestartIfAsked(restartBox).then(function (restarted) {
            showUpdate(text + (restarted ? '; ' + restarted : '. ' + t('upd_bot_still_old')), false);
          });
        }
        if (sb) {
          rows.push(h(doc, 'div', { id: 'u-bot-staged', text: t('upd_checked') + ': ' + sb.mb + ' ' + t('upd_mb') + ', ' + t('upd_ldd_ok') }));
          buttons.push(h(doc, 'button', { class: 'btn danger', id: 'u-bot-apply', text: t('upd_apply_bot'), on: { click: function () {
            confirmAction(t('upd_bot_q'), function () {
              api('/api/update/bot/apply', { method: 'POST', body: { confirm: 'bot', id: sb.id } }).then(function (r) { return botDone(t('upd_bot_replaced') + (r.backup ? ' (' + r.backup + ')' : '')); })
                .catch(function (e) { showUpdate(t('error') + ': ' + e.message, true); });
            });
          } } }));
        }
        if (bot.backups.length) {
          buttons.push(h(doc, 'button', { class: 'btn', id: 'u-bot-rollback', text: t('upd_rollback_bot'), on: { click: function () {
            confirmAction(t('upd_rollback_q'), function () {
              api('/api/update/bot/rollback', { method: 'POST', body: { confirm: 'bot' } }).then(function () { return botDone(t('upd_rollback_bot')); })
                .catch(function (e) { showUpdate(t('error') + ': ' + e.message, true); });
            });
          } } }));
        }
      }
      openModal(t('upd_title'), rows, buttons);
    }

    // ---------- Марин в панели: чат ----------
    var chat = { el: null, state: null, busy: false, error: '', parts: null };
    function chatPost(path, body) { return api('/api/assistant' + path, { method: 'POST', body: body || {} }); }
    function closeChat() { if (chat.el && chat.el.parentNode) chat.el.parentNode.removeChild(chat.el); chat.el = null; chat.parts = null; }
    function toggleChat() { if (chat.el) closeChat(); else openChat(); }
    function shortArgs(name, args) {
      if (name === 'shell') return String(args.command || '');
      var j = JSON.stringify(args || {});
      return j.length > 90 ? j.slice(0, 90) + '…' : j;
    }
    function openChat() {
      var list = h(doc, 'div', { id: 'chat-list' }), pend = h(doc, 'div', { id: 'chat-pending' }), note = h(doc, 'div', { id: 'chat-note', class: 'dim' }), info = h(doc, 'span', { id: 'chat-info', class: 'dim grow nl' });
      var ta = h(doc, 'textarea', { id: 'chat-input', rows: 2, placeholder: t('chat_ph') });
      var send = h(doc, 'button', { class: 'btn', id: 'chat-send', text: t('chat_send'), on: { click: function () { chatSend(); } } });
      var stop = h(doc, 'button', { class: 'btn danger', id: 'chat-stop', text: t('chat_stop'), on: { click: function () { chatPost('/stop').catch(function () {}); } } });
      var gear = h(doc, 'button', { class: 'btn', id: 'chat-gear', text: '⚙', title: t('chat_mode'), on: { click: chatSettings } });
      var close = h(doc, 'button', { class: 'wx', id: 'chat-close', text: '✕', title: t('close'), on: { click: closeChat } });
      ta.addEventListener('keydown', function (ev) { if (ev.key === 'Enter' && !ev.shiftKey) { if (ev.preventDefault) ev.preventDefault(); chatSend(); } });
      chat.el = h(doc, 'aside', { id: 'chat' }, [h(doc, 'div', { class: 'ch' }, [h(doc, 'span', { class: 'ct', text: t('chat_title') }), info, gear, close]), list, pend, note, h(doc, 'div', { class: 'cf' }, [ta, h(doc, 'div', { class: 'cb' }, [send, stop])])]);
      chat.parts = { list: list, pend: pend, note: note, info: info, ta: ta, send: send, stop: stop };
      doc.body.appendChild(chat.el);
      updateChat();
      api('/api/assistant').then(function (st) { chat.state = st; updateChat(); }).catch(function (e) { chat.error = e.message; updateChat(); });
      if (ta.focus) ta.focus();
    }
    function updateChat() {
      var P = chat.parts;
      if (!P) return;
      var st = chat.state, llmOk = st && st.llm && st.llm.available, on = !st || st.settings.enabled;
      clear(P.list); clear(P.pend);
      if (st) {
        var msgs = st.messages, results = {};
        msgs.forEach(function (m) { if (m.role === 'tool') results[m.id] = m.text; });
        if (!msgs.length && !chat.busy) P.list.appendChild(h(doc, 'div', { class: 'dim cmsg', id: 'chat-empty', text: t('chat_empty') }));
        msgs.forEach(function (m) {
          if (m.role === 'user') P.list.appendChild(h(doc, 'div', { class: 'cmsg me', text: m.text }));
          else if (m.role === 'assistant') {
            (m.calls || []).forEach(function (c) {
              P.list.appendChild(h(doc, 'details', { class: 'cstep', id: 'chat-step-' + c.id }, [h(doc, 'summary', { text: '🔧 ' + c.name + ' · ' + shortArgs(c.name, c.args) }), h(doc, 'pre', { text: results[c.id] === undefined ? '…' : results[c.id] })]));
            });
            if (m.text) P.list.appendChild(h(doc, 'div', { class: 'cmsg bot', text: m.text }));
          }
        });
        if (st.pending) {
          var pd = st.pending;
          P.pend.appendChild(h(doc, 'div', { class: 'cconfirm', id: 'chat-confirm' }, [h(doc, 'div', { class: 'ctitle', text: '⚠ ' + t('chat_confirm_title') }), h(doc, 'pre', { text: pd.tool + ' · ' + shortArgs(pd.tool, pd.args) }),
            h(doc, 'div', { class: 'dim', text: t('chat_why') + ': ' + pd.why }), h(doc, 'div', { class: 'row' }, [
              h(doc, 'button', { class: 'btn', id: 'chat-allow', text: t('chat_allow'), on: { click: function () { chatConfirm(pd.id, true); } } }),
              h(doc, 'button', { class: 'btn danger', id: 'chat-deny', text: t('chat_deny'), on: { click: function () { chatConfirm(pd.id, false); } } })])]));
        }
      }
      if (chat.busy) P.list.appendChild(h(doc, 'div', { class: 'dim cmsg', id: 'chat-thinking', text: t('chat_think') }));
      P.list.scrollTop = P.list.scrollHeight;
      P.note.textContent = chat.error || (!on ? t('chat_off') : st && !llmOk ? t('chat_no_llm') : st && st.settings.confirm === 'never' ? t('chat_mode_warn') : '');
      P.note.className = chat.error || (st && !llmOk) ? 'err' : 'dim';
      P.info.textContent = st && llmOk ? st.llm.model + (st.usage ? ' · ' + t('chat_usage') + ': ' + st.usage.requests + ' · $' + (st.usage.cost || 0).toFixed(4) : '') : '';
      var blocked = chat.busy || !on || (st && !llmOk) || !!(st && st.pending);
      P.ta.disabled = blocked && !chat.busy ? true : false;
      P.send.style.display = chat.busy ? 'none' : ''; P.stop.style.display = chat.busy ? '' : 'none';
      P.send.disabled = blocked;
    }
    function chatDone(r) { chat.busy = false; chat.error = r.error || ''; chat.state = r.state; updateChat(); }
    function chatFail(e) { chat.busy = false; chat.error = e.message; updateChat(); }
    function chatSend() {
      var P = chat.parts, text = (P.ta.value || '').trim();
      if (!text || chat.busy || !chat.state) return;
      P.ta.value = ''; chat.error = ''; chat.busy = true;
      chat.state.pending = null; chat.state.messages.push({ role: 'user', text: text }); updateChat();
      chatPost('/message', { text: text }).then(chatDone).catch(chatFail);
    }
    function chatConfirm(id, approve) { chat.busy = true; chat.error = ''; chat.state.pending = null; updateChat(); chatPost('/confirm', { id: id, approve: approve }).then(chatDone).catch(chatFail); }
    function chatSettings() {
      var st = chat.state || { settings: { confirm: 'dangerous', enabled: true } };
      var mode = h(doc, 'select', { id: 'chat-mode' }, ['dangerous', 'always', 'never'].map(function (v) { return h(doc, 'option', { value: v, text: t('chat_mode_' + v) }); }));
      mode.value = st.settings.confirm;
      var box = h(doc, 'input', { type: 'checkbox', id: 'chat-enabled' }); box.checked = !!st.settings.enabled;
      var rows = [h(doc, 'label', {}, [t('chat_mode'), mode]), labelled(t('chat_enabled'), box), h(doc, 'div', { class: 'dim', text: t('chat_mode_warn') }), h(doc, 'div', { class: 'section', text: t('chat_audit') })];
      (st.audit || []).slice(0, 12).forEach(function (r) {
        var d = new Date(r.t * 1000);
        rows.push(h(doc, 'div', { class: 'jrow' + (r.ok ? '' : ' err'), title: r.args }, [h(doc, 'span', { class: 'dim', text: pad(d.getHours()) + ':' + pad(d.getMinutes()) }), h(doc, 'span', { class: 'jn', text: r.tool + (r.confirmed === true ? ' ✓' : r.confirmed === false ? ' ✗' : '') }), h(doc, 'span', { class: 'nl', text: r.result })]));
      });
      openModal(t('chat_title'), rows, [
        h(doc, 'button', { class: 'btn danger', id: 'chat-reset', text: t('chat_reset'), on: { click: function () { confirmAction(t('chat_reset_q'), function () { chatPost('/reset').then(function (s) { chat.state = Object.assign({}, chat.state, s); closeOverlay(); updateChat(); }); }); } } }),
        h(doc, 'button', { class: 'btn', text: t('cancel'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn', id: 'chat-settings-save', text: t('save'), on: { click: function () {
          chatPost('/settings', { confirm: mode.value, enabled: !!box.checked }).then(function (s) { chat.state = Object.assign({}, chat.state, s); closeOverlay(); updateChat(); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); }); } } })]);
    }

    // ---------- редактор промптов ----------
    function showPrompts(name, msg, isErr, diffText) {
      api('/api/prompts').then(function (lst) {
        var cur = name || (lst.files[0] && lst.files[0].name);
        if (!cur) { setStatus(t('error') + ': ' + t('pr_none'), true); return; }
        return api('/api/prompts/' + encodeURIComponent(cur)).then(function (f) { renderPrompts(lst.files, f, msg, isErr, diffText); });
      }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function renderPrompts(files, f, msg, isErr, diffText) {
      var sel = h(doc, 'select', { id: 'pr-file' }, files.map(function (x) { return h(doc, 'option', { value: x.name, text: x.name + ' · ' + x.size + ' Б' }); }));
      sel.value = f.name;
      sel.addEventListener('change', function () { showPrompts(sel.value); });
      var ta = h(doc, 'textarea', { id: 'pr-text', rows: 14 }); ta.value = f.text;
      var note = h(doc, 'input', { type: 'text', id: 'pr-note', placeholder: t('pr_note') });
      var rows = [h(doc, 'div', { class: isErr ? 'err' : 'dim', id: 'pr-msg', text: msg || '' }), h(doc, 'label', {}, [t('pr_file'), sel])];
      if (f.blocks.length) rows.push(h(doc, 'div', { class: 'dim', id: 'pr-blocks', text: t('pr_blocks') + ': ' + f.blocks.map(function (b) { return b.module + '/' + b.patch; }).join(', ') }));
      rows.push(ta, note, h(doc, 'div', { class: 'section', text: t('pr_history') }));
      if (!f.history.length) rows.push(h(doc, 'div', { class: 'dim', id: 'pr-none', text: t('pr_none') }));
      f.history.slice(0, 12).forEach(function (v) {
        var d = new Date(v.at * 1000);
        rows.push(h(doc, 'div', { class: 'row bt', id: 'pr-ver-' + v.id }, [h(doc, 'span', { class: 'grow nl', text: d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ' · ' + (v.note || '') + ' · ' + v.size + ' Б' }),
          h(doc, 'button', { class: 'btn', id: 'pr-diff-' + v.id, text: t('pr_diff'), on: { click: function () {
            api('/api/prompts/' + encodeURIComponent(f.name) + '/diff?a=' + v.id + '&b=current').then(function (d2) { showPrompts(f.name, msg, isErr, d2.diff || t('pr_nodiff')); }); } } }),
          h(doc, 'button', { class: 'btn', id: 'pr-restore-' + v.id, text: t('pr_restore'), on: { click: function () {
            confirmAction(t('pr_restore_q'), function () { api('/api/prompts/' + encodeURIComponent(f.name) + '/restore', { method: 'POST', body: { id: v.id } }).then(function () { showPrompts(f.name, t('pr_saved')); }).catch(function (e) { showPrompts(f.name, t('error') + ': ' + e.message, true); }); }); } } })]));
      });
      if (diffText !== undefined) rows.push(h(doc, 'pre', { class: 'srcview', id: 'pr-diff', text: diffText }));
      openModal(t('pr_title'), rows, [
        h(doc, 'button', { class: 'btn', id: 'pr-restart', text: t('pr_restart'), on: { click: function () { closeOverlay(); moduleAction('kuni', 'restart'); } } }),
        h(doc, 'button', { class: 'btn', text: t('close'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn', id: 'pr-save', text: t('pr_save'), on: { click: function () {
          api('/api/prompts/' + encodeURIComponent(f.name), { method: 'POST', body: { text: ta.value, note: note.value } }).then(function () { showPrompts(f.name, t('pr_saved')); }).catch(function (e) { showPrompts(f.name, t('error') + ': ' + e.message, true); }); } } })]);
    }

    // ---------- резервные копии ----------
    function showBackups(msg, isErr) {
      api('/api/backups').then(function (d) { renderBackups(d, msg, isErr); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function bkPost(path, body, okMsg) {
      return api(path, { method: 'POST', body: body || {} }).then(function (d) { renderBackups(d, okMsg(d), false); }).catch(function (e) { showBackups(t('error') + ': ' + e.message, true); });
    }
    function renderBackups(d, msg, isErr) {
      var note = h(doc, 'input', { type: 'text', id: 'bk-note', placeholder: t('bk_note') });
      var rows = [h(doc, 'div', { class: isErr ? 'err' : 'dim', id: 'bk-msg', text: msg || '' }), h(doc, 'div', { class: 'dim', text: t('bk_warn') }),
        h(doc, 'div', { class: 'row' }, [note, h(doc, 'button', { class: 'btn', id: 'bk-create', text: t('bk_create'), on: { click: function () { bkPost('/api/backups', { note: note.value }, function () { return t('bk_done'); }); } } })])];
      var en = h(doc, 'input', { type: 'checkbox', id: 'bk-auto' }); en.checked = !!d.auto.enabled;
      var hours = h(doc, 'input', { type: 'number', id: 'bk-hours' }); hours.value = d.auto.hours;
      var keep = h(doc, 'input', { type: 'number', id: 'bk-keep' }); keep.value = d.auto.keep;
      rows.push(h(doc, 'div', { class: 'section', text: t('bk_auto') }), labelled(t('bk_auto'), en), h(doc, 'label', {}, [t('bk_every'), hours]), h(doc, 'label', {}, [t('bk_keep'), keep]),
        h(doc, 'button', { class: 'btn', id: 'bk-auto-save', text: t('bk_save'), on: { click: function () { bkPost('/api/backups/auto', { enabled: !!en.checked, hours: parseInt(hours.value, 10), keep: parseInt(keep.value, 10) }, function () { return t('bk_save'); }); } } }));
      if (!d.backups.length) rows.push(h(doc, 'div', { class: 'dim', id: 'bk-none', text: t('bk_none') }));
      d.backups.forEach(function (b) {
        var dt = new Date((b.created || b.mtime) * 1000);
        rows.push(h(doc, 'div', { class: 'row bt', id: 'bk-row-' + b.name }, [h(doc, 'span', { class: 'grow nl', title: b.name, text: dt.getFullYear() + '-' + pad(dt.getMonth() + 1) + '-' + pad(dt.getDate()) + ' ' + pad(dt.getHours()) + ':' + pad(dt.getMinutes()) + ' · ' + (b.note || '—') + ' · ' + Math.round(b.size / 1024) + ' КБ · ' + (b.files || '?') + ' ' + t('bk_files') }),
          h(doc, 'button', { class: 'btn', id: 'bk-restore-' + b.name, text: t('bk_restore'), on: { click: function () { confirmAction(t('bk_restore_q').replace('{n}', b.name), function () {
            bkPost('/api/backups/' + b.name + '/restore', { confirm: true }, function (r) { return t('bk_restored') + ': ' + r.restored + '; ' + t('bk_safety') + ': ' + r.safety; }); refreshAll(); }); } } }),
          h(doc, 'button', { class: 'btn danger', id: 'bk-delete-' + b.name, text: t('bk_delete'), on: { click: function () { confirmAction(t('bk_delete_q').replace('{n}', b.name), function () { bkPost('/api/backups/' + b.name + '/delete', {}, function () { return t('bk_delete'); }); }); } } })]));
      });
      openModal(t('bk_title'), rows, [h(doc, 'button', { class: 'btn', text: t('close'), on: { click: closeOverlay } })]);
    }

    // ---------- оповещения ----------
    function showAlerts(msg, isErr) {
      api('/api/alerts').then(function (d) { renderAlerts(d, msg, isErr); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function renderAlerts(d, msg, isErr) {
      var rows = [h(doc, 'div', { class: isErr ? 'err' : 'dim', id: 'al-msg', text: msg || '' }), h(doc, 'div', { class: 'dim', text: t('al_how') })];
      var tok = h(doc, 'input', { type: 'password', id: 'al-token', placeholder: t('al_token') + (d.token_set ? ' (' + t('al_token_set') + ')' : ''), autocomplete: 'off' });
      rows.push(h(doc, 'div', { class: 'row' }, [tok, h(doc, 'button', { class: 'btn', id: 'al-token-save', text: t('al_token_save'), on: { click: function () {
        api('/api/alerts/token', { method: 'POST', body: { token: tok.value } }).then(function (s) { renderAlerts(s, t('al_saved'), false); }).catch(function (e) { showAlerts(t('error') + ': ' + e.message, true); }); } } })]));
      var chatId = h(doc, 'input', { type: 'text', id: 'al-chat' }); chatId.value = d.chat_id || '';
      var en = h(doc, 'input', { type: 'checkbox', id: 'al-enabled' }); en.checked = !!d.enabled;
      var cool = h(doc, 'input', { type: 'number', id: 'al-cooldown' }); cool.value = d.cooldown_min;
      var thr = h(doc, 'input', { type: 'number', id: 'al-errors' }); thr.value = d.error_threshold;
      var disk = h(doc, 'input', { type: 'number', id: 'al-disk' }); disk.value = d.disk_percent;
      var evBoxes = {};
      rows.push(h(doc, 'label', {}, [t('al_chat'), chatId]), labelled(t('al_enabled'), en), h(doc, 'div', { class: 'section', text: t('al_events') }));
      Object.keys(d.event_titles).forEach(function (k) {
        var b = h(doc, 'input', { type: 'checkbox', id: 'al-ev-' + k }); b.checked = !!d.events[k]; evBoxes[k] = b;
        rows.push(labelled(d.event_titles[k], b));
      });
      rows.push(h(doc, 'label', {}, [t('al_cooldown'), cool]), h(doc, 'label', {}, [t('al_errors'), thr]), h(doc, 'label', {}, [t('al_disk'), disk]));
      openModal(t('al_title'), rows, [
        h(doc, 'button', { class: 'btn', id: 'al-test', text: t('al_test'), on: { click: function () { api('/api/alerts/test', { method: 'POST', body: {} }).then(function () { showAlerts(t('al_sent'), false); }).catch(function (e) { showAlerts(t('error') + ': ' + e.message, true); }); } } }),
        h(doc, 'button', { class: 'btn', text: t('close'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn', id: 'al-save', text: t('al_save'), on: { click: function () {
          var ev = {}; Object.keys(evBoxes).forEach(function (k) { ev[k] = !!evBoxes[k].checked; });
          api('/api/alerts', { method: 'POST', body: { chat_id: chatId.value, enabled: !!en.checked, events: ev, cooldown_min: parseInt(cool.value, 10), error_threshold: parseInt(thr.value, 10), disk_percent: parseInt(disk.value, 10) } })
            .then(function (s) { renderAlerts(s, t('al_saved'), false); }).catch(function (e) { showAlerts(t('error') + ': ' + e.message, true); }); } } })]);
    }

    // ---------- история и расходы ----------
    function plotSeries(canvas, vals, color, maxv) {
      var g = canvas.getContext('2d'), w = canvas.width, hh = canvas.height, pts = vals.filter(function (v) { return v !== null && v !== undefined; });
      g.clearRect(0, 0, w, hh);
      if (pts.length < 2) return;
      var hi = maxv || Math.max.apply(null, pts.concat([1])), lo = maxv ? 0 : 0;
      g.strokeStyle = color; g.lineWidth = 1.6; g.beginPath();
      var started = false;
      vals.forEach(function (v, i) {
        if (v === null || v === undefined) { started = false; return; }
        var x = vals.length > 1 ? i / (vals.length - 1) * (w - 2) + 1 : 1, y = hh - 3 - (v - lo) / (hi - lo) * (hh - 6);
        if (!started) { g.moveTo(x, y); started = true; } else g.lineTo(x, y);
      });
      g.stroke();
    }
    function showHistory(hours, msg) {
      hours = hours || 24;
      Promise.all([api('/api/history?hours=' + hours), api('/api/usage?days=14')]).then(function (res) { renderHistory(hours, res[0], res[1]); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function renderHistory(hours, hs, us) {
      var sel = h(doc, 'select', { id: 'hs-hours' }, [6, 24, 72, 168].map(function (n) { return h(doc, 'option', { value: String(n), text: n + ' ч' }); }));
      sel.value = String(hours);
      sel.addEventListener('change', function () { showHistory(parseInt(sel.value, 10)); });
      var rows = [h(doc, 'label', {}, [t('hs_hours'), sel])];
      var defs = [['load1', 'hs_load', '#7aa2ff', null], ['mem', 'hs_mem', '#58d68d', 100], ['disk', 'hs_disk', '#f5b041', 100], ['battery', 'hs_battery', '#c792ea', 100], ['temp', 'hs_temp', '#ff6b6b', null]];
      var any = hs.t.length > 1;
      if (!any) rows.push(h(doc, 'div', { class: 'dim', id: 'hs-nodata', text: t('hs_nodata') }));
      defs.forEach(function (d) {
        var vals = hs[d[0]], last = null; vals.forEach(function (v) { if (v !== null) last = v; });
        if (last === null) return;
        var cv = h(doc, 'canvas', { class: 'hsplot', id: 'hs-plot-' + d[0], width: 520, height: 54 });
        rows.push(h(doc, 'div', { class: 'hsrow' }, [h(doc, 'span', { class: 'hsl', id: 'hs-label-' + d[0], text: t(d[1]) + ': ' + last }), cv]));
        plotSeries(cv, vals, d[2], d[3]);
      });
      rows.push(h(doc, 'div', { class: 'section', text: t('hs_usage') }));
      if (!us.days.length) rows.push(h(doc, 'div', { class: 'dim', id: 'hs-nouse', text: t('hs_nodata') }));
      us.days.slice().reverse().forEach(function (dd) {
        rows.push(h(doc, 'div', { class: 'jrow', id: 'hs-day-' + dd.day }, [h(doc, 'span', { class: 'dim', text: dd.day }), h(doc, 'span', { class: 'jn', text: dd.requests + ' ' + t('hs_req') }), h(doc, 'span', { class: 'nl', text: dd.prompt + ' / ' + dd.completion + ' ток · $' + dd.cost.toFixed(4) + (dd.cost_unknown ? ' (' + t('hs_unknown') + ')' : '') })]));
      });
      var tt = us.total;
      if (us.days.length) rows.push(h(doc, 'div', { class: 'jrow', id: 'hs-total' }, [h(doc, 'span', { class: 'jn', text: t('hs_total') }), h(doc, 'span', { class: 'nl', text: tt.requests + ' ' + t('hs_req') + ' · ' + tt.prompt + ' / ' + tt.completion + ' ток · $' + tt.cost.toFixed(4) })]));
      rows.push(h(doc, 'div', { class: 'dim', text: t('hs_bot') }));
      openModal(t('hs_title'), rows, [h(doc, 'button', { class: 'btn', text: t('close'), on: { click: closeOverlay } })]);
    }

    // ---------- командная палитра (Ctrl+K): любое действие в панели без поиска кнопок ----------
    function setTheme(th) { return saveSettings({ theme: th }).then(function () { applyTheme(); if (!S.animating) drawThreads(); }); }
    function togglePro() { return saveSettings({ pro: !S.settings.pro }).then(function () { applyTheme(); return refreshAll(); }); }
    function paletteCommands() {
      var cmds = [];
      function add(group, title, run) { cmds.push({ group: group, title: title, run: run }); }
      add(t('pal_view'), t('view_panel'), function () { setView('panel'); });
      add(t('pal_view'), t('view_arch'), function () { setView('arch'); });
      ['dark', 'light', 'black', 'aurora', 'neon', 'paper'].forEach(function (th) { add(t('pal_theme'), t(th), function () { setTheme(th); }); });
      add('', S.settings.pro ? t('pal_pro_off') : t('pal_pro_on'), togglePro);
      add('', t('pal_refresh'), function () { refreshAll(); });
      add('', t('parts'), showParts); add('', t('settings'), showSettings); add('', t('update'), function () { showUpdate(); });
      add('', t('sm_open'), function () { showSelfmod(); }); add('', t('eco_open'), function () { showEco(); }); add('', t('sys_open'), function () { showSystem(); });
      add('', t('chat_open'), toggleChat); add('', t('pr_open'), function () { showPrompts(); }); add('', t('bk_open'), function () { showBackups(); }); add('', t('al_open'), function () { showAlerts(); }); add('', t('hs_open'), function () { showHistory(); });
      (S.modules || []).forEach(function (m) {
        add(m.name, (m.enabled ? t('pal_mod_off') : t('pal_mod_on')) + ' ' + m.name, function () { moduleAction(m.name, m.enabled ? 'disable' : 'enable'); });
        if (m.enabled && m.running && (m.kind === 'service' || m.kind === 'external')) add(m.name, t('pal_mod_restart') + ' ' + m.name, function () { moduleAction(m.name, 'restart'); });
        add(m.name, t('pal_mod_cfg') + ' ' + m.name, function () { showModule(m.name); });
      });
      return cmds;
    }
    /* Поиск не зависит от раскладки: «куни» находит kuni, «watchdog» находит «вотчдог» и наоборот (простая транслитерация в латиницу и обратный набор клавиш). */
    var TRANSLIT = { 'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'e', 'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm', 'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u', 'ф': 'f',
                     'х': 'h', 'ц': 'c', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch', 'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya' };
    var KEYMAP = { 'й': 'q', 'ц': 'w', 'у': 'e', 'к': 'r', 'е': 't', 'н': 'y', 'г': 'u', 'ш': 'i', 'щ': 'o', 'з': 'p', 'ф': 'a', 'ы': 's', 'в': 'd', 'а': 'f', 'п': 'g', 'р': 'h', 'о': 'j', 'л': 'k', 'д': 'l', 'я': 'z', 'ч': 'x', 'с': 'c', 'м': 'v', 'и': 'b', 'т': 'n', 'ь': 'm' };
    function translit(str, map) { return String(str).toLowerCase().split('').map(function (c) { return map[c] === undefined ? c : map[c]; }).join(''); }
    function haystack(s) { s = s.toLowerCase(); return s + ' ' + translit(s, TRANSLIT) + ' ' + translit(s, KEYMAP); }
    var palette = null;
    function closePalette() { if (palette && palette.parentNode) palette.parentNode.removeChild(palette); palette = null; }
    function openPalette() {
      if (palette) { closePalette(); return; }
      var cmds = paletteCommands(), shown = cmds.slice(), idx = 0;
      var input = h(doc, 'input', { type: 'text', id: 'pal-input', placeholder: t('pal_hint'), autocomplete: 'off' }), list = h(doc, 'div', { id: 'pal-list' });
      function match(q) {
        var ws = q.toLowerCase().split(/\s+/).filter(Boolean);
        if (!ws.length) return cmds.slice();
        var alts = ws.map(function (w) { return [w, translit(w, TRANSLIT), translit(w, KEYMAP)]; });   // слово как набрано, в латинице и как при другой раскладке
        return cmds.filter(function (c) { var s = haystack(c.group + ' ' + c.title); return alts.every(function (v) { return v.some(function (x) { return x && s.indexOf(x) >= 0; }); }); })
          .sort(function (x, y) { return (x.title.toLowerCase().indexOf(ws[0]) < 0 ? 99 : x.title.toLowerCase().indexOf(ws[0])) - (y.title.toLowerCase().indexOf(ws[0]) < 0 ? 99 : y.title.toLowerCase().indexOf(ws[0])); });
      }
      function run(c) { closePalette(); c.run(); }
      function draw() {
        clear(list);
        if (!shown.length) list.appendChild(h(doc, 'div', { class: 'dim', id: 'pal-none', text: t('pal_none') }));
        shown.slice(0, 12).forEach(function (c, i) {
          list.appendChild(h(doc, 'div', { class: 'pal-item' + (i === idx ? ' sel' : ''), id: 'pal-item-' + i, on: { click: function () { run(c); } } }, [h(doc, 'span', { class: 'g', text: c.group }), h(doc, 'span', { class: 'grow nl', text: c.title })]));
        });
      }
      input.addEventListener('input', function () { shown = match(input.value); idx = 0; draw(); });
      input.addEventListener('keydown', function (ev) {
        var n = Math.min(shown.length, 12);
        if (ev.key === 'ArrowDown') { idx = n ? (idx + 1) % n : 0; draw(); } else if (ev.key === 'ArrowUp') { idx = n ? (idx + n - 1) % n : 0; draw(); }
        else if (ev.key === 'Enter') { if (shown[idx]) run(shown[idx]); } else if (ev.key === 'Escape') { closePalette(); } else return;
        if (ev.preventDefault) ev.preventDefault();
        if (ev.stopPropagation) ev.stopPropagation();
      });
      palette = h(doc, 'div', { id: 'palette' }, [h(doc, 'div', { class: 'pal-back', on: { click: closePalette } }), h(doc, 'div', { class: 'pal-box', title: t('pal_title') }, [input, list])]);
      doc.body.appendChild(palette);
      draw();
      if (input.focus) input.focus();
    }
    doc.addEventListener('keydown', function (ev) { if ((ev.ctrlKey || ev.metaKey) && String(ev.key).toLowerCase() === 'k') { if (ev.preventDefault) ev.preventDefault(); openPalette(); } });

    // ---------- экосистема: наборы деталей ----------
    function showEco(msg, isErr) {
      api('/api/eco').then(function (d) { renderEco(d, msg, isErr); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function renderEco(d, msg, isErr) {
      var rows = [h(doc, 'div', { class: isErr ? 'err' : 'dim', id: 'eco-msg', text: msg || '' })];
      rows.push(h(doc, 'div', { class: d.catalog.warn ? 'err' : 'dim', id: 'eco-catalog', text: t('eco_catalog') + ': ' + d.catalog.tools + ' ' + t('eco_tools') + ', ≈ ' + d.catalog.tokens + ' ' + t('eco_tokens') + '. ' + (d.catalog.warn ? t('eco_warn') : t('eco_ok')) }));
      d.sets.forEach(function (st) {
        var box = h(doc, 'input', { type: 'checkbox', id: 'eco-set-' + st.key });
        box.checked = !!st.enabled;
        box.addEventListener('change', function () {
          var want = box.checked, q = (want ? t('eco_set_on_q') + (st.key === 'base' ? t('eco_set_rule_q') : '') : t('eco_set_off_q')).replace('{n}', st.title);
          box.checked = !!st.enabled;   // пока владелец не подтвердил, переключатель остаётся прежним
          confirmAction(q, function () {
            api('/api/eco/set', { method: 'POST', body: { key: st.key, enabled: want } }).then(function (r) { renderEco(r, st.title + ': ' + (want ? t('eco_state_on') : t('eco_state_off')), false); refreshAll(); })
              .catch(function (e) { showEco(t('error') + ': ' + e.message, true); });
          });
        });
        rows.push(h(doc, 'div', { class: 'section', text: st.title + ' · ≈ ' + st.tokens + ' ' + t('eco_tokens') }));
        rows.push(labelled(st.desc, box));
        st.modules.forEach(function (m) {
          var state = !m.installed ? t('eco_state_missing') : m.enabled ? t('eco_state_on') : t('eco_state_off');
          rows.push(h(doc, 'div', { class: 'row bt', id: 'eco-mod-' + m.name }, [dot(m.enabled ? 'ok' : m.installed ? 'warn' : ''), h(doc, 'span', { class: 'grow nl', text: m.name + ' · ' + m.tools + ' ' + t('eco_tools') + ' · ≈ ' + m.tokens + ' ' + t('eco_tokens') }),
            h(doc, 'span', { class: 'dim', text: state + (m.pending_trust ? ' · ' + t('eco_pending') : '') })]));
        });
      });
      rows.push(h(doc, 'div', { class: 'dim', text: t('eco_note') }));
      openModal(t('eco_title'), rows, [h(doc, 'button', { class: 'btn', id: 'eco-close', text: t('close'), on: { click: closeOverlay } })]);
    }

    // ---------- система: диагностика, готовые детали, связь с ботом (всё, что раньше было только в терминале) ----------
    function showSystem(msg, isErr, doctor) {
      api('/api/available').then(function (av) { renderSystem2(av, msg, isErr, doctor); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function renderSystem2(av, msg, isErr, doctor) {
      var rows = [h(doc, 'div', { class: isErr ? 'err' : 'dim', id: 'sys-msg', text: msg || '' })];
      rows.push(h(doc, 'div', { class: 'section', text: t('sys_doctor') }));
      var checkBtn = h(doc, 'button', { class: 'btn', id: 'sys-check', text: t('sys_check'), on: { click: function () {
        checkBtn.textContent = t('sys_checking');
        api('/api/system/doctor').then(function (d) { renderSystem2(av, msg, isErr, d); }).catch(function (e) { showSystem(t('error') + ': ' + e.message, true); });
      } } });
      rows.push(h(doc, 'div', { class: 'row' }, [checkBtn]));
      if (doctor) {
        doctor.checks.forEach(function (c, i) {
          rows.push(h(doc, 'div', { class: 'row', id: 'sys-check-' + i }, [dot(c.status === 'ok' ? 'ok' : c.status === 'warn' ? 'warn' : 'bad'), h(doc, 'span', { class: 'grow', text: c.title + (c.detail ? ': ' + c.detail : '') })]));
          if (c.status !== 'ok' && c.fix) rows.push(h(doc, 'div', { class: 'dim', id: 'sys-fix-' + i, text: '→ ' + t('sys_fix') + ': ' + c.fix }));
        });
        rows.push(h(doc, 'div', { class: doctor.bad ? 'err' : 'dim', id: 'sys-summary', text: t('sys_summary').replace('{bad}', doctor.bad).replace('{warn}', doctor.warn) }));
      }
      rows.push(h(doc, 'div', { class: 'section', text: t('sys_avail') }));
      var todo = av.modules.filter(function (m) { return !m.installed; });
      if (!todo.length) rows.push(h(doc, 'div', { class: 'dim', id: 'sys-avail-none', text: t('sys_avail_none') }));
      av.modules.forEach(function (m) {
        var right = m.installed ? h(doc, 'span', { class: 'dim', text: t('sys_installed') }) : h(doc, 'button', { class: 'btn', id: 'sys-install-' + m.name, text: t('sys_install'), on: { click: function () {
          api('/api/available/install', { method: 'POST', body: { name: m.name } }).then(function (r) { renderSystem2(r, m.name + ': ' + t('sys_installed'), false, doctor); refreshAll(); })
            .catch(function (e) { showSystem(t('error') + ': ' + e.message, true); });
        } } });
        rows.push(h(doc, 'div', { class: 'row bt', id: 'sys-avail-' + m.name }, [h(doc, 'span', { class: 'grow nl', text: m.name + ' ' + m.version + ' (' + m.kind + ')', title: m.description }), right]));
        rows.push(h(doc, 'div', { class: 'dim nl', title: m.description, text: m.description }));
      });
      rows.push(h(doc, 'div', { class: 'section', text: t('sys_wire') }));
      rows.push(h(doc, 'div', { class: 'dim', text: t('sys_wire_note') }));
      rows.push(h(doc, 'div', { class: 'row' }, [h(doc, 'button', { class: 'btn', id: 'sys-wire', text: t('sys_wire_btn'), on: { click: function () {
        api('/api/wire-kuni', { method: 'POST', body: {} }).then(function (r) { renderSystem2(av, t('sys_wire_done') + ': ' + t('sys_wire_' + r.result) + ' (' + r.config + ')', false, doctor); })
          .catch(function (e) { renderSystem2(av, t('error') + ': ' + e.message, true, doctor); });
      } } })]));
      openModal(t('sys_title'), rows, [h(doc, 'button', { class: 'btn', id: 'sys-close', text: t('close'), on: { click: closeOverlay } })]);
    }

    // ---------- самостоятельные детали Марин ----------
    function showSelfmod(msg, isErr, openSrc) {
      api('/api/selfmod').then(function (st) { renderSelfmod(st, msg, isErr, openSrc || {}); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function selfmodCall(path, body, okMsg) {
      return api(path, { method: 'POST', body: body || {} }).then(function (st) { renderSelfmod(st, okMsg, false, {}); refreshAll(); }).catch(function (e) { showSelfmod(t('error') + ': ' + e.message, true); });
    }
    function renderSelfmod(st, msg, isErr, open) {
      var rows = [h(doc, 'div', { class: isErr ? 'err' : 'dim', id: 'sm-msg', text: msg || '' })];
      var box = h(doc, 'input', { type: 'checkbox', id: 'sm-enabled' });
      box.checked = !!st.enabled;
      box.addEventListener('change', function () {
        var want = box.checked;
        confirmAction(want ? t('sm_enable_q') : t('sm_off_q'), function () { selfmodCall('/api/selfmod/settings', { enabled: want }); });
        box.checked = !!st.enabled;   // пока владелец не подтвердил, переключатель остаётся прежним
      });
      rows.push(labelled(t('sm_enable'), box));
      rows.push(h(doc, 'div', { class: 'dim', id: 'sm-info', text: (st.enabled ? t('sm_on_note') : t('sm_off_note')) + ' · ' + t('sm_info') + ': ' + st.modules.filter(function (m) { return m.status !== 'removed'; }).length + '/' + st.limits.max_modules + ' · ' + t('sm_hour') + ': ' + st.used_hour + '/' + st.limits.max_per_hour }));
      rows.push(h(doc, 'div', { class: 'dim', text: t('sm_walls') }));
      rows.push(h(doc, 'div', { class: 'section', text: t('sm_journal') }));
      if (!st.journal.length) rows.push(h(doc, 'div', { class: 'dim', text: t('sm_journal_none') }));
      st.journal.slice(0, 14).forEach(function (j) {
        var d = new Date(j.t * 1000);
        rows.push(h(doc, 'div', { class: 'jrow' + (j.ok ? '' : ' err'), title: j.text }, [h(doc, 'span', { class: 'dim', text: pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) }),
          h(doc, 'span', { class: 'jn', text: j.name + ' · ' + j.step }), h(doc, 'span', { class: 'nl', text: j.text })]));
      });
      var live = st.modules.filter(function (m) { return m.status !== 'removed'; });
      if (!live.length) rows.push(h(doc, 'div', { class: 'dim', id: 'sm-none', text: t('sm_none') }));
      live.forEach(function (m) {
        var codeBtn = h(doc, 'button', { class: 'btn', id: 'sm-code-' + m.name, text: open[m.name] ? t('sm_hide_code') : t('sm_code'), on: { click: function () {
          if (open[m.name]) { delete open[m.name]; renderSelfmod(st, msg, isErr, open); return; }
          api('/api/selfmod/' + m.name + '/source').then(function (r) { open[m.name] = r.files; renderSelfmod(st, msg, isErr, open); }).catch(function (e) { showSelfmod(t('error') + ': ' + e.message, true); });
        } } });
        var toggle = h(doc, 'button', { class: 'btn', id: 'sm-toggle-' + m.name, text: m.status === 'active' ? t('sm_disable') : t('sm_enable_btn'), on: { click: function () { selfmodCall('/api/selfmod/' + m.name + '/' + (m.status === 'active' ? 'disable' : 'enable')); } } });
        var del = h(doc, 'button', { class: 'btn danger', id: 'sm-remove-' + m.name, text: t('sm_remove'), on: { click: function () { confirmAction(t('sm_remove_q'), function () { selfmodCall('/api/selfmod/' + m.name + '/remove'); }); } } });
        rows.push(h(doc, 'div', { class: 'row bt', id: 'sm-row-' + m.name }, [dot(m.status === 'active' ? 'ok' : 'warn'), h(doc, 'span', { class: 'grow nl', text: m.name + ' ' + (m.version || ''), title: m.description }),
          h(doc, 'span', { class: 'dim', text: t('st_' + m.status) }), codeBtn, toggle, del]));
        rows.push(h(doc, 'div', { class: 'dim nl', title: m.description, text: t('sm_tools') + ': ' + m.tools.join(', ') + ' · ' + m.description }));
        if (open[m.name]) Object.keys(open[m.name]).forEach(function (f) { rows.push(h(doc, 'pre', { class: 'srcview', id: 'sm-src-' + m.name + '-' + f, text: f + '\n' + open[m.name][f] })); });
      });
      var buttons = [h(doc, 'button', { class: 'btn', id: 'sm-close', text: t('close'), on: { click: closeOverlay } })];
      if (st.enabled || live.some(function (m) { return m.status === 'active'; })) {
        buttons.push(h(doc, 'button', { class: 'btn danger', id: 'sm-stop-all', text: t('sm_stop_all'), on: { click: function () { confirmAction(t('sm_stop_all_q'), function () { selfmodCall('/api/selfmod/settings', { enabled: false, disable_all: true }); }); } } }));
      }
      openModal(t('sm_title'), rows, buttons);
    }

    // ---------- верхняя панель ----------
    function applyTheme() { doc.body.className = 'theme-' + S.settings.theme + (S.settings.pro ? ' pro' : ''); S.staticDirty = true; }
    function buildTopbar() {
      clear(topbar);
      statusEl = h(doc, 'span', { class: 'status', text: '' });
      topbar.appendChild(h(doc, 'span', { class: 'brand', text: t('app') }));
      topbar.appendChild(h(doc, 'span', { class: 'badge', text: 'WebUI' }));
      ['panel', 'arch'].forEach(function (v) {
        topbar.appendChild(h(doc, 'button', { class: 'btn tab' + (S.settings.view === v ? ' active' : ''), id: 'tab-' + v, text: t('view_' + v), on: { click: function () { setView(v); } } }));
      });
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-parts', text: t('parts'), on: { click: showParts } }));
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-hidden', text: '＋', title: t('restore'), on: { click: showHidden } }));
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-settings', text: '⚙', title: t('settings'), on: { click: showSettings } }));
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-chat', text: '💬', title: t('chat_open'), on: { click: toggleChat } }));
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-palette', text: '⌘', title: t('pal_open'), on: { click: openPalette } }));
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-refresh', text: '⟳', on: { click: function () { refreshAll(); } } }));
      chips = h(doc, 'span', { class: 'chips', id: 'chips' });   // строка состояния: бот, события в минуту, ошибки за 10 минут
      topbar.appendChild(chips);
      topbar.appendChild(statusEl);
      updateChips();
    }

    // ---------- отрисовка содержимого ----------
    function kv(rows) {
      return h(doc, 'table', { class: 'kv' }, rows.map(function (r) {
        return h(doc, 'tr', {}, [h(doc, 'td', { class: 'k', text: String(r[0]) }), h(doc, 'td', { class: 'v', text: String(r[1]) })]);
      }));
    }
    function dot(cls) { return h(doc, 'span', { class: 'dot ' + (cls || '') }); }
    function fmtDur(sec) {
      if (sec < 90) return sec + ' ' + t('s');
      if (sec < 5400) return Math.round(sec / 60) + ' ' + t('min');
      return Math.floor(sec / 3600) + ' ' + t('h') + ' ' + Math.round((sec % 3600) / 60) + ' ' + t('min');
    }
    function text(body, msg, cls) { body.appendChild(h(doc, 'div', { class: cls || '', text: msg })); }

    /* Расширенный вид: датчик-кольцо (заполнение через conic-gradient: дёшево для видеокарты и процессора, ничего не перерисовывается каждый кадр). */
    function gauge(label, pct, value, cls) {
      var p = Math.max(0, Math.min(100, Math.round(pct || 0)));
      var g = h(doc, 'div', { class: 'gauge ' + (cls || (p >= 90 ? 'bad' : p >= 70 ? 'warn' : 'ok')), 'data-p': String(p) }, [h(doc, 'span', { class: 'gv', text: value }), h(doc, 'span', { class: 'gl', text: label })]);
      if (g.style && g.style.setProperty) g.style.setProperty('--p', String(p));
      return g;
    }
    function renderSystem(body, d) {
      var host = d.host || {};
      if (S.settings.pro) {   // два кольца (нагрузка и память) и короткая таблица
        var load = host.load1 === null || host.load1 === undefined ? null : host.load1, mem = host.mem_pct === null || host.mem_pct === undefined ? null : host.mem_pct;
        body.appendChild(h(doc, 'div', { class: 'gauges' }, [gauge(t('gauge_load'), load === null ? 0 : load * 50, load === null ? '?' : String(load)), gauge(t('gauge_ram'), mem === null ? 0 : mem, mem === null ? '?' : Math.round(mem) + '%')]));
        body.appendChild(kv([[t('version'), d.zerocore], [t('uptime'), fmtDur(d.uptime)], [t('modules'), d.enabled + ' / ' + d.modules], [t('integrity'), d.integrity && d.integrity.length ? d.integrity.join('; ') : 'OK']]));
        return;
      }
      body.appendChild(kv([
        [t('version'), d.zerocore], ['Python', d.python], [t('os'), d.os], ['PID', d.pid], [t('home'), d.home],
        [t('uptime'), fmtDur(d.uptime)], [t('modules'), d.enabled + ' / ' + d.modules],
        [t('integrity'), d.integrity && d.integrity.length ? d.integrity.join('; ') : 'OK'],
        [t('host'), 'load ' + (host.load1 === null ? '?' : host.load1) + ' · RAM ' + (host.mem_pct === null ? '?' : host.mem_pct + '%')]
      ]));
    }
    function renderLlm(body, d) {
      if (!d.available) return text(body, d.error || t('no_data'), 'dim');
      body.appendChild(kv([[t('provider'), d.provider], [t('model'), d.model], [t('endpoint'), d.host],
                           [t('embedding'), d.embedding_model + (d.embedding_host ? ' @ ' + d.embedding_host : '')], [t('lockdown'), d.lockdown]]));
    }
    function renderTransports(body, d) {
      if (!d.length) return text(body, t('none'), 'dim');
      d.forEach(function (x) {
        if (S.settings.pro) {   // карточка: цветная плашка состояния, имя, возможность
          body.appendChild(h(doc, 'div', { class: 'row tcard' }, [h(doc, 'span', { class: 'pill ' + (x.running ? 'h-healthy' : 'h-bad'), text: x.running ? t('run_on') : t('run_off') }), h(doc, 'span', { class: 'grow nl', text: x.name }), h(doc, 'span', { class: 'dim', text: x.capability })]));
          return;
        }
        body.appendChild(h(doc, 'div', { class: 'row' }, [dot(x.running ? 'ok' : 'bad'), h(doc, 'span', { class: 'grow', text: x.name }),
          h(doc, 'span', { class: 'dim', text: x.capability })]));
      });
    }
    function renderStats(body, d) {
      if (S.settings.pro) {   // плитки с крупными числами; ошибки красным, отказы жёлтым
        var tiles = [[t('st_tile_llm'), d.llm_requests_today, ''], [t('st_tile_shell'), d.shell_commands, ''], [t('st_tile_sent'), d.messages_sent, ''], [t('st_tile_ext'), d.external_calls || 0, ''],
                     [t('st_tile_refused'), d.guard_refusals, d.guard_refusals ? 'warn' : ''], [t('st_tile_err'), (d.errors || 0) + (d.llm_http_errors || 0), (d.errors || 0) + (d.llm_http_errors || 0) ? 'bad' : '']];
        body.appendChild(h(doc, 'div', { class: 'tiles' }, tiles.map(function (x) { return h(doc, 'div', { class: 'tile ' + x[2] }, [h(doc, 'span', { class: 'num', text: String(x[1] === undefined || x[1] === null ? 0 : x[1]) }), h(doc, 'span', { class: 'lab', text: x[0] })]); })));
        return;
      }
      body.appendChild(kv([[t('st_llm_today'), d.llm_requests_today], [t('st_shell'), d.shell_commands], [t('st_sent'), d.messages_sent], [t('st_external'), d.external_calls || 0],
                           [t('st_refused'), d.guard_refusals], [t('st_http'), d.llm_http_errors], [t('st_errors'), d.errors]]));
    }
    function renderGeneration(body, d) {
      if (!d.known) return text(body, t('no_data'), 'dim');
      if (d.active) return body.appendChild(h(doc, 'div', {}, [dot('warn'), t('generating') + ' · ' + Math.round(d.since) + ' ' + t('s')]));
      body.appendChild(h(doc, 'div', {}, [dot(''), t('idle')]));
      if (d.last_seconds !== null && d.last_seconds !== undefined) text(body, t('last_gen') + ': ' + d.last_seconds + ' ' + t('s') + (d.ago !== undefined ? ' · ' + fmtDur(d.ago) + ' ' + t('ago') : ''), 'dim');
    }
    function spark(canvas, series, color, max) {
      var ctx = canvas.getContext('2d'), w = canvas.width, hgt = canvas.height;
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.beginPath();
      var started = false;
      series.forEach(function (v, i) {
        if (v === null || v === undefined) return;
        var x = series.length < 2 ? 0 : (i / (series.length - 1)) * (w - 2) + 1, y = hgt - 2 - Math.min(1, v / max) * (hgt - 4);
        if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y);
      });
      ctx.stroke();
    }
    function renderLoad(body, pts) {
      if (!pts.length) return text(body, t('no_data'), 'dim');
      var canvas = h(doc, 'canvas', { class: 'spark', width: 600, height: 100 });
      body.appendChild(canvas);
      var loads = pts.map(function (p) { return p.load1; }), maxLoad = Math.max.apply(null, [1].concat(loads.filter(function (v) { return v !== null; })));
      spark(canvas, loads, '#7aa2ff', maxLoad);
      spark(canvas, pts.map(function (p) { return p.mem; }), '#58d68d', 100);
      var last = pts[pts.length - 1];
      if (S.settings.pro) body.insertBefore(h(doc, 'div', { class: 'bignums' }, [h(doc, 'span', { class: 'bn', text: 'load ' + last.load1 }), h(doc, 'span', { class: 'bn g', text: 'RAM ' + last.mem + '%' })]), canvas);
      body.appendChild(h(doc, 'div', { class: 'legend', text: 'load ' + last.load1 + ' (max ' + maxLoad.toFixed(1) + ') · RAM ' + last.mem + '% · ' + t('rss') + ' ' + (last.rss === null ? '—' : last.rss + ' MB') }));
    }
    function renderLog(body, rows, ctx) {
      var st = ctx.def.state;
      if (!st.lines) {
        st.lines = h(doc, 'div', { class: 'loglines' });
        var sel = h(doc, 'select', { id: 'log-filter' }, ['all', 'core', 'kuni'].map(function (v) {
          return h(doc, 'option', { value: v, text: v === 'all' ? t('all') : v === 'core' ? t('core_src') : t('kuni_src') }); }));
        sel.value = S.logFilter;
        sel.addEventListener('change', function () { S.logFilter = sel.value; refreshDef(ctx.def); });
        st.search = h(doc, 'input', { type: 'text', id: 'log-search', placeholder: t('log_search'), value: S.logSearch });
        st.search.addEventListener('input', function () { S.logSearch = (st.search.value || '').toLowerCase(); ctx.def.key = null; refreshDef(ctx.def); });
        st.bar = h(doc, 'div', { class: 'logbar' }, [sel]);
      }
      var searchIn = st.search.parentNode === st.bar;   // parentNode, а не children.indexOf: в браузере children это не массив
      if (S.settings.pro && !searchIn) st.bar.appendChild(st.search);
      if (!S.settings.pro && searchIn) st.bar.removeChild(st.search);
      clear(st.lines);
      rows.filter(function (r) { return (S.logFilter === 'all' || r.src === S.logFilter) && (!S.settings.pro || !S.logSearch || r.text.toLowerCase().indexOf(S.logSearch) >= 0); }).forEach(function (r) {
        var cls = /\[(ERR|ERROR)\]|HTTP_[45]/.test(r.text) ? 'bad' : /\[WARN\]/.test(r.text) ? 'warn' : r.src === 'core' ? 'core' : '';
        if (S.settings.pro) {   // бейджи: уровень (INFO, WARN, ERROR) и источник (core, kuni); текст без служебной скобки уровня
          var lv = /\[(INFO|WARN|WARNING|ERR|ERROR)\]/.exec(r.text), level = lv ? (lv[1] === 'WARNING' ? 'WARN' : lv[1] === 'ERR' ? 'ERROR' : lv[1]) : (cls === 'bad' ? 'ERROR' : '');
          st.lines.appendChild(h(doc, 'div', { class: 'logline ' + cls }, [h(doc, 'span', { class: 'ts', text: fmtTime(r.t) }), h(doc, 'span', { class: 'lb src-' + r.src, text: r.src }),
            level ? h(doc, 'span', { class: 'lb lv-' + level, text: level }) : '', r.text.replace(/\[(INFO|WARN|WARNING|ERR|ERROR)\]:?\s?/, '')].filter(function (x) { return x !== ''; })));
          return;
        }
        st.lines.appendChild(h(doc, 'div', { class: 'logline ' + cls }, [h(doc, 'span', { class: 'ts', text: fmtTime(r.t) }), r.text]));
      });
      body.appendChild(st.bar);
      body.appendChild(st.lines);
      body.scrollTop = body.scrollHeight;
    }
    /* Подтверждение: окно внутри панели (в тон теме, работает на телефоне); env.confirm, если задан, имеет приоритет (тесты). */
    function confirmAction(message, onYes) {
      if (env.confirm) { if (env.confirm(message)) onYes(); return; }
      openModal(t('confirm_title'), [h(doc, 'div', { text: message })], [
        h(doc, 'button', { class: 'btn', id: 'confirm-no', text: t('cancel'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn danger', id: 'confirm-yes', text: t('confirm'), on: { click: function () { closeOverlay(); onYes(); } } })
      ]);
    }
    function moduleAction(name, action) {
      var risky = action === 'stop' || action === 'disable' || action === 'restart';
      if (risky) return confirmAction(t(action) + ' ' + name + '?', function () { runModuleAction(name, action); });
      runModuleAction(name, action);
    }
    function runModuleAction(name, action) {
      setStatus(t(action) + ' ' + name + '…', false);
      api('/api/modules/' + name + '/' + action, { method: 'POST', body: action === 'disable' ? { cascade: false } : {} })
        .then(function () { setStatus('OK: ' + t(action) + ' ' + name, false); return syncModules(); })
        .then(function () { refreshAll(); })
        .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function moduleDotClass(m) { return !m.enabled ? '' : m.health === 'healthy' ? 'ok' : (m.health === 'unhealthy' || m.health === 'broken') ? 'bad' : m.running ? 'ok' : 'warn'; }
    function moduleButtons(m, withGear) {
      var btns = [h(doc, 'button', { class: 'btn', text: m.enabled ? t('disable') : t('enable'), on: { click: function () { moduleAction(m.name, m.enabled ? 'disable' : 'enable'); } } })];
      if (m.enabled && (m.kind === 'service' || m.kind === 'external')) {
        btns.push(h(doc, 'button', { class: 'btn', text: m.running ? t('stop') : t('start'), on: { click: function () { moduleAction(m.name, m.running ? 'stop' : 'start'); } } }));
        if (m.running) btns.push(h(doc, 'button', { class: 'btn', text: t('restart'), on: { click: function () { moduleAction(m.name, 'restart'); } } }));
      }
      if (withGear) btns.push(gearButton(m.name));
      return btns;
    }
    /* Шестерёнка (настройки детали) не занимает места, пока на строку не навели мышь (на сенсорных экранах видна всегда): вид как на видео, функция на месте. */
    function gearButton(name) { return h(doc, 'button', { class: 'btn gear', text: '⚙', title: t('module_settings'), on: { click: function () { showModule(name); } } }); }
    /* Компактные кнопки (тесный экран): «вкл/выкл» словом и значки; полные названия в подсказках. */
    function archButtons(m) {
      function ic(text, title, fn) { return h(doc, 'button', { class: 'btn ic', text: text, title: title, on: { click: fn } }); }
      var btns = [ic(m.enabled ? t('short_off') : t('short_on'), m.enabled ? t('disable') : t('enable'), function () { moduleAction(m.name, m.enabled ? 'disable' : 'enable'); })];
      if (m.enabled && (m.kind === 'service' || m.kind === 'external')) {
        btns.push(ic(m.running ? '■' : '▶', m.running ? t('stop') : t('start'), function () { moduleAction(m.name, m.running ? 'stop' : 'start'); }));
        if (m.running) btns.push(ic('↻', t('restart'), function () { moduleAction(m.name, 'restart'); }));
      }
      return btns;
    }
    /* Строка детали в «Плагинах»: в ней оба вида (полный и компактный), какой виден, решает класс доски (см. стили). */
    function moduleRow(m) {
      return h(doc, 'div', { class: 'row bt' + (S.settings.pro ? ' pcard' : ''), 'data-owner': m.name, title: m.kind + ' · ' + m.health }, [dot(moduleDotClass(m)), h(doc, 'span', { class: 'grow nl', text: m.name + ' ' + m.version, title: m.detail || '' }),
        S.settings.pro ? h(doc, 'span', { class: 'full pills' }, [h(doc, 'span', { class: 'pill k-' + m.kind, text: m.kind }), h(doc, 'span', { class: 'pill h-' + m.health, text: m.health })]) : h(doc, 'span', { class: 'dim full', text: m.kind + ' · ' + m.health }),
        h(doc, 'span', { class: 'full' }, moduleButtons(m, false)),
        h(doc, 'span', { class: 'abtns cmp' }, archButtons(m)), gearButton(m.name)]);
    }
    function renderPlugins(body, mods) {
      mods.slice().sort(function (a, b) { return (a.name === 'kuni' ? 0 : 1) - (b.name === 'kuni' ? 0 : 1) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0); })   // главный модуль первым, остальные по алфавиту
          .forEach(function (m) { body.appendChild(moduleRow(m)); });
    }
    /* Узел архитектуры: состояние, описание, у модулей те же кнопки, что в «Плагинах». */
    function renderArchNode(body, n, ctx) {
      var node = S.nodes[ctx.def.id];
      if (node) {
        ['grp-kernel', 'grp-manager', 'grp-module', 'grp-kuni', 'grp-external'].forEach(function (c) { node.el.classList.remove(c); });
        node.el.classList.add('grp-' + n.group);
        if (n.status === 'off') node.el.classList.add('off'); else node.el.classList.remove('off');
      }
      var lines = (n.lines || []).filter(Boolean);
      if (node && !node.spark) {   // мини-график: 20 полосок-элементов (холст внутри двигаемого окна стоил плавности переноса)
        node.spark = h(doc, 'span', { class: 'nspark', title: t('spark_title') });
        for (var si = 0; si < SPARK_BUCKETS; si++) node.spark.appendChild(h(doc, 'i', {}));
        node.head.insertBefore(node.spark, node.head.lastChild);
      }
      if (n.module) {   // оба вида в узле; какой виден, решает класс доски: полный (как на видео) или компактный
        var m = { name: n.module, version: n.version, kind: n.kind, enabled: n.enabled, running: n.running, health: n.health, detail: '' };
        var info = m.version + ' · ' + m.kind + ' · ' + m.health;
        body.appendChild(h(doc, 'div', { class: 'row full' }, [dot(moduleDotClass(m)), h(doc, 'span', { class: 'grow', text: m.version + ' · ' + m.kind }), h(doc, 'span', { class: 'dim', text: m.health })]));
        body.appendChild(h(doc, 'div', { class: 'row full btnrow', 'data-owner': m.name }, [h(doc, 'span', { class: 'fbtns' }, moduleButtons(m, false))]));
        body.appendChild(h(doc, 'div', { class: 'row cmp' }, [dot(moduleDotClass(m)), h(doc, 'span', { class: 'grow nl', title: info, text: info })]));
        body.appendChild(h(doc, 'div', { class: 'row cmp', 'data-owner': m.name }, [h(doc, 'span', { class: 'abtns' }, archButtons(m))]));
        if (lines.length) body.appendChild(h(doc, 'div', { class: 'dim nl', title: lines.join('\n'), text: lines[0] }));
        if (node && !node.gear) {   // шестерёнка в заголовке: видна при наведении на узел, места в теле не занимает
          node.gear = h(doc, 'button', { class: 'wg', title: t('module_settings'), text: '⚙', on: { click: function () { showModule(m.name); } } });
          node.head.insertBefore(node.gear, node.head.lastChild);
        }
        return;
      }
      var cls = n.status === 'ok' ? 'ok' : n.status === 'bad' ? 'bad' : (n.status === 'warn' || n.status === 'idle') ? 'warn' : '';
      body.appendChild(h(doc, 'div', { class: 'row' }, [dot(cls), h(doc, 'span', { class: 'grow', text: t('node_' + n.status) })]));
      lines.forEach(function (line) { body.appendChild(h(doc, 'div', { class: 'dim nl', title: line, text: line })); });   // одна строка с многоточием, полный текст в подсказке
    }
    function renderTools(body, tools) {
      if (!tools.length) return text(body, t('no_data'), 'dim');
      text(body, t('tools_count') + ': ' + tools.length, 'dim');
      tools.forEach(function (x) { body.appendChild(h(doc, 'div', { class: 'row', title: x.description }, [h(doc, 'span', { text: '▸ ' + x.name })])); });
    }
    function renderModuleWidget(body, d, ctx) {
      if (!d.ok) return text(body, t('error') + ': ' + d.error, 'err');
      if (d.kind === 'kv') body.appendChild(kv(d.data.items));
      else if (d.kind === 'text') body.appendChild(h(doc, 'pre', { text: d.data.text }));
      else if (d.kind === 'table') {
        body.appendChild(h(doc, 'table', { class: 'grid' }, [h(doc, 'tr', {}, d.data.columns.map(function (c) { return h(doc, 'th', { text: String(c) }); }))]
          .concat(d.data.rows.map(function (r) { return h(doc, 'tr', {}, r.map(function (c) { return h(doc, 'td', { text: String(c) }); })); }))));
      } else if (d.kind === 'counter') {
        body.appendChild(h(doc, 'div', { class: 'counter-value', text: String(d.data.value) }));
        body.appendChild(h(doc, 'div', { class: 'counter-label', text: d.data.label || '' }));
      }
      if (d.actions && d.actions.length) {
        body.appendChild(h(doc, 'div', { class: 'actions' }, d.actions.map(function (a) {
          return h(doc, 'button', { class: 'btn', text: a.label, on: { click: function () {
            api('/api/widget/' + ctx.def.mod + '/' + ctx.def.wid + '/action/' + a.id, { method: 'POST', body: {} })
              .then(function (res) { renderInto(ctx.def, res); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); }); } } });
        })));
      }
      if (d.note) body.appendChild(h(doc, 'div', { class: 'note', text: d.note }));
    }

    // ---------- описания виджетов ----------
    function builtinDefs() {
      function d(id, w, hgt, refresh, load, render, x, y) { return { id: id, title: id, w: w, h: hgt, x: x, y: y, refresh: refresh, load: load, render: render, state: {}, next: 0, builtin: true }; }
      return [   // раскладка как на видео (30 рядов): вверху «Система», «Статистика», «Транспорты»; в середине «Плагины»; внизу лог и график. LLM, «Генерация», «Тулы» по умолчанию скрыты и ставятся сами, если их показать
        d('system', 6, 8, 10, function () { return api('/api/system'); }, renderSystem, 1, 1),
        d('llm', 8, 6, 30, function () { return api('/api/llm'); }, renderLlm),
        d('transports', 6, 5, 10, function () { return api('/api/transports'); }, renderTransports, 17, 1),
        d('stats', 6, 7, 10, function () { return api('/api/stats'); }, renderStats, 9, 0),
        d('generation', 8, 5, 3, function () { return api('/api/generation'); }, renderGeneration),
        d('load', 9, 8, 5, function () { return api('/api/metrics'); }, renderLoad, 14, 22),
        d('plugins', 8, 9, 5, function () { return Promise.resolve(S.modules); }, renderPlugins, 8, 10),
        d('tools', 12, 8, 30, function () { return api('/api/tools'); }, renderTools),
        d('log', 9, 8, 3, function () { return api('/api/log?n=' + S.settings.log_lines); }, renderLog, 1, 22)
      ];
    }
    function title(def) { return def.rawTitle ? def.title : t(def.title); }
    function syncModules() {
      return api('/api/modules').then(function (mods) {
        S.modules = mods;
        var keep = S.defs.filter(function (d) { return d.builtin; }), extra = [];
        mods.forEach(function (m) {
          (m.widgets || []).forEach(function (w) {
            var id = 'm:' + m.name + ':' + w.id;
            var existing = S.defs.filter(function (d) { return d.id === id; })[0];
            var dp = DEFAULT_POS[id];
            extra.push(existing || { id: id, rawTitle: true, title: w.title, mod: m.name, wid: w.id, w: dp ? dp.w : w.size.w, h: dp ? dp.h : w.size.h, x: dp ? dp.x : undefined, y: dp ? dp.y : undefined, refresh: w.refresh,
                                     load: function () { return api('/api/widget/' + m.name + '/' + w.id); }, render: renderModuleWidget, state: {}, next: 0 });
          });
        });
        var changed = extra.map(function (d) { return d.id; }).join() !== S.defs.filter(function (d) { return !d.builtin; }).map(function (d) { return d.id; }).join();
        S.defs = keep.concat(extra);
        if (changed) rebuildAll();
      });
    }

    /* Архитектура: узлы строит сервер из живого реестра; здесь они становятся виджетами, а связи нитями. */
    function syncArchitecture() {
      return api('/api/architecture').then(function (g) {
        S.arch = g;
        S.archById = {};
        g.nodes.forEach(function (n) { S.archById[n.id] = n; });
        var existing = {};
        S.archDefs.forEach(function (d) { existing[d.id] = d; });
        var defs = g.nodes.map(function (n) {
          var d = existing['a:' + n.id] || { id: 'a:' + n.id, rawTitle: true, w: n.pos.w, h: n.pos.h, x: n.pos.x, y: n.pos.y, refresh: 5, state: {}, next: 0, arch: true,
            load: function () { return Promise.resolve(S.archById[n.id]); }, render: renderArchNode };
          d.title = n.title;
          return d;
        });
        var changed = defs.map(function (d) { return d.id; }).join() !== S.archDefs.map(function (d) { return d.id; }).join();
        S.archDefs = defs;
        if (S.settings.view === 'arch') {
          if (changed) rebuildAll(); else { computeThreads(); if (!S.animating) drawThreads(); }
          return Promise.all(visibleDefs().map(function (d) { return refreshDef(d); }));
        }
      });
    }
    function setView(v) {
      if (S.settings.view === v) return Promise.resolve();
      if (S.focusId) setFocus(null);   // фокус и окно подробностей относятся к схеме
      S.settings.view = v;
      return saveSettings({ view: v }).then(function () {
        buildTopbar();
        return (v === 'arch' ? syncArchitecture().catch(function () {}) : Promise.resolve()).then(function () { rebuildAll(); return refreshAll(); });
      });
    }

    // ---------- виджеты: узлы и раскладка ----------
    function currentDefs() { return S.settings.view === 'arch' ? S.archDefs : S.defs; }
    function visibleDefs() { return currentDefs().filter(function (d) { return S.settings.hidden.indexOf(d.id) < 0; }); }
    function renderInto(def, data) {
      var node = S.nodes[def.id];
      if (!node) return;
      clear(node.body);
      node.body.className = 'wb';
      try { def.render(node.body, data, { def: def }); } catch (e) { node.body.className = 'wb err'; text(node.body, String(e && e.message || e)); }
    }
    function refreshDef(def) {
      if (def.busy || !S.nodes[def.id]) return Promise.resolve();
      def.busy = true;
      return def.load().then(function (data) {
        var key = JSON.stringify(data) + '|' + S.settings.language + '|' + S.settings.theme + '|' + (S.settings.pro ? 'pro' : '') + '|' + S.logSearch, node = S.nodes[def.id];
        if (def.key === key && def.keyNode === node) return;   // данные те же: окно не перестраивается (нет мерцания, сбросов наведения и прокрутки)
        def.key = key; def.keyNode = node;
        renderInto(def, data);
      }).catch(function (e) {
        var node = S.nodes[def.id];
        if (node && e.message !== '401') { clear(node.body); node.body.className = 'wb err'; text(node.body, t('error') + ': ' + e.message); }
      }).then(function () { def.busy = false; });
    }
    function refreshAll() {
      return syncModules().catch(function () {}).then(function () {
        return S.settings.view === 'arch' ? syncArchitecture().catch(function () {}) : Promise.all(visibleDefs().map(function (d) { return refreshDef(d); }));
      }).then(function () { setStatus(t('updated') + ' ' + fmtTime(Date.now() / 1000), false); });
    }
    function createNode(def) {
      var body = h(doc, 'div', { class: 'wb' });
      var close = h(doc, 'button', { class: 'wx', title: t('hide'), text: '✕', on: { click: function () {
        S.settings.hidden = S.settings.hidden.concat([def.id]);
        saveSettings({ hidden: S.settings.hidden }).then(function () { rebuildAll(); }); } } });
      var head = h(doc, 'header', { class: 'wh' }, [h(doc, 'span', { class: 'wt', text: title(def) }), close]);
      var handle = h(doc, 'div', { class: 'rh' });
      var el = h(doc, 'section', { class: 'widget', id: 'w-' + def.id }, [head, body, handle]);
      head.addEventListener('pointerdown', function (ev) { if (ev.target !== close && !(ev.target.classList && ev.target.classList.contains('wg'))) startDrag(ev, def.id, 'move'); });
      handle.addEventListener('pointerdown', function (ev) { startDrag(ev, def.id, 'resize'); });
      board.appendChild(el);
      S.nodes[def.id] = { el: el, body: body, head: head };
    }
    function rebuildAll() {
      var vis = visibleDefs(), ids = vis.map(function (d) { return d.id; });
      Object.keys(S.nodes).forEach(function (id) {
        if (ids.indexOf(id) < 0) { board.removeChild(S.nodes[id].el); delete S.nodes[id]; }
      });
      vis.forEach(function (d) {
        if (!S.nodes[d.id]) createNode(d);
        else S.nodes[d.id].head.firstChild.textContent = title(d);
      });
      relayout();
      vis.forEach(function (d) { d.next = 0; });
    }
    function gapOf() { return typeof S.settings.gap === 'number' ? S.settings.gap : DEFAULT_GAP; }
    function gapNow() { return Math.max(4, Math.round(gapOf() * (S.rowH / ROW_H))); }   // отступ сжимается вместе с рядами
    /* Раскладка подгоняется под высоту экрана: ряды сжимаются, чтобы всё было видно без прокрутки (на HP 1366×768 и т. п.). Нижний предел MIN_ROW_H; ниже него появляется обычная прокрутка. */
    function computeRowH() {
      if (S.stacked) return ROW_H;
      var vh = env.window && env.window.innerHeight;
      if (!vh) return ROW_H;
      S.topH = topbar.offsetHeight || 40;   // запоминается: если панель сверху вырастет (узкий экран, строка состояния), раскладка пересчитается
      var rows = Math.max(L.boardRows(S.layout) + 1, 12), avail = vh - S.topH - 24;
      return Math.max(MIN_ROW_H, Math.min(ROW_H, Math.floor(avail / rows)));
    }
    function clock() { return env.now ? env.now() : Date.now(); }
    var staticCanvas = h(doc, 'canvas', { class: 'threads', id: 'threads-static' });   // нижний слой: линии и подписи, перерисовывается только при изменении схемы
    var threadCanvas = h(doc, 'canvas', { class: 'threads', id: 'threads' });   // верхний слой: бегущие точки, кометы, подсветка; каждый кадр (60 в секунду)
    board.appendChild(staticCanvas);   // первые дети доски: лежат под виджетами
    board.appendChild(threadCanvas);
    /* Размер холстов: CSS-размер доски, а число пикселей умножается на плотность экрана (резкие линии на ретине), пока компьютер справляется. */
    function sizeCanvases(w, hgt) {
      w = Math.round(w);
      if (S.cssW === w && S.cssH === hgt && S.dprApplied === S.dpr) return;
      S.cssW = w; S.cssH = hgt; S.dprApplied = S.dpr; S.staticDirty = true;
      [staticCanvas, threadCanvas].forEach(function (c) {   // (половинное разрешение верхнего слоя проверено опытом: растягивание дороже передачи, кадров меньше)
        var pw = Math.round(w * S.dpr), ph = Math.round(hgt * S.dpr);
        if (c.width !== pw) c.width = pw;
        if (c.height !== ph) c.height = ph;
        if (c.style) { c.style.width = w + 'px'; c.style.height = hgt + 'px'; }
      });
    }

    /* Прямоугольник окна в пикселях; у двигаемого окна учтён его плавный сдвиг (оно идёт за курсором ровно, а в клетку встаёт при отпускании). */
    function pxOf(id) {
      var px = L.rectToPx(S.layout[id], S.cellW, S.rowH, gapNow()), dp = S.dragPx;
      if (dp && dp.id === id) return { left: dp.base.left + dp.dx, top: dp.base.top + dp.dy, width: dp.base.width, height: dp.base.height };
      return px;
    }
    function computeThreads() {
      S.threads = [];
      if (!S.dragId) S.staticDirty = true;   // во время перетаскивания нижний слой не трогаем: двигаемые нити рисует верхний
      if (S.stacked) return;
      var pairs = S.settings.view === 'arch' && S.arch ? S.arch.edges.map(function (e) { return { a: 'a:' + e.a, b: 'a:' + e.b, kind: e.kind, label: e.label, off: !!e.off }; })
                                                       : L.threadPairs(Object.keys(S.nodes));
      pairs.forEach(function (pr) {
        if (!S.nodes[pr.a] || !S.nodes[pr.b] || !S.layout[pr.a] || !S.layout[pr.b]) return;
        S.threads.push({ a: pr.a, b: pr.b, kind: pr.kind, label: pr.label || '', off: !!pr.off,
          p: L.threadCurve(pxOf(pr.a), pxOf(pr.b)) });
      });
    }
    function bez(ctx, p) { ctx.beginPath(); ctx.moveTo(p[0][0], p[0][1]); ctx.bezierCurveTo(p[1][0], p[1][1], p[2][0], p[2][1], p[3][0], p[3][1]); }
    function dotAt(ctx, pt, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(pt[0], pt[1], r, 0, Math.PI * 2); ctx.fill(); }
    /* Нити светятся, по ним бегут импульсы; нити перетаскиваемого виджета ярче; от клика по виджету бежит яркая волна. */
    /* Одна нить: свечение и линия. hot: яркая (нить двигаемого окна), пунктир для «желательной» связи. */
    function threadAlpha(th) {
      var a = th.off ? 0.22 : 1;   // связь выключенного модуля тусклая и без импульсов
      if (S.focusId && th.a !== S.focusId && th.b !== S.focusId) a *= 0.15;   // фокус: чужие нити почти гаснут
      return a;
    }
    function strokeThread(ctx, th, col, hot) {
      var rgb = KIND_RGB[th.kind], q = S.trafficQ[pairKey(th.a, th.b)] || 0;   // толщина по трафику за минуту: 0..4
      ctx.globalAlpha = threadAlpha(th);
      if (th.kind === 'opt') ctx.setLineDash([7, 6]);
      bez(ctx, th.p); ctx.strokeStyle = hot ? col.hotGlow : (rgb ? 'rgba(' + rgb + ',' + (0.12 + q * 0.04) + ')' : col.glow); ctx.lineWidth = hot ? 9 : 6 + q * 2.5; ctx.stroke();
      bez(ctx, th.p); ctx.strokeStyle = hot ? col.hot : (rgb ? 'rgba(' + rgb + ',' + (0.62 + q * 0.08) + ')' : (th.kind === 'module' ? col.module : col.line)); ctx.lineWidth = hot ? 2.2 : 1.4 + q * 0.6; ctx.stroke();
      if (th.kind === 'opt') ctx.setLineDash([]);
      if (!hot && !th.off && S.settings.view === 'arch') {   // стрелка направления посередине нити
        var p1 = L.bezierPoint(th.p, 0.53), p2 = L.bezierPoint(th.p, 0.58), dx = p2[0] - p1[0], dy = p2[1] - p1[1], len = Math.sqrt(dx * dx + dy * dy) || 1;
        dx /= len; dy /= len;
        ctx.beginPath(); ctx.moveTo(p2[0] - dx * 6 - dy * 4, p2[1] - dy * 6 + dx * 4); ctx.lineTo(p2[0], p2[1]); ctx.lineTo(p2[0] - dx * 6 + dy * 4, p2[1] - dy * 6 - dx * 4);
        ctx.strokeStyle = rgb ? 'rgba(' + rgb + ',0.85)' : col.label; ctx.lineWidth = 1.4; ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    /* Нижний слой: линии и подписи всех нитей, кроме нитей двигаемого окна (их рисует верхний слой). Перерисовывается только при изменении схемы, раскладки, темы,
       размера и в начале и конце перетаскивания, поэтому в обычном кадре его работа нулевая. */
    function renderStatic(col) {
      var sc = staticCanvas.getContext('2d');
      sc.setTransform(S.dpr, 0, 0, S.dpr, 0, 0);
      sc.clearRect(0, 0, S.cssW || staticCanvas.width, S.cssH || staticCanvas.height);
      sc.lineCap = 'round';
      S.staticDragId = S.dragId;
      S.threads.forEach(function (th) {
        if (S.dragId && (th.a === S.dragId || th.b === S.dragId)) return;
        strokeThread(sc, th, col, false);
        if (th.label && th.kind !== 'manage') {   // подписи у «управляет» только засоряли бы схему
          var mid = L.bezierPoint(th.p, 0.5), m = sc.measureText ? sc.measureText(th.label) : null, lw = (m && m.width) || th.label.length * 6;
          sc.globalAlpha = threadAlpha(th);
          sc.font = '10px "ZC Mono", monospace'; sc.fillStyle = col.labelBg; sc.fillRect(mid[0] - lw / 2 - 3, mid[1] - 8, lw + 6, 14);
          sc.fillStyle = col.label; sc.fillText(th.label, mid[0] - lw / 2, mid[1] + 3);
          sc.globalAlpha = 1;
        }
      });
    }
    /* Бегущая точка с хвостом: плавно появляется в начале нити и гаснет в конце. */
    function pulse(ctx, th, ph, r, color, alpha) {
      var fade = Math.min(1, Math.min(ph, 1 - ph) * 7);
      for (var k = 0; k < 3; k++) {
        var tt = ph - k * 0.022;
        if (tt < 0) break;
        ctx.globalAlpha = alpha * fade * (1 - k * 0.38);
        dotAt(ctx, L.bezierPoint(th.p, tt), r * (1 - k * 0.22), color);
      }
      ctx.globalAlpha = 1;
    }
    /* Верхний слой, каждый кадр: нити двигаемого окна, подсветка нитей под мышью, фоновые точки, волна от клика и яркие кометы настоящих событий. */
    function drawThreads() {
      var ctx = threadCanvas.getContext('2d'), now = clock();
      ctx.setTransform(S.dpr, 0, 0, S.dpr, 0, 0);
      ctx.clearRect(0, 0, S.cssW || threadCanvas.width, S.cssH || threadCanvas.height);
      if (S.stacked) return;
      var col = THREAD_COLORS[S.settings.theme] || THREAD_COLORS.dark;
      if (S.staticDirty || S.dragId !== S.staticDragId) { renderStatic(col); S.staticDirty = false; }
      ctx.lineCap = 'round';
      S.threads.forEach(function (th, i) {
        var hot = S.dragId && (th.a === S.dragId || th.b === S.dragId);
        if (hot) strokeThread(ctx, th, col, true);
        else if (S.hoverId && (th.a === S.hoverId || th.b === S.hoverId) && !th.off) {   // нити узла под мышью светлеют
          ctx.globalAlpha = 0.75; bez(ctx, th.p); ctx.strokeStyle = col.hot; ctx.lineWidth = 1.8; ctx.stroke(); ctx.globalAlpha = 1;
        }
        if (!th.off && !(S.focusId && th.a !== S.focusId && th.b !== S.focusId)) {
          var base = (now / 1000) * 0.16 + i * 0.31, alpha = S.settings.view === 'arch' ? 0.45 : 0.85;   // в архитектуре фоновые импульсы тихие: яркие только по настоящим событиям
          pulse(ctx, th, base % 1, hot ? 3.6 : 2.6, col.pulse, alpha);
          pulse(ctx, th, (base + 0.5) % 1, hot ? 3.6 : 2.6, col.pulse, alpha);
        }
        if (S.shock && (th.a === S.shock.id || th.b === S.shock.id)) {
          var age = (now - S.shock.t0) / 900;
          if (age < 1) { var tt = th.a === S.shock.id ? age : 1 - age, pt = L.bezierPoint(th.p, tt); dotAt(ctx, pt, 9, col.glow); dotAt(ctx, pt, 4.5, col.pulse); }
        }
      });
      if (S.shock && now - S.shock.t0 >= 900) S.shock = null;
      // настоящие события: яркая «комета» бежит по нити в направлении события (красная для ошибок)
      S.bursts = S.bursts.filter(function (bu) { return now - bu.t0 < 1000; });
      S.bursts.forEach(function (bu) {
        var th = S.threads.filter(function (x) { return x.a === bu.a && x.b === bu.b; })[0];
        if (!th) return;
        var age = (now - bu.t0) / 1000, color = bu.level === 'error' ? col.err : col.pulse;
        for (var k = 3; k >= 0; k--) {
          var tt = age - k * 0.05;
          if (tt < 0) continue;
          var pt = L.bezierPoint(th.p, bu.forward ? tt : 1 - tt);
          if (k === 0) dotAt(ctx, pt, 11, bu.level === 'error' ? 'rgba(255,107,107,0.22)' : col.glow);
          dotAt(ctx, pt, k === 0 ? 4.6 : 3.6 - k * 0.7, color);
        }
      });
    }
    function flashNode(id) {
      var n = S.nodes[id];
      if (!n) return;
      n.el.classList.add('flash');
      if (env.setTimeout) env.setTimeout(function () { n.el.classList.remove('flash'); }, 700);
    }
    /* Событие активности -> импульс по нити между его узлами (если такой нити сейчас нет, например узел скрыт, событие пропускается). */
    function addBurst(ev) {
      var a = 'a:' + ev.a, b = 'a:' + ev.b;
      var th = S.threads.filter(function (x) { return (x.a === a && x.b === b) || (x.a === b && x.b === a); })[0];
      if (!th) return false;
      S.bursts.push({ a: th.a, b: th.b, forward: th.a === a, t0: clock(), level: ev.level });
      if (S.bursts.length > 40) S.bursts.shift();
      flashNode(a); flashNode(b);
      return true;
    }
    function pollActivity() {
      var seeding = !S.activitySince;   // самый первый опрос заполняет историю: старые события из журнала идут в неё без комет
      return api('/api/activity' + (S.activitySince ? '?since=' + S.activitySince : '')).then(function (r) {
        S.activitySince = r.now;
        r.events.forEach(function (ev) {
          recordEvent(ev);
          if (S.settings.view === 'arch' && !(seeding && ev.t < r.now - 10)) addBurst(ev);
        });
        updateLive(r.now);
        if (!S.animating) drawThreads();
        return r.events.length;
      });
    }
    /* ---------- живая статистика: трафик нитей, «тепло» ошибок, история узлов (всё считается из потока событий в браузере) ---------- */
    var TRAFFIC_SEC = 60, HEAT_TAU = 120, HIST_MAX = 800, SPARK_BUCKETS = 20, SPARK_SEC = 30;
    function recordEvent(ev) {
      if (typeof ev.t !== 'number') ev.t = clock() / 1000;
      S.hist.push(ev);
      if (S.hist.length > HIST_MAX) S.hist.splice(0, S.hist.length - HIST_MAX);
    }
    function pairKey(a, b) { return a < b ? a + '|' + b : b + '|' + a; }
    function trafficLevel(n) { return !n ? 0 : n < 3 ? 1 : n < 10 ? 2 : n < 30 ? 3 : 4; }   // толщина нити по событиям за минуту
    function nodeEvents(id, since) {
      return S.hist.filter(function (ev) { return ('a:' + ev.a === id || 'a:' + ev.b === id) && (!since || ev.t >= since); });
    }
    function sparkCounts(id, now) {   // события узла по 30-секундным корзинам за 10 минут
      var c = []; for (var i = 0; i < SPARK_BUCKETS; i++) c.push(0);
      nodeEvents(id, now - SPARK_BUCKETS * SPARK_SEC).forEach(function (ev) {
        var k = SPARK_BUCKETS - 1 - Math.floor((now - ev.t) / SPARK_SEC);
        if (k >= 0 && k < SPARK_BUCKETS) c[k]++;
      });
      return c;
    }
    function drawSpark(canvas, counts, color) {
      var g = canvas.getContext('2d'), w = canvas.width, hh = canvas.height, mx = Math.max.apply(null, counts.concat([1]));
      g.clearRect(0, 0, w, hh);
      var bw = w / counts.length;
      counts.forEach(function (v, i) {
        if (!v) return;
        var bh = Math.max(2, Math.round((v / mx) * (hh - 1)));
        g.globalAlpha = i === counts.length - 1 ? 0.95 : 0.55;
        g.fillStyle = color; g.fillRect(Math.round(i * bw) + 0.5, hh - bh, Math.max(1, Math.floor(bw) - 1), bh);
      });
      g.globalAlpha = 1;
    }
    function updateLive(now) {
      now = now || clock() / 1000;
      S.liveNow = now;
      var traffic = {}, heat = {};
      S.hist.forEach(function (ev) {
        var a = 'a:' + ev.a, b = 'a:' + ev.b, age = now - ev.t;
        if (age <= TRAFFIC_SEC) traffic[pairKey(a, b)] = (traffic[pairKey(a, b)] || 0) + 1;
        if (ev.level === 'error' && age <= 600) { var w = Math.exp(-Math.max(0, age) / HEAT_TAU); heat[a] = (heat[a] || 0) + w; heat[b] = (heat[b] || 0) + w; }
      });
      var q = {};
      Object.keys(traffic).forEach(function (k) { q[k] = trafficLevel(traffic[k]); });
      if (JSON.stringify(q) !== JSON.stringify(S.trafficQ) && !(now - (S.trafficAt || 0) < 6)) { S.trafficQ = q; S.trafficAt = now; S.staticDirty = true; }   // нижний слой: только при смене ступени и не чаще раза в 6 секунд
      S.traffic = traffic;
      Object.keys(S.nodes).forEach(function (id) {   // «тепло» ошибок: узел краснеет и остывает примерно за 2 минуты
        var node = S.nodes[id], v = Math.round(Math.min(1, heat[id] || 0) * 4) / 4;   // крупные ступени: окно перерисовывается редко
        if (node.heat === v) return;
        node.heat = v;
        if (v > 0) { node.el.classList.add('heat'); if (node.el.style.setProperty) node.el.style.setProperty('--heat', String(v)); } else node.el.classList.remove('heat');
      });
      if (S.settings.view === 'arch' && !(now - (S.sparkAt || 0) < 5)) { S.sparkAt = now; Object.keys(S.nodes).forEach(function (id) {   // мини-график активности в заголовке узла (не чаще раза в 5 секунд)
        var node = S.nodes[id];
        if (!node.spark) return;
        var c = sparkCounts(id, now), key = c.join(',');
        if (node.sparkKey === key) return;
        node.sparkKey = key;
        var mx = Math.max.apply(null, c.concat([1]));
        node.spark.children.forEach ? node.spark.children.forEach(bar) : Array.prototype.forEach.call(node.spark.children, bar);
        function bar(el, i) { el.style.height = (c[i] ? Math.max(2, Math.round(c[i] / mx * 12)) : 0) + 'px'; el.className = i === c.length - 1 ? 'now' : ''; }
      }); }
      updateChips();
      if (S.focusId) renderInspector();
    }
    /* ---------- строка состояния в верхней панели: бот, события в минуту, ошибки ---------- */
    function updateChips() {
      if (!chips) return;
      var now = S.liveNow || clock() / 1000, kuni = (S.modules || []).filter(function (m) { return m.name === 'kuni'; })[0];
      var perMin = S.hist.filter(function (ev) { return now - ev.t <= 60; }).length, errs = S.hist.filter(function (ev) { return ev.level === 'error' && now - ev.t <= 600; }).length;
      var key = [kuni ? kuni.running + kuni.health : '-', perMin, errs, S.settings.language].join('|');
      if (chips.key === key) return;
      chips.key = key;
      if (!chips.parts) {   // создаётся один раз, дальше меняются только тексты и классы
        var bd = dot(''), bt = h(doc, 'span', {}), rate = h(doc, 'span', { class: 'chip', id: 'chip-rate', title: t('chip_rate_title') }), err = h(doc, 'span', { class: 'chip', id: 'chip-err', title: t('chip_err_title') });
        chips.appendChild(h(doc, 'span', { class: 'chip', id: 'chip-bot', title: t('chip_bot_title') }, [bd, bt]));
        chips.appendChild(rate); chips.appendChild(err);
        chips.parts = { bd: bd, bt: bt, rate: rate, err: err };
      }
      var P = chips.parts;
      P.bd.className = 'dot ' + (!kuni ? '' : kuni.running ? (kuni.health === 'healthy' ? 'ok' : 'warn') : 'bad');
      P.bt.textContent = !kuni ? t('chip_no_bot') : kuni.running ? t('chip_bot_on') : t('chip_bot_off');
      P.rate.textContent = perMin + ' ' + t('chip_per_min');
      P.err.textContent = errs + ' ' + t('chip_errors');
      P.err.className = 'chip' + (errs ? ' bad' : '');
      if (S.topH && topbar.offsetHeight && topbar.offsetHeight !== S.topH) applyLayout();   // верхняя панель поменяла высоту (строка состояния переносится): ряды пересчитываются
    }
    /* ---------- фокус по клику: узел, его соседи и окно подробностей; остальное тускнеет ---------- */
    function neighborsOf(id) {
      var set = {}; set[id] = true;
      S.threads.forEach(function (th) { if (th.a === id) set[th.b] = true; if (th.b === id) set[th.a] = true; });
      return set;
    }
    function setFocus(id) {
      S.focusId = id && S.nodes[id] ? id : null;
      var near = S.focusId ? neighborsOf(S.focusId) : null;
      Object.keys(S.nodes).forEach(function (nid) {
        var el = S.nodes[nid].el;
        el.classList.remove('focus'); el.classList.remove('faded');
        if (!near) return;
        if (nid === S.focusId) el.classList.add('focus'); else if (!near[nid]) el.classList.add('faded');
      });
      S.staticDirty = true;
      if (!S.animating) drawThreads();
      renderInspector();
    }
    var inspector = null;
    function renderInspector() {
      if (!S.focusId) { if (inspector && inspector.parentNode) inspector.parentNode.removeChild(inspector); inspector = null; return; }   // parentNode: так в браузере
      var id = S.focusId, n = S.archById[id.slice(2)] || {}, now = S.liveNow || clock() / 1000;
      var evs = nodeEvents(id).slice(-20).reverse(), lastMin = nodeEvents(id, now - 60), errs = nodeEvents(id, now - 600).filter(function (e) { return e.level === 'error'; }).length;
      var inbound = lastMin.filter(function (e) { return 'a:' + e.b === id; }).length;
      if (!inspector) { inspector = h(doc, 'aside', { id: 'inspector' }); doc.body.appendChild(inspector); }
      while (inspector.firstChild) inspector.removeChild(inspector.firstChild);
      var spark = h(doc, 'canvas', { class: 'ispark', width: 288, height: 40 });
      inspector.appendChild(h(doc, 'div', { class: 'ih' }, [h(doc, 'span', { class: 'grow', text: n.title || id }),
        h(doc, 'button', { class: 'wx', id: 'insp-close', title: t('close'), text: '✕', on: { click: function () { setFocus(null); } } })]));
      inspector.appendChild(h(doc, 'div', { class: 'dim', id: 'insp-stats', text: t('insp_min') + ': ' + lastMin.length + ' (' + t('insp_in') + ' ' + inbound + ', ' + t('insp_out') + ' ' + (lastMin.length - inbound) + ') · ' + t('insp_errs') + ': ' + errs }));
      inspector.appendChild(spark);
      drawSpark(spark, sparkCounts(id, now), errs ? '#ff6b6b' : '#6ea8ff');
      inspector.appendChild(h(doc, 'div', { class: 'section', text: t('insp_recent') }));
      var list = h(doc, 'div', { class: 'ilist', id: 'insp-list' });
      if (!evs.length) list.appendChild(h(doc, 'div', { class: 'dim', text: t('insp_none') }));
      evs.forEach(function (e) {
        var out = 'a:' + e.a === id, other = S.archById[out ? e.b : e.a], d = new Date(e.t * 1000);
        list.appendChild(h(doc, 'div', { class: 'iev' + (e.level === 'error' ? ' err' : ''), title: e.text }, [
          h(doc, 'span', { class: 'dim', text: pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds()) }),
          h(doc, 'span', { class: 'ik k-' + e.kind, text: e.kind }),
          h(doc, 'span', { text: (out ? '→ ' : '← ') + ((other && other.title) || (out ? e.b : e.a)) }),
          h(doc, 'span', { class: 'dim nl', text: e.text || '' })]));
      });
      inspector.appendChild(list);
    }
    /* Уровни плавности: 0 = 60 кадров/с и плотность экрана; 1 = 60 кадров/с без неё; 2 = 30; 3 = 15; 4 = 8. Слабый компьютер переходит вниз, когда браузер несколько
       раз подряд не успевает вызывать кадры (интервал растёт), и поднимается обратно после нескольких секунд стабильной работы; если подъём сразу сменился спадом,
       ждать приходится дольше (до 24 секунд), чтобы частота не дёргалась. Первые секунды после запуска не считаются: страница ещё грузится. */
    var GAPS = [0, 0, 33, 66, 125];
    function setLevel(n) {
      if (S.fx === 'full') n = 0; else if (S.fx === 'fast') n = 1;   // для диагностики: localStorage zc_fx = full | fast фиксирует режим и отключает адаптацию
      S.level = n; S.frameGap = GAPS[n];
      var dpr = n === 0 ? Math.min(2, (env.window && env.window.devicePixelRatio) || 1) : 1;
      if (dpr !== S.dpr) { S.dpr = dpr; if (S.cssW) sizeCanvases(S.cssW, S.cssH); }
    }
    function adaptFrameRate(now) {
      if (S.fx) return;
      var dt = S.frameAt ? now - S.frameAt : 0;
      S.frameAt = now;
      if (!S.warmUntil) S.warmUntil = now + 2500;
      if (now < S.warmUntil || dt <= 0 || dt > 300) return;   // прогрев; долгие паузы (вкладка спала) не считаются
      S.frameAvg = S.frameAvg ? S.frameAvg * 0.9 + dt * 0.1 : dt;
      if (S.frameAvg > 24 && S.level < 4) {
        S.goodSince = 0;
        if (!S.badSince) S.badSince = now;
        else if (now - S.badSince > 600) {
          if (S.promotedAt && now - S.promotedAt < 6000) S.goodNeeded = Math.min(24000, S.goodNeeded * 2);   // подъём сразу сорвался: ждать дольше
          setLevel(S.level + 1); S.badSince = 0; S.frameAvg = 16.7;
        }
      } else {
        S.badSince = 0;
        if (S.level > 0 && S.frameAvg < 19) {
          if (!S.goodSince) S.goodSince = now;
          else if (now - S.goodSince > S.goodNeeded) { setLevel(S.level - 1); S.goodSince = 0; S.promotedAt = now; }
        } else S.goodSince = 0;
      }
    }
    function animate() {
      var now = clock();
      adaptFrameRate(now);
      if (!doc.hidden && !S.stacked && (S.frameGap === 0 || now - S.lastDraw >= S.frameGap - 2)) { S.lastDraw = now; drawThreads(); }
      env.requestAnimationFrame(animate);
    }
    function startAnimation() {
      if (S.animating) return;
      if (env.requestAnimationFrame && !S.reduced) { S.animating = true; setLevel(0); env.requestAnimationFrame(animate); }
    }
    /* Эффект клика: расходящееся кольцо у курсора и волна по нитям от виджета, по которому нажали. */
    function nearestWidgetId(el) {
      while (el) { if (el.id && String(el.id).indexOf('w-') === 0) return String(el.id).slice(2); el = el.parentNode || el.parent; }
      return null;
    }
    board.addEventListener('pointerover', function (ev) {
      var id = nearestWidgetId(ev.target);
      if (id !== S.hoverId) { S.hoverId = id; if (!S.animating) drawThreads(); }
    });
    board.addEventListener('click', function (ev) {
      if (S.settings.view !== 'arch' || S.justDragged) { S.justDragged = false; return; }
      for (var n = ev.target; n && n !== board; n = n.parent || n.parentNode) {
        if (n.tag === 'button' || n.tagName === 'BUTTON' || n.tag === 'select' || n.tagName === 'SELECT' || n.tag === 'input' || n.tagName === 'INPUT') return;
      }
      var id = nearestWidgetId(ev.target);
      setFocus(id && id !== S.focusId ? id : null);
    });
    doc.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && S.focusId) setFocus(null); });
    board.addEventListener('pointerleave', function () { if (S.hoverId) { S.hoverId = null; if (!S.animating) drawThreads(); } });
    doc.addEventListener('pointerdown', function (ev) {
      var fx = h(doc, 'div', { class: 'clickfx', style: { left: ev.clientX + 'px', top: ev.clientY + 'px' } });
      doc.body.appendChild(fx);
      if (env.setTimeout) env.setTimeout(function () { var par = fx.parentNode || fx.parent; if (par) par.removeChild(fx); }, 700);
      var wid = nearestWidgetId(ev.target);
      if (wid) S.shock = { id: wid, t0: clock() };
      if (!S.animating) drawThreads();
    });

    function relayout() {
      S.layout = L.mergeLayout(S.settings.layout, visibleDefs().map(function (d) { return { id: d.id, w: d.w, h: d.h, x: d.x, y: d.y }; }), L.COLS);
      applyLayout();
    }
    function applyLayout() {
      var rect = board.getBoundingClientRect(), width = rect.width || 1200;
      S.stacked = width < 720;
      S.rowH = computeRowH();
      S.cellW = width / L.COLS;
      var tight = S.rowH < SNUG_FROM || S.cellW < FULL_CELL;   // тесно: компактный вид; места хватает: полный, как на видео
      var cls = S.stacked ? 'stack' : [tight ? 'compact' : (S.rowH < ROW_H ? 'snug' : ''), S.settings.view === 'arch' ? 'arch' : ''].filter(Boolean).join(' ');
      if (S.boardClass !== cls || board.className !== cls) { board.className = cls; S.boardClass = cls; }   // запись класса пересчитывает стили, поэтому только при изменении
      if (board.style.setProperty && (S.lastCell !== S.cellW || S.lastRow !== S.rowH)) { board.style.setProperty('--cell', S.cellW + 'px'); board.style.setProperty('--row', S.rowH + 'px'); S.lastCell = S.cellW; S.lastRow = S.rowH; }
      var ids = Object.keys(S.nodes);
      if (S.stacked) {
        ids.sort(function (a, b) { return (S.layout[a].y - S.layout[b].y) || (S.layout[a].x - S.layout[b].x); });
        ids.forEach(function (id) { var st = S.nodes[id].el.style; st.left = ''; st.top = ''; st.width = ''; st.height = ''; S.nodes[id].key = ''; board.appendChild(S.nodes[id].el); });
        board.style.height = ''; S.boardH = 0;
        computeThreads();
        if (!S.animating) drawThreads();
        return;
      }
      ids.forEach(function (id) {   // стили пишутся только тем окнам, чьи размеры изменились: при перетаскивании это одно окно, а не все
        if (S.dragPx && S.dragPx.id === id) return;   // двигаемое окно ведёт transform, его left/top не трогаем до отпускания
        var px = L.rectToPx(S.layout[id], S.cellW, S.rowH, gapNow()), node = S.nodes[id], key = px.left + '|' + px.top + '|' + px.width + '|' + px.height;
        if (node.key === key) return;
        node.key = key;
        var st = node.el.style;
        st.left = px.left + 'px'; st.top = px.top + 'px'; st.width = px.width + 'px'; st.height = px.height + 'px';
      });
      var boardH = Math.max(L.boardRows(S.layout) + 2, 20) * S.rowH;
      if (S.boardH !== boardH) { board.style.height = boardH + 'px'; S.boardH = boardH; }
      sizeCanvases(width, boardH);
      computeThreads();
      if (!S.animating) drawThreads();
    }
    /* Перетаскивание. Перенос окна плавный: оно идёт за курсором через transform (композитор, без перерисовки содержимого), нити тянутся за ним по пикселям,
       а в клетку сетки окно встаёт при отпускании и мягко «прилипает». Изменение размера идёт по клеткам. Движения мыши собираются в одно обновление на кадр. */
    function startDrag(ev, id, mode) {
      if (S.stacked) return;
      if (ev.preventDefault) ev.preventDefault();
      var start = { x: ev.clientX, y: ev.clientY, rect: L.copy(S.layout)[id] }, el = S.nodes[id].el, pending = null, queued = false;
      var smooth = mode === 'move' && !!env.requestAnimationFrame, base = L.rectToPx(start.rect, S.cellW, S.rowH, gapNow()), last = { dx: 0, dy: 0 }, moved = false;
      S.justDragged = false;
      el.classList.add('dragging');
      S.dragId = id;
      if (smooth) { el.style.transition = 'none'; S.dragPx = { id: id, dx: 0, dy: 0, base: base }; }
      function apply() {   // одно обновление на кадр, как бы часто ни приходили движения мыши (на экранах с высокой частотой их больше 60 в секунду)
        queued = false;
        if (!pending) return;
        var e = pending, dx = e.clientX - start.x, dy = e.clientY - start.y;
        pending = null;
        if (Math.abs(dx) + Math.abs(dy) > 3) moved = true;
        var d = L.pxToCells(dx, dy, S.cellW, S.rowH);
        S.layout[id] = L.clampRect(mode === 'move'
          ? { x: start.rect.x + d.dx, y: start.rect.y + d.dy, w: start.rect.w, h: start.rect.h }
          : { x: start.rect.x, y: start.rect.y, w: start.rect.w + d.dx, h: start.rect.h + d.dy }, L.COLS);   // клетка, в которую окно встанет
        if (smooth) {
          last = { dx: dx, dy: dy };
          S.dragPx.dx = dx; S.dragPx.dy = dy;
          el.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
          computeThreads();
          if (!S.animating) drawThreads();
        } else applyLayout();
      }
      function move(e) {
        pending = { clientX: e.clientX, clientY: e.clientY };
        if (!env.requestAnimationFrame) return apply();
        if (!queued) { queued = true; env.requestAnimationFrame(apply); }
      }
      function up() {
        doc.removeEventListener('pointermove', move);
        doc.removeEventListener('pointerup', up);
        apply();   // последнее положение применяется сразу
        S.justDragged = moved;   // после настоящего переноса щелчок не включает фокус
        el.classList.remove('dragging');
        S.dragId = null;
        S.dragPx = null;
        S.staticDirty = true;
        S.layout = L.resolveCollisions(S.layout, id);
        S.settings.layout = Object.assign({}, S.settings.layout, L.copy(S.layout));   // раскладка другого вида сохраняется
        applyLayout();   // окно получает свои left/top уже в клетке
        if (smooth) {   // визуально окно остаётся там, где отпустили, и за ~0,14 с «прилипает» к клетке
          var fin = L.rectToPx(S.layout[id], S.cellW, S.rowH, gapNow());
          el.style.transform = 'translate(' + (base.left + last.dx - fin.left) + 'px,' + (base.top + last.dy - fin.top) + 'px)';
          env.requestAnimationFrame(function () { el.style.transition = 'transform .14s ease-out'; el.style.transform = ''; });
          if (env.setTimeout) env.setTimeout(function () { el.style.transition = ''; }, 220);
        }
        saveSettings({ layout: S.settings.layout });
      }
      doc.addEventListener('pointermove', move);
      doc.addEventListener('pointerup', up);
    }

    // ---------- запуск ----------
    function tick() {
      if (doc.hidden || overlay.hidden === false) return;
      var now = Date.now();
      if (S.settings.view === 'arch' && now >= S.archNext) { S.archNext = now + 5000; syncArchitecture().catch(function () {}); }
      if (now >= S.activityNext) { S.activityNext = now + 2000; pollActivity().catch(function () {}); }   // и в «Панели»: строка состояния сверху
      visibleDefs().forEach(function (d) {
        if (!d.busy && now >= d.next) { d.next = now + d.refresh * 1000; refreshDef(d); }
      });
    }
    var ticking = false;
    function start() {
      if (!S.token) return showLogin();
      return api('/api/settings').then(function (s) {
        S.settings = s;
        applyTheme();
        buildTopbar();
        S.defs = builtinDefs();
        return syncModules().catch(function () {}).then(function () { return S.settings.view === 'arch' ? syncArchitecture().catch(function () {}) : null; });
      }).then(function () {
        rebuildAll();
        startAnimation();
        if (!ticking) { ticking = true; env.setInterval(tick, 1000); if (env.window && env.window.addEventListener) env.window.addEventListener('resize', applyLayout); }
        return refreshAll();
      }).catch(function (e) { if (e.message !== '401') { buildTopbar(); setStatus(t('error') + ': ' + e.message, true); } });
    }
    var started = start();
    return { S: S, started: started, refreshAll: refreshAll, tick: tick, applyLayout: applyLayout, drawThreads: drawThreads, setView: setView, syncArchitecture: syncArchitecture, pollActivity: pollActivity, updateLive: updateLive, setFocus: setFocus, openPalette: openPalette, openChat: openChat, toggleChat: toggleChat };
  }

  return { boot: boot, h: h, I18N: I18N };
});
