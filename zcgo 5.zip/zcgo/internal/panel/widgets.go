package panel

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os/exec"
	"strings"
	"syscall"
	"time"
)

// Виджеты модулей: команда из манифеста печатает JSON, панель рисует результат.
// Контракт вывода (как у Python-панели): kv, table, text, counter. Вывод до 64 КБ, таймаут 5 с.

const (
	maxWidgetOutput = 65536
	widgetTimeout   = 5 * time.Second
)

var errNotFound = errors.New("виджет не найден")

func shapeProblem(kind string, data any) string {
	obj, ok := data.(map[string]any)
	if !ok {
		return "ответ должен быть объектом JSON"
	}
	switch kind {
	case "kv":
		items, ok := obj["items"].([]any)
		if !ok {
			return `ожидается {"items": [["ключ", "значение"], ...]}`
		}
		for _, it := range items {
			pair, ok := it.([]any)
			if !ok || len(pair) != 2 {
				return `ожидается {"items": [["ключ", "значение"], ...]}`
			}
		}
	case "table":
		cols, ok1 := obj["columns"].([]any)
		rows, ok2 := obj["rows"].([]any)
		if !ok1 || !ok2 {
			return `ожидается {"columns": [...], "rows": [[...], ...]} с равной длиной строк`
		}
		for _, r := range rows {
			row, ok := r.([]any)
			if !ok || len(row) != len(cols) {
				return `ожидается {"columns": [...], "rows": [[...], ...]} с равной длиной строк`
			}
		}
	case "text":
		if _, ok := obj["text"].(string); !ok {
			return `ожидается {"text": "..."}`
		}
	case "counter":
		if _, ok := obj["value"].(float64); !ok {
			return `ожидается {"value": число, "label": "..."}`
		}
	}
	return ""
}

// runWidget выполняет команду виджета. Ошибки самого виджета возвращаются полем ok=false, а не HTTP-ошибкой.
func (s *Server) runWidget(module, id, actionID string) (map[string]any, error) {
	enabled := false
	for _, n := range s.M.EnabledNames() {
		if n == module {
			enabled = true
		}
	}
	if !enabled {
		return nil, fmt.Errorf("модуль %s не включён", module)
	}
	mf, err := s.M.Manifest(module, "")
	if err != nil {
		return nil, err
	}
	var w map[string]any
	for _, cand := range mf.Widgets {
		if cand["id"] == id {
			w = cand
		}
	}
	if w == nil {
		return nil, fmt.Errorf("у модуля %s нет виджета %s", module, id)
	}
	kind, _ := w["kind"].(string)
	title, _ := w["title"].(string)
	cmd := stringList(w["command"])
	mdir, err := s.M.ModuleDirOf(module)
	if err != nil {
		return nil, err
	}
	env := s.M.ModuleEnv(module, mf, mdir)
	var note any
	if actionID != "" {
		var act map[string]any
		if as, ok := w["actions"].([]any); ok {
			for _, a := range as {
				if am, ok := a.(map[string]any); ok && am["id"] == actionID {
					act = am
				}
			}
		}
		if act == nil {
			return nil, fmt.Errorf("у виджета нет действия %s", actionID)
		}
		aout, aerr := runCommand(s.M.ExpandCommand(module, mdir, stringList(act["command"])), mdir, env, widgetTimeout)
		if aerr != nil {
			return map[string]any{"ok": false, "error": aerr.Error()}, nil
		}
		if n := strings.TrimSpace(string(aout)); n != "" {
			note = truncRunes(n, 300)
		}
	}
	argv := s.M.ExpandCommand(module, mdir, cmd)
	out, runErr := runCommand(argv, mdir, env, widgetTimeout)
	if runErr != nil {
		return map[string]any{"ok": false, "error": runErr.Error(), "note": note}, nil
	}
	var data any
	if err := json.Unmarshal(out, &data); err != nil {
		return map[string]any{"ok": false, "error": "команда вернула не JSON"}, nil
	}
	if p := shapeProblem(kind, data); p != "" {
		return map[string]any{"ok": false, "error": p}, nil
	}
	actions := []map[string]any{}
	if as, ok := w["actions"].([]any); ok {
		for _, a := range as {
			if am, ok := a.(map[string]any); ok {
				actions = append(actions, map[string]any{"id": am["id"], "label": am["label"]})
			}
		}
	}
	return map[string]any{"ok": true, "kind": kind, "title": title, "data": data, "note": note, "actions": actions}, nil
}

func stringList(v any) []string {
	raw, _ := v.([]any)
	out := make([]string, 0, len(raw))
	for _, c := range raw {
		if str, ok := c.(string); ok {
			out = append(out, str)
		}
	}
	return out
}

// runCommand запускает команду в своей группе процессов: по таймауту убивается вся группа.
func runCommand(argv []string, dir string, env []string, timeout time.Duration) ([]byte, error) {
	if len(argv) == 0 {
		return nil, errors.New("пустая команда")
	}
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	cmd.Dir = dir
	cmd.Env = env
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	cmd.Cancel = func() error { return syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL) }
	var stdout, stderr bytes.Buffer
	cmd.Stdout = &stdout
	cmd.Stderr = &stderr
	if err := cmd.Start(); err != nil {
		return nil, fmt.Errorf("не удалось запустить: %v", err)
	}
	err := cmd.Wait()
	if ctx.Err() == context.DeadlineExceeded {
		return nil, fmt.Errorf("таймаут %g с", timeout.Seconds())
	}
	if stdout.Len() > maxWidgetOutput {
		return nil, fmt.Errorf("вывод больше %d байт", maxWidgetOutput)
	}
	if err != nil {
		var ee *exec.ExitError
		if errors.As(err, &ee) {
			tail := bytes.TrimSpace(stderr.Bytes())
			if len(tail) == 0 {
				tail = bytes.TrimSpace(stdout.Bytes())
			}
			if len(tail) > 200 {
				tail = tail[len(tail)-200:]
			}
			return nil, fmt.Errorf("команда завершилась кодом %d: %s", ee.ExitCode(), tail)
		}
		return nil, err
	}
	return stdout.Bytes(), nil
}
