package panel

// Запуск на настоящей машине: поиск каталога бота, адреса для телефона, подключение каталога инструментов к конфигу бота,
// проверка среды (doctor). Команды tmux и Python-проверки из Python-версии заменены на Go-варианты.

import (
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"

	"zcgo/internal/kernel"
	"zcgo/internal/manager"
)

const (
	catalogKey   = "external_tools_catalog"
	kuniFallback = "/home/marinka/kuni"
)

// detectKuniDir — каталог бота: явный путь, переменная ZEROCORE_KUNI_DIR, ~/kuni, /home/marinka/kuni.
// Признак: config.toml или бинарник kuni. Явно указанный неверный путь не подменяется другим.
func detectKuniDir(explicit string) string {
	candidates := []string{explicit}
	if explicit == "" {
		home, _ := os.UserHomeDir()
		candidates = []string{os.Getenv("ZEROCORE_KUNI_DIR"), filepath.Join(home, "kuni"), kuniFallback}
	}
	for _, c := range candidates {
		if c == "" {
			continue
		}
		if st, err := os.Stat(c); err != nil || !st.IsDir() {
			continue
		}
		if fileExists(filepath.Join(c, "config.toml")) || fileExists(filepath.Join(c, "kuni")) {
			return c
		}
	}
	return ""
}

var ipv4RE = regexp.MustCompile(`^\d{1,3}(\.\d{1,3}){3}$`)

// lanIPs — адреса этого компьютера в локальной сети, самый вероятный первым.
func lanIPs() []string {
	var found []string
	add := func(ip string) {
		if ipv4RE.MatchString(ip) && !strings.HasPrefix(ip, "127.") && !strings.HasPrefix(ip, "169.254.") && !strings.HasPrefix(ip, "0.") {
			for _, f := range found {
				if f == ip {
					return
				}
			}
			found = append(found, ip)
		}
	}
	// адрес интерфейса, через который уходит трафик наружу (пакеты не отправляются)
	if c, err := net.Dial("udp4", "10.255.255.255:1"); err == nil {
		if a, ok := c.LocalAddr().(*net.UDPAddr); ok {
			add(a.IP.String())
		}
		c.Close()
	}
	if addrs, err := net.InterfaceAddrs(); err == nil {
		for _, a := range addrs {
			if ipn, ok := a.(*net.IPNet); ok && ipn.IP.To4() != nil {
				add(ipn.IP.String())
			}
		}
	}
	return found
}

func portFree(host string, port int) bool {
	l, err := net.Listen("tcp", net.JoinHostPort(host, strconv.Itoa(port)))
	if err != nil {
		return false
	}
	_ = l.Close()
	return true
}

func tomlString(v string) string {
	return `"` + strings.ReplaceAll(strings.ReplaceAll(v, `\`, `\\`), `"`, `\"`) + `"`
}

var (
	sectionRE = regexp.MustCompile(`^\s*\[([^\[\]]+)\]\s*(#.*)?$`)
)

// wireKuniCatalog добавляет или обновляет external_tools_catalog в секции [misc] конфига бота.
// Остальной текст не трогает; перед первым изменением кладёт копию config.toml.bak-zerocore.
// Возвращает added, updated или unchanged.
func wireKuniCatalog(configPath, catalogPath string) (string, error) {
	raw, err := os.ReadFile(configPath)
	if err != nil {
		return "", kernel.Newf(kernel.KindGeneric, "не найден конфиг бота: %s", configPath)
	}
	original := string(raw)
	newline := "\n"
	if strings.Contains(original, "\r\n") {
		newline = "\r\n"
	}
	lines := strings.Split(strings.ReplaceAll(original, "\r\n", "\n"), "\n")
	if strings.HasSuffix(original, "\n") && len(lines) > 0 && lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	wanted := catalogKey + " = " + tomlString(catalogPath)
	keyRE := regexp.MustCompile(`^(\s*)` + catalogKey + `\s*=`)
	inMisc, miscStart, miscEnd, keyLine := false, -1, len(lines), -1
	for i, line := range lines {
		if m := sectionRE.FindStringSubmatch(line); m != nil {
			if inMisc {
				miscEnd = i
				inMisc = false
			}
			if strings.TrimSpace(m[1]) == "misc" {
				inMisc, miscStart = true, i
			}
		} else if inMisc && keyRE.MatchString(line) {
			keyLine = i
		}
	}
	var status string
	switch {
	case keyLine >= 0:
		if strings.TrimSpace(lines[keyLine]) == wanted {
			return "unchanged", nil
		}
		indent := keyRE.FindStringSubmatch(lines[keyLine])[1]
		lines[keyLine] = indent + wanted
		status = "updated"
	case miscStart >= 0:
		at := miscEnd
		for at > miscStart+1 && strings.TrimSpace(lines[at-1]) == "" {
			at--
		}
		lines = append(lines[:at], append([]string{wanted}, lines[at:]...)...)
		status = "added"
	default:
		if len(lines) > 0 && strings.TrimSpace(lines[len(lines)-1]) != "" {
			lines = append(lines, "")
		}
		lines = append(lines, "[misc]", wanted)
		status = "added"
	}
	text := strings.Join(lines, newline)
	if strings.HasSuffix(original, "\n") || status == "added" {
		text += newline
	}
	if got := parseTOML(text)["misc"]; got == nil || got.(map[string]any)[catalogKey] != catalogPath {
		return "", kernel.Newf(kernel.KindGeneric, "не удалось записать ключ в секцию [misc]; файл не изменён")
	}
	backup := configPath + ".bak-zerocore"
	if !fileExists(backup) {
		if err := os.WriteFile(backup, raw, 0o600); err != nil {
			return "", err
		}
	}
	if err := writeFileAtomic(configPath, []byte(text), 0o644); err != nil {
		return "", err
	}
	return status, nil
}

// wiredCatalog — что записано в конфиге бота: путь к каталогу или "".
func wiredCatalog(configPath string) string {
	raw, err := os.ReadFile(configPath)
	if err != nil {
		return ""
	}
	misc, _ := parseTOML(string(raw))["misc"].(map[string]any)
	if v, ok := misc[catalogKey].(string); ok {
		return v
	}
	return ""
}

type check struct {
	Status, Title, Detail, Fix string
}

// doctor — проверки среды: [статус, название, подробности, что делать]; статус ok, warn или fail.
func (s *Server) doctor(kuniDir string, port int) []check {
	var out []check
	add := func(status, title, detail, fix string) {
		out = append(out, check{status, title, detail, fix})
	}
	add("ok", "среда выполнения", "Go, стандартная библиотека", "")
	home := s.M.Home
	if err := os.MkdirAll(home, 0o755); err == nil {
		probe := filepath.Join(home, ".write-probe")
		if f, err := os.Create(probe); err == nil {
			f.Close()
			_ = os.Remove(probe)
			add("ok", "домашний каталог ядра", home, "")
		} else {
			add("fail", "домашний каталог ядра", home, "проверьте права на каталог")
		}
	}
	if st, err := os.Stat(filepath.Join(home, "panel_token")); err == nil {
		mode := st.Mode().Perm()
		if mode&0o077 == 0 {
			add("ok", "права на токен панели", modeString(mode), "")
		} else {
			add("warn", "права на токен панели", modeString(mode), "chmod 600 "+filepath.Join(home, "panel_token"))
		}
	}
	rows := s.M.Status()
	enabled := 0
	for _, r := range rows {
		if r["enabled"] == true {
			enabled++
		}
	}
	if len(rows) > 0 {
		add("ok", "модули установлены", strconv.Itoa(len(rows))+" шт., включено "+strconv.Itoa(enabled), "")
	} else {
		add("warn", "модули установлены", "нет", "установите деталь из готовых или загрузите zip")
	}
	if problems := s.M.CheckIntegrity(); len(problems) == 0 {
		add("ok", "целостность модулей", "в порядке", "")
	} else {
		add("fail", "целостность модулей", strings.Join(problems, "; "), "проверьте зависимости деталей")
	}
	kdir := detectKuniDir(kuniDir)
	if kdir == "" {
		detail := "не найден"
		if kuniDir != "" {
			detail = "не найден (" + kuniDir + ")"
		}
		add("fail", "каталог бота kuni", detail, "укажите каталог бота в настройках модуля kuni (kuni_dir)")
		return out
	}
	add("ok", "каталог бота kuni", kdir, "")
	cfgPath := filepath.Join(kdir, "config.toml")
	if fileExists(cfgPath) {
		llm := parseLLM(cfgPath)
		if avail, _ := llm["available"].(bool); avail {
			add("ok", "config.toml бота читается", toStr(llm["provider"])+": "+toStr(llm["model"]), "")
		} else {
			add("fail", "config.toml бота читается", "не найден или повреждён", "проверьте файл config.toml")
		}
	} else {
		add("fail", "config.toml бота читается", "не найден", "проверьте файл config.toml")
	}
	nLogs := 0
	if entries, err := os.ReadDir(filepath.Join(kdir, "logs")); err == nil {
		for _, e := range entries {
			if strings.HasSuffix(e.Name(), "query.json") {
				nLogs++
			}
		}
	}
	if nLogs > 0 {
		add("ok", "журнал запросов LLM (logs/)", strconv.Itoa(nLogs)+" запросов", "")
	} else {
		add("warn", "журнал запросов LLM (logs/)", "пусто или нет каталога", "виджеты «Генерация», «Тулы» и статистика заполнятся после работы бота")
	}
	console := newestFile("/tmp/aui.*.log")
	if console != "" {
		add("ok", "консольный лог бота (/tmp/aui.*.log)", filepath.Base(console), "")
	} else {
		add("warn", "консольный лог бота (/tmp/aui.*.log)", "не найден", "запустите бота: статистика и живой лог берутся оттуда")
	}
	if processRSSMB("kuni") != nil {
		add("ok", "процесс kuni запущен", "", "")
	} else {
		add("warn", "процесс kuni запущен", "", "запустите бота")
	}
	wired := wiredCatalog(cfgPath)
	expected := s.M.ToolsPath()
	if wired == expected {
		add("ok", "каталог инструментов подключён к боту", wired, "")
	} else {
		shown := wired
		if shown == "" {
			shown = "не задан"
		}
		add("warn", "каталог инструментов подключён к боту", "сейчас: "+shown, "подключите каталог инструментов к боту (wire-kuni)")
	}
	if fileExists(expected) {
		add("ok", "каталог инструментов tools.json", expected, "")
	} else {
		add("warn", "каталог инструментов tools.json", expected, "выполните экспорт инструментов")
	}
	if portFree("127.0.0.1", port) {
		add("ok", "порт панели "+strconv.Itoa(port), "свободен", "")
	} else {
		add("warn", "порт панели "+strconv.Itoa(port), "занят (панель уже запущена?)", "")
	}
	if _, err := exec.LookPath("tmux"); err == nil {
		add("ok", "tmux", "найден", "")
	} else {
		add("warn", "tmux", "не найден", "sudo apt install tmux (панель в фоне, переживает закрытие SSH)")
	}
	if ips := lanIPs(); len(ips) > 0 {
		add("ok", "адрес в локальной сети (для телефона)", strings.Join(ips, ", "), "")
	} else {
		add("warn", "адрес в локальной сети (для телефона)", "не найден", "подключитесь к Wi-Fi или укажите --host вручную")
	}
	return out
}

func modeString(m os.FileMode) string {
	return "0" + strconv.FormatUint(uint64(m.Perm()), 8)
}

// availableParts — готовые детали из поставки (каталог modules рядом с ядром).
func (s *Server) availableParts() map[string]any {
	found, errs := manager.Discover(filepath.Join(s.M.CoreDir, "modules"))
	inst := s.installed()
	var mods []map[string]any
	names := make([]string, 0, len(found))
	for n := range found {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		mf := found[n].Manifest
		_, isInst := inst[n]
		mods = append(mods, map[string]any{"name": n, "version": mf.Version, "kind": mf.Kind, "description": mf.Description, "installed": isInst})
	}
	if mods == nil {
		mods = []map[string]any{}
	}
	if errs == nil {
		errs = []string{}
	}
	return map[string]any{"modules": mods, "errors": errs}
}

// installAvailable ставит готовую деталь из поставки.
func (s *Server) installAvailable(name string) (map[string]any, error) {
	found, _ := manager.Discover(filepath.Join(s.M.CoreDir, "modules"))
	d, ok := found[name]
	if !ok {
		return nil, kernel.Newf(kernel.KindGeneric, "%s: нет среди готовых деталей", name)
	}
	if _, inst := s.installed()[name]; inst {
		return nil, kernel.Newf(kernel.KindGeneric, "%s: уже установлена", name)
	}
	if _, err := s.M.Install(d.Dir); err != nil {
		return nil, err
	}
	return s.availableParts(), nil
}
