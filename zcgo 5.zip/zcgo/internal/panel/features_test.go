package panel

import (
	"archive/tar"
	"compress/gzip"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func writeFile(t *testing.T, p, body string) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(p, []byte(body), 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestBackupRoundTripAndPrune(t *testing.T) {
	home := t.TempDir()
	kuni := t.TempDir()
	writeFile(t, filepath.Join(home, "settings.json"), `{"a":1}`)
	writeFile(t, filepath.Join(home, "backups", "old.txt"), "skip me")
	writeFile(t, filepath.Join(home, "tools.json"), "skip me too")
	writeFile(t, filepath.Join(kuni, "config.toml"), "[general]")
	writeFile(t, filepath.Join(kuni, "prompts", "p.md"), "hello")
	writeFile(t, filepath.Join(kuni, "logs", "x.json"), "not copied")

	base := time.Date(2026, 10, 1, 10, 0, 0, 0, time.Local)
	res, err := createBackup(home, kuni, "Перед обновлением ✓", base)
	if err != nil {
		t.Fatal(err)
	}
	name := res["name"].(string)
	if !strings.Contains(name, "pered-obnovleniem") || strings.ContainsAny(name, "✓ ") {
		t.Errorf("заметка не транслитерирована: %s", name)
	}
	items := listBackups(home)
	if len(items) != 1 || items[0].Files == nil || *items[0].Files != 3 {
		t.Fatalf("состав копии: %+v", items)
	}
	if items[0].Note != "Перед обновлением ✓" {
		t.Errorf("заметка в манифесте: %q", items[0].Note)
	}
	// содержимое: home без служебных, kuni без logs
	var names []string
	_ = walkArchive(filepath.Join(home, "backups", name), func(h *tar.Header, _ io.Reader) error {
		names = append(names, h.Name)
		return nil
	})
	joined := strings.Join(names, " ")
	for _, bad := range []string{"home/backups", "home/tools.json", "kuni/logs"} {
		if strings.Contains(joined, bad) {
			t.Errorf("в копии лишнее: %s (%s)", bad, joined)
		}
	}
	for _, good := range []string{"home/settings.json", "kuni/config.toml", "kuni/prompts/p.md", "manifest.json"} {
		if !strings.Contains(joined, good) {
			t.Errorf("нет в копии: %s", good)
		}
	}

	// восстановление меняет файл и делает страховую копию
	writeFile(t, filepath.Join(home, "settings.json"), `{"a":2}`)
	out, err := restoreBackup(home, name, kuni, base.Add(time.Minute))
	if err != nil {
		t.Fatal(err)
	}
	raw, _ := os.ReadFile(filepath.Join(home, "settings.json"))
	if string(raw) != `{"a":1}` || out["restored"].(int) < 3 || out["safety"] == "" {
		t.Errorf("восстановление: %s %v", raw, out)
	}
	if len(listBackups(home)) != 2 {
		t.Errorf("страховая копия не создана")
	}

	// прореживание оставляет самые свежие
	for i := 0; i < 3; i++ {
		_, _ = createBackup(home, "", "", base.Add(time.Duration(i+2)*time.Hour))
	}
	if removed := pruneBackups(home, 2); removed != 3 {
		t.Errorf("удалено %d, ожидали 3", removed)
	}
}

func TestRestoreRejectsUnsafePaths(t *testing.T) {
	home := t.TempDir()
	dir := filepath.Join(home, "backups")
	_ = os.MkdirAll(dir, 0o700)
	evil := filepath.Join(dir, "20260101-000000.tar.gz")
	f, _ := os.Create(evil)
	gz := gzip.NewWriter(f)
	tw := tar.NewWriter(gz)
	body := []byte("x")
	_ = tw.WriteHeader(&tar.Header{Name: "home/../../escape.txt", Mode: 0o600, Size: int64(len(body))})
	_, _ = tw.Write(body)
	_ = tw.Close()
	_ = gz.Close()
	_ = f.Close()
	if _, err := restoreBackup(home, filepath.Base(evil), "", time.Now()); err == nil || !strings.Contains(err.Error(), "небезопасный путь") {
		t.Fatalf("путь с .. должен отклоняться: %v", err)
	}
	if _, err := os.Stat(filepath.Join(home, "..", "escape.txt")); err == nil {
		t.Error("файл вне дома записан")
	}
	if _, err := restoreBackup(home, "../evil.tar.gz", "", time.Now()); err == nil {
		t.Error("имя с каталогом должно отклоняться")
	}
}

func TestPromptsKeepBlocksAndVersions(t *testing.T) {
	home := t.TempDir()
	kuni := t.TempDir()
	block := "\n<!-- zerocore:begin module=demo patch=rule -->\nПравило демо\n<!-- zerocore:end module=demo patch=rule -->\n"
	writeFile(t, filepath.Join(kuni, "prompts", "main.md"), "Привет\n"+block+"Конец\n")
	now := time.Date(2026, 10, 2, 9, 0, 0, 0, time.Local)

	// правка текста вокруг блока: сохраняется, прежняя версия в истории
	if _, err := savePrompt(kuni, home, "main.md", "Здравствуй\n"+block+"Конец\n", "смена приветствия", now); err != nil {
		t.Fatalf("правка вокруг блока: %v", err)
	}
	// блок менять нельзя
	if _, err := savePrompt(kuni, home, "main.md", "Здравствуй\nБез блока\nКонец\n", "", now); err == nil || !strings.Contains(err.Error(), "блоки") {
		t.Fatalf("удаление блока должно отклоняться: %v", err)
	}
	if _, err := savePrompt(kuni, home, "main.md", "Здравствуй\n"+block+"Конец\n", "", now); err == nil {
		t.Error("без изменений должно отклоняться")
	}
	hist := promptHistoryList(home, "main.md")
	if len(hist) != 1 || hist[0]["note"] != "смена приветствия" {
		t.Fatalf("история: %v", hist)
	}
	id := hist[0]["id"].(string)
	d, err := diffPrompts(kuni, home, "main.md", id, "current")
	if err != nil || d["added"] != 1 || d["removed"] != 1 {
		t.Errorf("сравнение: %v %v", d, err)
	}
	// откат возвращает старый текст, блок остаётся текущим
	if _, err := restorePrompt(kuni, home, "main.md", id, now.Add(time.Minute)); err != nil {
		t.Fatalf("откат: %v", err)
	}
	raw, _ := os.ReadFile(filepath.Join(kuni, "prompts", "main.md"))
	if !strings.HasPrefix(string(raw), "Привет") || !strings.Contains(string(raw), "Правило демо") {
		t.Errorf("после отката: %q", raw)
	}
	if _, err := readPrompt(kuni, home, "../x.md"); err == nil {
		t.Error("выход из папки промптов должен отклоняться")
	}
}

func TestUnifiedDiffFormat(t *testing.T) {
	text, added, removed := unifiedDiff("a", "b", "one\ntwo\nthree\nfour\n", "one\nTWO\nthree\nfour\nfive\n")
	if added != 2 || removed != 1 {
		t.Errorf("счётчики: +%d -%d", added, removed)
	}
	if !strings.Contains(text, "-two") || !strings.Contains(text, "+TWO") || !strings.Contains(text, "@@ -1,") {
		t.Errorf("формат: %s", text)
	}
	if empty, a, r := unifiedDiff("a", "b", "x\n", "x\n"); empty != "" || a != 0 || r != 0 {
		t.Errorf("одинаковые тексты: %q", empty)
	}
}

func TestAlertsValidationAndTelegramDelivery(t *testing.T) {
	home := t.TempDir()
	var got struct {
		Chat, Text string
	}
	tg := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		var body map[string]any
		_ = json.NewDecoder(r.Body).Decode(&body)
		got.Chat, _ = body["chat_id"].(string)
		got.Text, _ = body["text"].(string)
		if !strings.Contains(r.URL.Path, "/bot123456789:") {
			w.WriteHeader(404)
			_, _ = w.Write([]byte(`{"ok":false,"description":"not found"}`))
			return
		}
		_, _ = w.Write([]byte(`{"ok":true}`))
	}))
	defer tg.Close()
	t.Setenv("ZEROCORE_TG_API", tg.URL)

	if _, err := setAlertToken(home, "не токен"); err == nil {
		t.Error("неверный вид токена должен отклоняться")
	}
	if _, err := saveAlerts(home, map[string]any{"chat_id": "abc"}); err == nil {
		t.Error("chat_id с буквами должен отклоняться")
	}
	if _, err := saveAlerts(home, map[string]any{"enabled": true}); err == nil {
		t.Error("без токена и chat_id оповещения не включаются")
	}
	if _, err := setAlertToken(home, "123456789:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"); err != nil {
		t.Fatal(err)
	}
	if _, err := saveAlerts(home, map[string]any{"chat_id": "42", "enabled": true, "cooldown_min": 10}); err != nil {
		t.Fatal(err)
	}
	if err := sendTelegram(home, "привет"); err != nil {
		t.Fatalf("отправка: %v", err)
	}
	if got.Text != "привет" || got.Chat != "42" {
		t.Errorf("доставлено: %+v", got)
	}
	// второй вызов в пределах cooldown не шлётся
	calls := 0
	send := func(home, text string) error { calls++; return nil }
	now := float64(time.Now().Unix())
	if !notifyAlert(home, "errors", "первое", now, send) {
		t.Fatal("первое оповещение должно уйти")
	}
	if notifyAlert(home, "errors", "второе", now+60, send) {
		t.Error("внутри cooldown оповещение не должно уходить")
	}
	if !notifyAlert(home, "errors", "третье", now+11*60, send) || calls != 2 {
		t.Errorf("после cooldown: вызовов %d", calls)
	}
	// статус показывает, что токен задан, но не его значение
	st := alertsStatus(home)
	raw, _ := json.Marshal(st)
	if st["token_set"] != true || strings.Contains(string(raw), "123456789:") {
		t.Errorf("статус: %s", raw)
	}
}

func TestHistorySampleAndUsage(t *testing.T) {
	home := t.TempDir()
	base := time.Date(2026, 10, 18, 12, 0, 0, 0, time.Local)
	reader := func() map[string]any {
		return map[string]any{"load1": 1.5, "mem": 40.0, "disk": 50.0, "battery": nil, "temp": nil}
	}
	for i := 0; i < 5; i++ {
		if err := sampleHistory(home, base.Add(time.Duration(i)*time.Minute), reader); err != nil {
			t.Fatal(err)
		}
	}
	// старые точки уходят
	if err := sampleHistory(home, base.Add(20*24*time.Hour), reader); err != nil {
		t.Fatal(err)
	}
	series := historySeries(home, 1, base.Add(20*24*time.Hour), 240)
	if ts := series["t"].([]any); len(ts) != 1 {
		t.Errorf("после очистки старых точек: %d", len(ts))
	}
	cost := 0.25
	if err := recordUsage(home, "chat", "gpt-x", 100, 50, &cost, "", base); err != nil {
		t.Fatal(err)
	}
	if err := recordUsage(home, "chat", "gpt-x", 10, 5, nil, "", base); err != nil {
		t.Fatal(err)
	}
	u := usageSummary(home, 14, base.Add(time.Hour))
	tot := u["total"].(map[string]any)
	if tot["requests"] != 2 || tot["cost_unknown"] != 1 || tot["cost"] != 0.25 {
		t.Errorf("расходы: %v", tot)
	}
}

func TestBackgroundStepRunsWithoutAlerts(t *testing.T) {
	srv, _ := newPanel(t)
	done := srv.backgroundStep(time.Now())
	if done["history"] != true {
		t.Errorf("история: %v", done["history"])
	}
	if _, ok := done["alerts"]; !ok {
		t.Error("проверка оповещений не выполнена")
	}
}

func TestPromptsRoutesWithoutKuniDirAnswerClearly(t *testing.T) {
	_, ts := newPanel(t)
	code, out, _ := do(t, ts, "GET", "/api/prompts", token, "")
	if code != 400 || !strings.Contains(out["error"].(string), "kuni_dir") {
		t.Errorf("без каталога бота: %d %v", code, out)
	}
	if code, _, _ := do(t, ts, "GET", "/api/backups", token, ""); code != 200 {
		t.Errorf("копии без бота: %d", code)
	}
	if code, out, _ := do(t, ts, "POST", "/api/backups/20260101-000000.tar.gz/restore", token, `{}`); code != 400 || !strings.Contains(out["error"].(string), "confirm") {
		t.Errorf("восстановление без подтверждения: %d %v", code, out)
	}
}
