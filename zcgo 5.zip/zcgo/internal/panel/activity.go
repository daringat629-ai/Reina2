package panel

// Живая активность для схемы архитектуры: что происходило недавно и по какой связи это «прошло».
// Источники: события менеджера, консольный лог бота, файлы журнала запросов к LLM.

import (
	"os"
	"sort"
	"strings"
	"time"

	"zcgo/internal/kernel"
)

const activityLimit = 60

type actEvent struct {
	T     float64 `json:"t"`
	A     string  `json:"a"`
	B     string  `json:"b"`
	Kind  string  `json:"kind"`
	Level string  `json:"level"`
	Text  string  `json:"text"`
}

func newAct(t float64, a, b, kind, text, level string) actEvent {
	r := []rune(text)
	if len(r) > 80 {
		text = string(r[:80])
	}
	return actEvent{T: roundTo(t, 3), A: a, B: b, Kind: kind, Level: level, Text: text}
}

func fromBus(events []kernel.Event, since float64) []actEvent {
	var out []actEvent
	for _, e := range events {
		if e.TS <= since {
			continue
		}
		topic := e.Topic
		mod, _ := e.Payload["module"].(string)
		bad := strings.HasSuffix(topic, "failed") || strings.HasSuffix(topic, "broken") || strings.HasSuffix(topic, "suppressed")
		level := "info"
		if bad {
			level = "error"
		}
		if mod != "" {
			out = append(out, newAct(e.TS, "manager", "mod_"+mod, "manager", topic+" "+mod, level))
		}
		switch {
		case topic == "module.installed" || topic == "module.swapped" || topic == "module.uninstalled" || topic == "swap.failed":
			out = append(out, newAct(e.TS, "manager", "installer", "manager", topic, level))
		case strings.HasPrefix(topic, "tools."):
			out = append(out, newAct(e.TS, "manager", "catalog", "tools", topic, level))
		case topic == "integrity.broken":
			out = append(out, newAct(e.TS, "manager", "solver", "manager", topic, "error"))
		case topic == "module.started" || topic == "module.stopped" || topic == "module.restarted" || topic == "health.changed":
			out = append(out, newAct(e.TS, "manager", "lifecycle", "manager", topic, level))
		case topic == "config.changed":
			out = append(out, newAct(e.TS, "manager", "state", "manager", topic, level))
		}
	}
	return out
}

type timedLine struct {
	t    float64
	ok   bool
	line string
}

func fromConsole(lines []timedLine, since float64) []actEvent {
	var out []actEvent
	for _, tl := range lines {
		if !tl.ok || tl.t <= since {
			continue
		}
		t, line := tl.t, tl.line
		switch {
		case strings.Contains(line, "[send_telegram_message][INFO]: Synthetic typing delay"):
			out = append(out, newAct(t, "k_telegram", "telegram", "message", "сообщение отправлено", "info"))
		case strings.Contains(line, "Processing notification"):
			out = append(out, newAct(t, "telegram", "k_telegram", "message", "входящее сообщение", "info"))
			out = append(out, newAct(t, "k_telegram", "k_cognition", "message", "событие в цикл ходов", "info"))
		case strings.Contains(line, "[tools::shell][WARN]: EXEC:"):
			cmd := strings.TrimSpace(strings.SplitN(line, "EXEC:", 2)[1])
			out = append(out, newAct(t, "k_cognition", "k_tools", "tool", "shell: "+cmd, "info"))
		case strings.Contains(line, "[tools::external][INFO]: CALL"):
			name := strings.TrimSpace(strings.SplitN(line, "CALL", 2)[1])
			out = append(out, newAct(t, "k_cognition", "k_tools", "tool", "инструмент "+name, "info"))
			out = append(out, newAct(t, "k_tools", "catalog", "tools", "инструмент "+name, "info"))
		case strings.Contains(line, "[tools::external][INFO]: Loaded"):
			out = append(out, newAct(t, "catalog", "k_tools", "tools", "каталог перечитан", "info"))
		case strings.Contains(line, "tool call refused"):
			out = append(out, newAct(t, "k_cognition", "k_tools", "guard", "отказ охранника", "error"))
		case strings.Contains(line, "chatStreaming: status=HTTP_"):
			out = append(out, newAct(t, "k_cognition", "llm", "llm", "ошибка LLM", "error"))
		}
	}
	return out
}

// fromLogs — файлы журнала запросов к LLM, изменённые после since (сорт по имени, последние 60).
func fromLogs(logsDir string, since float64) []actEvent {
	entries, err := os.ReadDir(logsDir)
	if err != nil {
		return nil
	}
	var names []string
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), "query.json") || strings.HasSuffix(e.Name(), "response.json") {
			names = append(names, e.Name())
		}
	}
	sort.Sort(sort.Reverse(sort.StringSlice(names)))
	if len(names) > 60 {
		names = names[:60]
	}
	var out []actEvent
	for _, n := range names {
		st, err := os.Stat(logsDir + string(os.PathSeparator) + n)
		if err != nil {
			continue
		}
		t := float64(st.ModTime().UnixNano()) / 1e9
		if t > since {
			text := "ответ LLM"
			if strings.HasSuffix(n, "query.json") {
				text = "запрос к LLM"
			}
			out = append(out, newAct(t, "k_cognition", "llm", "llm", text, "info"))
		}
	}
	return out
}

// collectActivity собирает события за окно (since, now], без дублей, не больше activityLimit.
func collectActivity(events []kernel.Event, logsDir, consolePath string, since, now float64) map[string]any {
	evs := fromBus(events, since)
	if consolePath != "" {
		lines := consoleLines(consolePath, 300, 400_000)
		nowT := time.Unix(0, int64(now*1e9))
		var tl []timedLine
		for _, l := range lines {
			t, ok := parseConsoleTS(l, nowT)
			tl = append(tl, timedLine{t: t, ok: ok, line: l})
		}
		evs = append(evs, fromConsole(tl, since)...)
	}
	if logsDir != "" {
		evs = append(evs, fromLogs(logsDir, since)...)
	}
	sort.SliceStable(evs, func(i, j int) bool { return evs[i].T < evs[j].T })
	type key struct {
		t         float64
		a, b, txt string
	}
	seen := map[key]bool{}
	var unique []actEvent
	for _, e := range evs {
		k := key{e.T, e.A, e.B, e.Text}
		if !seen[k] {
			seen[k] = true
			unique = append(unique, e)
		}
	}
	if len(unique) > activityLimit {
		unique = unique[len(unique)-activityLimit:]
	}
	if unique == nil {
		unique = []actEvent{}
	}
	return map[string]any{"now": roundTo(now, 3), "events": unique}
}
