package panel

// Экосистема: наборы деталей eco_* (порт eco_payload и eco_set из admin/server.py
// и SETS/estimate_tokens из eco/core.py). Метаданные инструментов выгружены из
// Python-источника в eco_catalog.json. Сами инструменты eco остаются Python-модулями.

import (
	"bytes"
	_ "embed"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"unicode/utf8"

	"zcgo/internal/manager"
)

//go:embed eco_catalog.json
var ecoCatalogRaw []byte

type ecoSetDef struct {
	Key     string   `json:"key"`
	Title   string   `json:"title"`
	Desc    string   `json:"desc"`
	Modules []string `json:"modules"`
}

type ecoModuleDef struct {
	Title   string   `json:"title"`
	Desc    string   `json:"desc"`
	Tools   []string `json:"tools"`
	Patches []any    `json:"patches"`
}

type ecoToolDef struct {
	Module     string `json:"module"`
	Desc       string `json:"desc"`
	ParamsJSON string `json:"params_json"`
}

type ecoCatalog struct {
	Sets    []ecoSetDef             `json:"sets"`
	Modules map[string]ecoModuleDef `json:"modules"`
	Tools   map[string]ecoToolDef   `json:"tools"`
}

// ecoCat — метаданные eco, зашитые в бинарник. Файл проверяется тестами.
var ecoCat = mustLoadEco()

func mustLoadEco() *ecoCatalog {
	var c ecoCatalog
	if err := json.Unmarshal(ecoCatalogRaw, &c); err != nil {
		panic("eco_catalog.json: " + err.Error())
	}
	return &c
}

// ecoEstimateTokens — оценка объёма описаний инструментов, та же формула, что в Python:
// длины имени, описания и параметров (в символах) плюс 30 на инструмент, делить на 3,5.
func ecoEstimateTokens(names []string) int {
	total := 0
	for _, n := range names {
		t, ok := ecoCat.Tools[n]
		if !ok {
			continue
		}
		total += utf8.RuneCountInString(n) + utf8.RuneCountInString(t.Desc) +
			utf8.RuneCountInString(t.ParamsJSON) + 30
	}
	return int(float64(total) / 3.5)
}

// catalogTokens оценивает tools.json так же, как Python: по полям name, description, parameters.
// Отличие: порядок и пробелы JSON компактные, поэтому оценка немного ниже Python-версии.
func catalogTokens(entries []manager.ToolEntry) int {
	total := 0
	for _, t := range entries {
		var buf bytes.Buffer
		enc := json.NewEncoder(&buf)
		enc.SetEscapeHTML(false)
		_ = enc.Encode(map[string]any{"name": t.Name, "description": t.Description, "parameters": t.Parameters})
		total += utf8.RuneCount(bytes.TrimRight(buf.Bytes(), "\n"))
	}
	return int(float64(total) / 3.5)
}

func readToolsCatalog(path string) []manager.ToolEntry {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	var c manager.Catalog
	if err := json.Unmarshal(raw, &c); err != nil {
		return nil
	}
	return c.Tools
}

// pendingTrust — детали, у которых патчи ждут одобрения (по последнему сохранённому состоянию).
func (s *Server) pendingTrust() map[string]bool {
	out := map[string]bool{}
	for mod, patches := range s.M.LoadPatchState() {
		for _, p := range patches {
			if p.Status == "pending_trust" {
				out[mod] = true
			}
		}
	}
	return out
}

func (s *Server) isEnabled(name string) bool {
	st, ok := s.installed()[name]
	return ok && st.Enabled
}

// ecoPayload — наборы с деталями, оценкой токенов и состоянием, плюс размер каталога для бота.
func (s *Server) ecoPayload() map[string]any {
	found, _ := manager.Discover(filepath.Join(s.M.CoreDir, "modules"))
	inst := s.installed()
	pending := s.pendingTrust()
	sets := make([]any, 0, len(ecoCat.Sets))
	for _, set := range ecoCat.Sets {
		rows := make([]any, 0, len(set.Modules))
		allOn := true
		tokens := 0
		for _, n := range set.Modules {
			mod := ecoCat.Modules[n]
			t := ecoEstimateTokens(mod.Tools)
			on := s.isEnabled(n)
			if !on {
				allOn = false
			}
			tokens += t
			_, isInst := inst[n]
			_, avail := found[n]
			rows = append(rows, map[string]any{
				"name": n, "installed": isInst, "enabled": on, "available": avail,
				"tools": len(mod.Tools), "tokens": t, "pending_trust": pending[n],
			})
		}
		sets = append(sets, map[string]any{
			"key": set.Key, "title": set.Title, "desc": set.Desc,
			"enabled": allOn, "tokens": tokens, "modules": rows,
		})
	}
	entries := readToolsCatalog(s.M.ToolsPath())
	tokens := catalogTokens(entries)
	return map[string]any{
		"sets":    sets,
		"catalog": map[string]any{"tools": len(entries), "tokens": tokens, "warn": tokens > 4000},
	}
}

// ecoSet включает или выключает набор. Недостающие детали ставятся из поставки.
// Включение набора владельцем одобряет патчи деталей eco_* (как в Python).
func (s *Server) ecoSet(body map[string]any) (map[string]any, error) {
	key, _ := body["key"].(string)
	want, _ := body["enabled"].(bool)
	var set *ecoSetDef
	for i := range ecoCat.Sets {
		if ecoCat.Sets[i].Key == key {
			set = &ecoCat.Sets[i]
			break
		}
	}
	if set == nil {
		return nil, fmt.Errorf("набора %s нет", key)
	}
	found, _ := manager.Discover(filepath.Join(s.M.CoreDir, "modules"))
	for _, n := range set.Modules {
		if want {
			if err := s.ecoEnsure(found, n); err != nil {
				return nil, err
			}
		} else if s.isEnabled(n) {
			if _, err := s.M.Disable(n, true); err != nil {
				return nil, err
			}
		}
	}
	s.M.RefreshExtensions()
	return s.ecoPayload(), nil
}

// ecoEnsure ставит, включает и одобряет патчи одной детали набора.
func (s *Server) ecoEnsure(found map[string]manager.Discovered, n string) error {
	if _, inst := s.installed()[n]; !inst {
		d, ok := found[n]
		if !ok {
			return fmt.Errorf("%s: нет среди готовых деталей этой установки; обновите ядро", n)
		}
		if _, err := s.M.Install(d.Dir); err != nil {
			return err
		}
	}
	if !s.isEnabled(n) {
		if _, err := s.M.Enable(n); err != nil {
			return err
		}
	}
	mf, err := s.M.Manifest(n, "")
	if err != nil {
		return err
	}
	if len(mf.Patches) > 0 {
		return manager.Approve(s.M.Home, n, s.moduleDir(n), mf.Version)
	}
	return nil
}
