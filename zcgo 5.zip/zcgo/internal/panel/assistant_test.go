package panel

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// scripted — подменяет модель: отдаёт заранее заданные ответы по очереди.
type scripted struct {
	replies []map[string]any
	calls   int
}

func (sc *scripted) fn(_ llmCreds, _ []map[string]any, _ []any) (llmReply, error) {
	if sc.calls >= len(sc.replies) {
		return llmReply{}, errors.New("ответы закончились")
	}
	m := sc.replies[sc.calls]
	sc.calls++
	return llmReply{Message: m, Model: "test-model", Prompt: 10, Compl: 5}, nil
}

func toolCall(id, name, args string) map[string]any {
	return map[string]any{"id": id, "type": "function", "function": map[string]any{"name": name, "arguments": args}}
}

func setupAssistant(t *testing.T, replies ...map[string]any) (*Server, *assistantState, *scripted) {
	t.Helper()
	srv, _ := newPanel(t)
	a := srv.asst
	sc := &scripted{replies: replies}
	a.llmFn = sc.fn
	a.credsFn = func(string) (llmCreds, error) { return llmCreds{URL: "http://x", Key: "k", Model: "m"}, nil }
	a.now = func() time.Time { return time.Date(2026, 10, 18, 12, 0, 0, 0, time.Local) }
	return srv, a, sc
}

func TestAssistantRunsToolThenAnswers(t *testing.T) {
	_, a, _ := setupAssistant(t,
		map[string]any{"content": "", "tool_calls": []any{toolCall("c1", "shell", `{"command":"echo привет"}`)}},
		map[string]any{"content": "Готово: привет."},
	)
	if _, err := a.setSettings(map[string]any{"confirm": "never"}); err != nil {
		t.Fatal(err)
	}
	res, err := a.message("скажи привет через shell")
	if err != nil {
		t.Fatal(err)
	}
	if res["reply"] != "Готово: привет." || res["error"] != nil {
		t.Fatalf("ответ: %v", res)
	}
	steps := res["steps"].([]map[string]any)
	if len(steps) != 1 || steps[0]["ok"] != true || !strings.Contains(steps[0]["result"].(string), "привет") {
		t.Errorf("шаги: %v", steps)
	}
	audit := a.auditTail(10)
	if len(audit) == 0 || audit[0]["tool"] != "shell" {
		t.Errorf("журнал: %v", audit)
	}
}

func TestDangerousCommandAsksAndRejectionIsReported(t *testing.T) {
	_, a, _ := setupAssistant(t,
		map[string]any{"content": "", "tool_calls": []any{toolCall("c9", "shell", `{"command":"sudo ls /root"}`)}},
		map[string]any{"content": "Хорошо, не буду."},
	)
	res, err := a.message("выполни sudo")
	if err != nil {
		t.Fatal(err)
	}
	p, ok := res["pending"].(map[string]any)
	if !ok || p["id"] != "c9" || !strings.Contains(p["why"].(string), "опасную") {
		t.Fatalf("должно спросить: %v", res)
	}
	res, err = a.confirm("c9", false)
	if err != nil {
		t.Fatal(err)
	}
	if res["reply"] != "Хорошо, не буду." {
		t.Errorf("после отказа: %v", res)
	}
	msgs := a.session()["messages"].([]any)
	found := false
	for _, m := range msgs {
		if mm := m.(map[string]any); mm["role"] == "tool" && strings.Contains(mm["content"].(string), "отклонил") {
			found = true
		}
	}
	if !found {
		t.Error("отказ не записан в историю для модели")
	}
	if _, err := a.confirm("c9", true); err == nil {
		t.Error("повторное подтверждение уже закрытого действия должно отказать")
	}
}

func TestShellTimeoutStopsCommand(t *testing.T) {
	_, a, _ := setupAssistant(t)
	a.setSettings(map[string]any{"confirm": "never"})
	out, err := a.toolShell(map[string]any{"command": "sleep 20", "timeout_seconds": 1.0})
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(out, "команда остановлена: прошло 1 с") {
		t.Errorf("таймаут: %q", out)
	}
}

func TestFileGuardsAndModuleErrors(t *testing.T) {
	_, a, _ := setupAssistant(t)
	dir := t.TempDir()
	p := filepath.Join(dir, "note.txt")
	if _, err := toolWriteFile(map[string]any{"path": p, "content": "один"}); err != nil {
		t.Fatal(err)
	}
	if _, err := toolWriteFile(map[string]any{"path": p, "content": " два", "append": true}); err != nil {
		t.Fatal(err)
	}
	out, err := toolReadFile(map[string]any{"path": p})
	if err != nil || out != "один два" {
		t.Errorf("чтение: %q %v", out, err)
	}
	bin := filepath.Join(dir, "b.bin")
	_ = os.WriteFile(bin, []byte{0, 1, 2}, 0o644)
	if out, _ := toolReadFile(map[string]any{"path": bin}); out != "двоичный файл, показывать нечего" {
		t.Errorf("двоичный: %q", out)
	}
	if _, err := toolReadFile(map[string]any{"path": filepath.Join(dir, "нет.txt")}); err == nil {
		t.Error("нет файла должна быть ошибка")
	}
	if ok, text := a.execute("module_action", map[string]any{"name": "ghost", "action": "start"}); ok || !strings.Contains(text, "детали ghost нет") {
		t.Errorf("неизвестная деталь: %v %q", ok, text)
	}
	if ok, text := a.execute("nosuch", map[string]any{}); ok || !strings.Contains(text, "нет инструмента") {
		t.Errorf("неизвестный инструмент: %v %q", ok, text)
	}
	// запись в системный путь требует подтверждения в режиме dangerous
	if why := a.needsConfirmation("write_file", map[string]any{"path": "/etc/hosts"}); why == "" {
		t.Error("запись в /etc должна спрашивать")
	}
	if why := a.needsConfirmation("module_action", map[string]any{"name": "kuni", "action": "stop"}); why == "" {
		t.Error("остановка бота должна спрашивать")
	}
	if why := a.needsConfirmation("modules", map[string]any{}); why != "" {
		t.Error("чтение списка деталей не спрашивает")
	}
}

func TestSettingsAndDisabledChat(t *testing.T) {
	_, a, _ := setupAssistant(t)
	if _, err := a.setSettings(map[string]any{"confirm": "maybe"}); err == nil {
		t.Error("неизвестный режим должен отказать")
	}
	if _, err := a.setSettings(map[string]any{"max_steps": 99.0}); err == nil {
		t.Error("max_steps вне диапазона должен отказать")
	}
	if _, err := a.setSettings(map[string]any{"enabled": false}); err != nil {
		t.Fatal(err)
	}
	if _, err := a.message("привет"); err == nil || !strings.Contains(err.Error(), "выключен") {
		t.Errorf("выключенный чат: %v", err)
	}
	a.setSettings(map[string]any{"enabled": true})
	if _, err := a.message("   "); err == nil {
		t.Error("пустое сообщение должно отказать")
	}
}

func TestAssistantRoutesAndStateShape(t *testing.T) {
	srv, ts := newPanel(t)
	a := srv.asst
	a.credsFn = func(string) (llmCreds, error) {
		return llmCreds{}, errors.New("настройки модели не найдены")
	}
	code, out, _ := do(t, ts, "GET", "/api/assistant", token, "")
	if code != 200 || out["settings"] == nil || out["messages"] == nil || out["audit"] == nil {
		t.Fatalf("состояние: %d %v", code, out)
	}
	code, out, _ = do(t, ts, "POST", "/api/assistant/message", token, `{"text":"привет"}`)
	if code != 200 || out["error"] == nil {
		t.Errorf("без модели ошибка в ответе: %d %v", code, out)
	}
	// ключ из config.toml бота не должен попадать в ответы панели
	kuni := t.TempDir()
	cfg := "[general.llm]\nmodel = \"m\"\n[general.llm.endpoint]\nbaseUrl = \"https://example.test/v1\"\nbearerKey = \"SECRET-XYZ-987\"\n"
	_ = os.WriteFile(filepath.Join(kuni, "config.toml"), []byte(cfg), 0o600)
	t.Setenv("ZEROCORE_KUNI_DIR", kuni)
	t.Setenv("ZEROCORE_LLM_KEY", "")
	a.credsFn = llmCredentials
	_, out, _ = do(t, ts, "GET", "/api/assistant", token, "")
	raw, _ := json.Marshal(out)
	if strings.Contains(string(raw), "SECRET-XYZ-987") {
		t.Error("ключ попал в ответ панели")
	}
	if llm, _ := out["llm"].(map[string]any); llm["available"] != true {
		t.Errorf("модель должна считаться доступной: %v", out["llm"])
	}
	code, _, _ = do(t, ts, "POST", "/api/assistant/reset", token, "")
	if code != 200 {
		t.Errorf("сброс: %d", code)
	}
	code, _, _ = do(t, ts, "POST", "/api/assistant/stop", token, "")
	if code != 200 {
		t.Errorf("стоп: %d", code)
	}
	code, _, _ = do(t, ts, "POST", "/api/assistant/settings", token, `{"confirm":"always"}`)
	if code != 200 {
		t.Errorf("настройки: %d", code)
	}
}
