package panel

// Источники данных встроенных виджетов панели. Только чтение. Ключи и секреты не читаются и не отдаются.

import (
	"bufio"
	"encoding/json"
	"math"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"zcgo/internal/kernel"
)

var (
	ansiRE    = regexp.MustCompile(`\x1b\[[0-9;]*[A-Za-z]`)
	consoleTS = regexp.MustCompile(`^\[(\d\d):(\d\d):(\d\d)\]`)
)

const maxToolsQueryBytes = 8_000_000

func newestFile(pattern string) string {
	files, _ := filepath.Glob(pattern)
	best, bestT := "", time.Time{}
	for _, f := range files {
		if st, err := os.Stat(f); err == nil && st.ModTime().After(bestT) {
			best, bestT = f, st.ModTime()
		}
	}
	return best
}

// tailText читает последние maxBytes файла.
func tailText(path string, maxBytes int64) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()
	st, err := f.Stat()
	if err != nil {
		return ""
	}
	start := st.Size() - maxBytes
	if start < 0 {
		start = 0
	}
	buf := make([]byte, st.Size()-start)
	n, _ := f.ReadAt(buf, start)
	return strings.ToValidUTF8(string(buf[:n]), "")
}

// consoleLines — строки консольного лога kuni без шума (замеры производительности, хвосты стека).
func consoleLines(path string, n int, maxBytes int64) []string {
	var out []string
	for _, line := range strings.Split(ansiRE.ReplaceAllString(tailText(path, maxBytes), ""), "\n") {
		if strings.TrimSpace(line) == "" || strings.HasPrefix(line, " - ") || strings.Contains(line, "[Performance]") {
			continue
		}
		out = append(out, strings.TrimRight(line, "\r"))
	}
	if len(out) > n {
		out = out[len(out)-n:]
	}
	return out
}

// ---------- хост ----------

func readMeminfo() map[string]int64 {
	info := map[string]int64{}
	f, err := os.Open("/proc/meminfo")
	if err != nil {
		return info
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		k, v, ok := strings.Cut(sc.Text(), ":")
		if !ok {
			continue
		}
		fields := strings.Fields(v)
		if len(fields) == 0 {
			continue
		}
		if n, err := strconv.ParseInt(fields[0], 10, 64); err == nil {
			info[k] = n
		}
	}
	return info
}

func hostMetrics() map[string]any {
	mem := readMeminfo()
	var pct any
	if total, avail := mem["MemTotal"], mem["MemAvailable"]; total > 0 {
		if _, ok := mem["MemAvailable"]; ok {
			pct = math.Round(1000*(1-float64(avail)/float64(total))) / 10
		}
	}
	var load any
	if raw, err := os.ReadFile("/proc/loadavg"); err == nil {
		if f := strings.Fields(string(raw)); len(f) > 0 {
			if v, err := strconv.ParseFloat(f[0], 64); err == nil {
				load = math.Round(v*100) / 100
			}
		}
	}
	return map[string]any{"load1": load, "mem_pct": pct, "cpus": runtime.NumCPU()}
}

// processRSSMB — память процесса по имени (как comm в /proc), в МБ.
func processRSSMB(comm string) any {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return nil
	}
	for _, e := range entries {
		if _, err := strconv.Atoi(e.Name()); err != nil {
			continue
		}
		c, err := os.ReadFile(filepath.Join("/proc", e.Name(), "comm"))
		if err != nil || strings.TrimSpace(string(c)) != truncName(comm) {
			continue
		}
		status, err := os.ReadFile(filepath.Join("/proc", e.Name(), "status"))
		if err != nil {
			continue
		}
		for _, line := range strings.Split(string(status), "\n") {
			if strings.HasPrefix(line, "VmRSS:") {
				f := strings.Fields(line)
				if len(f) >= 2 {
					if kb, err := strconv.ParseFloat(f[1], 64); err == nil {
						return math.Round(kb/1024*10) / 10
					}
				}
			}
		}
	}
	return nil
}

func truncName(s string) string {
	if len(s) > 15 {
		return s[:15]
	}
	return s
}

// MetricsSampler — кольцевой буфер замеров нагрузки для графика панели.
type MetricsSampler struct {
	mu      sync.Mutex
	points  []map[string]any
	size    int
	stop    chan struct{}
	started bool
	process string
	every   time.Duration
}

func NewMetricsSampler(process string) *MetricsSampler {
	return &MetricsSampler{size: 120, process: process, every: 5 * time.Second, stop: make(chan struct{})}
}

func (s *MetricsSampler) SampleOnce(now time.Time) {
	m := hostMetrics()
	p := map[string]any{"t": float64(now.UnixNano()) / 1e9, "load1": m["load1"], "mem": m["mem_pct"], "rss": processRSSMB(s.process)}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.points = append(s.points, p)
	if len(s.points) > s.size {
		s.points = s.points[len(s.points)-s.size:]
	}
}

func (s *MetricsSampler) Points() []map[string]any {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := make([]map[string]any, len(s.points))
	copy(out, s.points)
	return out
}

func (s *MetricsSampler) Start() {
	s.mu.Lock()
	if s.started {
		s.mu.Unlock()
		return
	}
	s.started = true
	s.mu.Unlock()
	go func() {
		t := time.NewTicker(s.every)
		defer t.Stop()
		for {
			s.SampleOnce(time.Now())
			select {
			case <-s.stop:
				return
			case <-t.C:
			}
		}
	}()
}

func (s *MetricsSampler) Stop() {
	select {
	case <-s.stop:
	default:
		close(s.stop)
	}
}

// ---------- LLM ----------

func hostOnly(raw string) string {
	u, err := url.Parse(raw)
	if err != nil || u.Hostname() == "" {
		return ""
	}
	out := u.Scheme + "://" + u.Hostname()
	if p := u.Port(); p != "" {
		out += ":" + p
	}
	return out
}

func providerOf(host string) string {
	h := strings.ToLower(host)
	switch {
	case strings.Contains(h, "openrouter"):
		return "openrouter"
	case strings.Contains(h, ":11434") || strings.Contains(h, "ollama"):
		return "ollama"
	case strings.Contains(h, "openai.com"):
		return "openai"
	}
	if u, err := url.Parse(host); err == nil && u.Hostname() != "" {
		return u.Hostname()
	}
	return "?"
}

// parseLLM — только модель и хост конечной точки. Ключи не читаются и не отдаются.
func parseLLM(configPath string) map[string]any {
	raw, err := os.ReadFile(configPath)
	if err != nil {
		return map[string]any{"available": false, "error": "config.toml не найден или не читается"}
	}
	data := parseTOML(string(raw))
	g, _ := data["general"].(map[string]any)
	part := func(name string) (string, string) {
		sect, _ := g[name].(map[string]any)
		ep, _ := sect["endpoint"].(map[string]any)
		base, _ := ep["baseUrl"].(string)
		model, _ := sect["model"].(string)
		if len(model) > 200 {
			model = model[:200]
		}
		return model, hostOnly(base)
	}
	model, host := part("llm")
	emodel, ehost := part("embedding")
	lockdown := ""
	if v, ok := g["lockdown"]; ok {
		lockdown = toStr(v)
	}
	return map[string]any{"available": true, "provider": providerOf(host), "model": model, "host": host,
		"embedding_model": emodel, "embedding_host": ehost, "lockdown": lockdown}
}

func toStr(v any) string {
	switch x := v.(type) {
	case string:
		return x
	case bool:
		if x {
			return "true"
		}
		return "false"
	case float64:
		return strconv.FormatFloat(x, 'f', -1, 64)
	}
	return ""
}

// ---------- логи kuni ----------

func queryNames(logsDir string) []string {
	entries, err := os.ReadDir(logsDir)
	if err != nil {
		return nil
	}
	var names []string
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), "query.json") {
			names = append(names, e.Name())
		}
	}
	sort.Sort(sort.Reverse(sort.StringSlice(names)))
	return names
}

// toolsFromQuery — список инструментов, который видит LLM: поле tools в самом свежем запросе.
func toolsFromQuery(logsDir string, limit int) []map[string]any {
	names := queryNames(logsDir)
	if len(names) > 8 {
		names = names[:8]
	}
	for _, name := range names {
		path := filepath.Join(logsDir, name)
		st, err := os.Stat(path)
		if err != nil || st.Size() > maxToolsQueryBytes {
			continue
		}
		raw, err := os.ReadFile(path)
		if err != nil {
			continue
		}
		var doc struct {
			Tools []map[string]any `json:"tools"`
		}
		if json.Unmarshal(raw, &doc) != nil || len(doc.Tools) == 0 {
			continue
		}
		var out []map[string]any
		for i, t := range doc.Tools {
			if i >= limit {
				break
			}
			fn, _ := t["function"].(map[string]any)
			n := toStr(fn["name"])
			if n == "" {
				continue
			}
			if len(n) > 80 {
				n = n[:80]
			}
			desc := toStr(fn["description"])
			if len(desc) > 240 {
				desc = desc[:240]
			}
			out = append(out, map[string]any{"name": n, "description": desc})
		}
		sort.Slice(out, func(i, j int) bool { return out[i]["name"].(string) < out[j]["name"].(string) })
		return out
	}
	return []map[string]any{}
}

// generationState — по журналу запросов: свежий query без response означает, что идёт генерация.
func generationState(logsDir string, now time.Time) map[string]any {
	entries, err := os.ReadDir(logsDir)
	if err != nil {
		return map[string]any{"known": false}
	}
	var files []os.DirEntry
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), "query.json") || strings.HasSuffix(e.Name(), "response.json") {
			files = append(files, e)
		}
	}
	sort.Slice(files, func(i, j int) bool { return files[i].Name() < files[j].Name() })
	if len(files) == 0 {
		return map[string]any{"known": true, "active": false, "last_seconds": nil}
	}
	last := files[len(files)-1]
	lst, _ := last.Info()
	mt := lst.ModTime()
	if strings.HasSuffix(last.Name(), "query.json") && now.Sub(mt) < 5*time.Minute {
		return map[string]any{"known": true, "active": true, "since": roundTo(now.Sub(mt).Seconds(), 1)}
	}
	var duration any
	if strings.HasSuffix(last.Name(), "response.json") && len(files) > 1 && strings.HasSuffix(files[len(files)-2].Name(), "query.json") {
		if pst, err := files[len(files)-2].Info(); err == nil {
			duration = roundTo(mt.Sub(pst.ModTime()).Seconds(), 1)
		}
	}
	return map[string]any{"known": true, "active": false, "last_seconds": duration, "ago": int(math.Round(now.Sub(mt).Seconds()))}
}

func roundTo(v float64, digits int) float64 {
	p := math.Pow(10, float64(digits))
	return math.Round(v*p) / p
}

var (
	reShell    = regexp.MustCompile(`\[tools::shell\]\[WARN\]: EXEC:`)
	reMessage  = regexp.MustCompile(`\[send_telegram_message\]\[INFO\]: Synthetic typing delay`)
	reExternal = regexp.MustCompile(`\[tools::external\]\[INFO\]: CALL`)
	reHTTP     = regexp.MustCompile(`chatStreaming: status=HTTP_`)
	reErrors   = regexp.MustCompile(`\]\[(?:ERROR|ERR)\]`)
)

func stats(logsDir, consolePath string, now time.Time) map[string]any {
	today := now.Format("2006-01-02")
	llmToday := 0
	if entries, err := os.ReadDir(logsDir); err == nil {
		for _, e := range entries {
			if strings.HasPrefix(e.Name(), today) && strings.HasSuffix(e.Name(), "response.json") {
				llmToday++
			}
		}
	}
	text := ""
	if consolePath != "" {
		text = ansiRE.ReplaceAllString(tailText(consolePath, 2_000_000), "")
	}
	session := any(nil)
	if consolePath != "" {
		session = filepath.Base(consolePath)
	}
	return map[string]any{
		"llm_requests_today": llmToday,
		"shell_commands":     len(reShell.FindAllStringIndex(text, -1)),
		"messages_sent":      len(reMessage.FindAllStringIndex(text, -1)),
		"external_calls":     len(reExternal.FindAllStringIndex(text, -1)),
		"guard_refusals":     strings.Count(text, "tool call refused"),
		"llm_http_errors":    len(reHTTP.FindAllStringIndex(text, -1)),
		"errors":             len(reErrors.FindAllStringIndex(text, -1)),
		"session_log":        session,
	}
}

// parseConsoleTS — время из строки лога "[HH:MM:SS]" в ближайшем прошлом относительно now.
func parseConsoleTS(line string, now time.Time) (float64, bool) {
	m := consoleTS.FindStringSubmatch(line)
	if m == nil {
		return 0, false
	}
	h, _ := strconv.Atoi(m[1])
	mi, _ := strconv.Atoi(m[2])
	s, _ := strconv.Atoi(m[3])
	t := time.Date(now.Year(), now.Month(), now.Day(), h, mi, s, 0, now.Location())
	if t.Sub(now) > time.Minute {
		t = t.Add(-24 * time.Hour)
	}
	return float64(t.UnixNano()) / 1e9, true
}

// liveLog — объединяет события шины и хвост консоли бота.
func liveLog(events []kernel.Event, consolePath string, n int, now time.Time) []map[string]any {
	type row struct {
		t    float64
		ok   bool
		src  string
		text string
	}
	var rows []row
	for _, e := range events {
		payload, _ := json.Marshal(e.Payload)
		rows = append(rows, row{t: e.TS, ok: true, src: "core", text: e.Topic + " " + string(payload)})
	}
	if consolePath != "" {
		for _, line := range consoleLines(consolePath, n, 400_000) {
			t, ok := parseConsoleTS(line, now)
			rows = append(rows, row{t: t, ok: ok, src: "kuni", text: line})
		}
	}
	sort.SliceStable(rows, func(i, j int) bool {
		// строки без времени идут в конец, как (t is not None, t or 0) в Python
		if rows[i].ok != rows[j].ok {
			return !rows[i].ok && rows[j].ok
		}
		return rows[i].t < rows[j].t
	})
	if len(rows) > n {
		rows = rows[len(rows)-n:]
	}
	out := make([]map[string]any, 0, len(rows))
	for _, r := range rows {
		var t any
		if r.ok {
			t = r.t
		}
		out = append(out, map[string]any{"t": t, "src": r.src, "text": r.text})
	}
	return out
}
