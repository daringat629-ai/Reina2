package panel

// Резервные копии: домашний каталог ядра и важное из каталога бота (config.toml, prompts, web, notes, marin_world).
// Копия — <дом>/backups/<время>[-заметка].tar.gz с манифестом внутри (права 0600: в ней секреты).
// Восстановление сначала делает копию «перед восстановлением», проверяет пути в архиве и только потом распаковывает.

import (
	"archive/tar"
	"compress/gzip"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"time"
)

var (
	backupNameRE = regexp.MustCompile(`^[0-9]{8}-[0-9]{6}(-[a-z0-9_-]{1,40})?\.tar\.gz$`)
	kuniItems    = []string{"config.toml", "prompts", "web", "notes", "marin_world"}
	homeSkip     = map[string]bool{"backups": true, "tools.json": true, "tools.json.tmp": true, "panel.pid": true}
	cyr          = []rune("абвгдеёжзийклмнопрстуфхцчшщъыьэюя")
	lat          = []rune("abvgdeezzijklmnoprstufhccss_y_eua")
	nonSlug      = regexp.MustCompile(`[^a-z0-9_-]+`)
)

const maxBackupFile = 200 * 1024 * 1024

func backupsDir(home string) (string, error) {
	d := filepath.Join(home, "backups")
	if err := os.MkdirAll(d, 0o700); err != nil {
		return "", err
	}
	_ = os.Chmod(d, 0o700)
	return d, nil
}

func slugify(note string) string {
	s := strings.ToLower(note)
	var b strings.Builder
	for _, r := range s {
		for i, c := range cyr {
			if r == c {
				r = lat[i]
				break
			}
		}
		b.WriteRune(r)
	}
	slug := nonSlug.ReplaceAllString(b.String(), "-")
	slug = strings.Trim(slug, "-")
	if r := []rune(slug); len(r) > 40 {
		slug = string(r[:40])
	}
	return slug
}

// walkFiles обходит дерево: пропускает ссылки, слишком большие файлы и служебные суффиксы.
func walkFiles(root string, skipTop map[string]bool, visit func(p string, info fs.FileInfo) error) error {
	return filepath.WalkDir(root, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		rel, rerr := filepath.Rel(root, p)
		if rerr != nil || rel == "." {
			return nil
		}
		parts := strings.Split(rel, string(os.PathSeparator))
		if skipTop != nil && skipTop[parts[0]] && len(parts) == 1 {
			if d.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}
		for _, part := range parts {
			if part == "__pycache__" {
				if d.IsDir() {
					return filepath.SkipDir
				}
				return nil
			}
		}
		if strings.HasSuffix(d.Name(), ".tmp") || strings.HasSuffix(d.Name(), ".pyc") || strings.HasSuffix(d.Name(), ".lock") {
			return nil
		}
		info, err := os.Lstat(p)
		if err != nil || info.Mode()&fs.ModeSymlink != 0 {
			return nil
		}
		if info.Mode().IsRegular() && info.Size() > maxBackupFile {
			return nil
		}
		if !info.Mode().IsRegular() && !info.IsDir() {
			return nil
		}
		return visit(p, info)
	})
}

func addFile(tw *tar.Writer, p, name string, info fs.FileInfo) error {
	hdr, err := tar.FileInfoHeader(info, "")
	if err != nil {
		return err
	}
	hdr.Name = name
	if info.IsDir() {
		hdr.Name += "/"
	}
	if err := tw.WriteHeader(hdr); err != nil {
		return err
	}
	if !info.IsDir() {
		f, err := os.Open(p)
		if err != nil {
			return err
		}
		defer f.Close()
		_, err = io.Copy(tw, f)
		return err
	}
	return nil
}

// createBackup делает копию; возвращает имя, размер и число файлов.
func createBackup(home, kuniDir, note string, now time.Time) (map[string]any, error) {
	dir, err := backupsDir(home)
	if err != nil {
		return nil, err
	}
	slug := slugify(note)
	base := now.Format("20060102-150405")
	if slug != "" {
		base += "-" + slug
	}
	name := base + ".tar.gz"
	for n := 1; ; n++ {
		if _, err := os.Stat(filepath.Join(dir, name)); os.IsNotExist(err) {
			break
		}
		name = fmt.Sprintf("%s-%d.tar.gz", base, n)
	}
	out := filepath.Join(dir, name)
	f, err := os.OpenFile(out, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o600)
	if err != nil {
		return nil, err
	}
	gz := gzip.NewWriter(f)
	tw := tar.NewWriter(gz)
	files := 0
	err = walkFiles(home, homeSkip, func(p string, info fs.FileInfo) error {
		rel, _ := filepath.Rel(home, p)
		if info.Mode().IsRegular() {
			files++
		}
		return addFile(tw, p, "home/"+filepath.ToSlash(rel), info)
	})
	if err == nil && kuniDir != "" {
		for _, item := range kuniItems {
			src := filepath.Join(kuniDir, item)
			info, serr := os.Lstat(src)
			if serr != nil {
				continue
			}
			if info.Mode().IsRegular() {
				files++
				err = addFile(tw, src, "kuni/"+item, info)
			} else if info.IsDir() {
				err = addFile(tw, src, "kuni/"+item, info)
				if err == nil {
					err = walkFiles(src, nil, func(p string, fi fs.FileInfo) error {
						rel, _ := filepath.Rel(src, p)
						if fi.Mode().IsRegular() {
							files++
						}
						return addFile(tw, p, "kuni/"+item+"/"+filepath.ToSlash(rel), fi)
					})
				}
			}
			if err != nil {
				break
			}
		}
	}
	if err == nil {
		raw, _ := json.Marshal(map[string]any{"created": now.Unix(), "note": truncRunes(note, 200), "files": files, "kuni_dir": kuniDir, "format": 1})
		err = tw.WriteHeader(&tar.Header{Name: "manifest.json", Mode: 0o600, Size: int64(len(raw)), ModTime: now})
		if err == nil {
			_, err = tw.Write(raw)
		}
	}
	for _, closer := range []func() error{tw.Close, gz.Close, f.Close} {
		if cerr := closer(); cerr != nil && err == nil {
			err = cerr
		}
	}
	if err != nil {
		_ = os.Remove(out)
		return nil, err
	}
	_ = os.Chmod(out, 0o600)
	st, _ := os.Stat(out)
	return map[string]any{"name": name, "size": st.Size(), "files": files}, nil
}

func truncRunes(s string, n int) string {
	if r := []rune(s); len(r) > n {
		return string(r[:n])
	}
	return s
}

type backupItem struct {
	Name    string `json:"name"`
	Size    int64  `json:"size"`
	MTime   int64  `json:"mtime"`
	Created int64  `json:"created"`
	Note    string `json:"note"`
	Files   *int   `json:"files"`
}

func listBackups(home string) []backupItem {
	dir, err := backupsDir(home)
	if err != nil {
		return nil
	}
	entries, _ := os.ReadDir(dir)
	var names []string
	for _, e := range entries {
		if !e.IsDir() && backupNameRE.MatchString(e.Name()) {
			names = append(names, e.Name())
		}
	}
	sort.Sort(sort.Reverse(sort.StringSlice(names)))
	var out []backupItem
	for _, n := range names {
		p := filepath.Join(dir, n)
		st, err := os.Stat(p)
		if err != nil {
			continue
		}
		item := backupItem{Name: n, Size: st.Size(), MTime: st.ModTime().Unix(), Created: st.ModTime().Unix(), Note: ""}
		if m, err := readManifest(p); err == nil {
			if v, ok := m["note"].(string); ok {
				item.Note = v
			}
			if v, ok := m["files"].(float64); ok {
				n := int(v)
				item.Files = &n
			}
			if v, ok := m["created"].(float64); ok {
				item.Created = int64(v)
			}
		} else {
			item.Note = "(манифест не читается)"
		}
		out = append(out, item)
	}
	if out == nil {
		out = []backupItem{}
	}
	return out
}

func readManifest(p string) (map[string]any, error) {
	f, err := os.Open(p)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		return nil, err
	}
	defer gz.Close()
	tr := tar.NewReader(gz)
	for {
		hdr, err := tr.Next()
		if err != nil {
			return nil, err
		}
		if hdr.Name == "manifest.json" {
			var m map[string]any
			if err := json.NewDecoder(io.LimitReader(tr, 1<<20)).Decode(&m); err != nil {
				return nil, err
			}
			return m, nil
		}
	}
}

func checkBackupName(name string) error {
	if !backupNameRE.MatchString(name) {
		return errors.New("имя копии указано неверно")
	}
	return nil
}

func deleteBackup(home, name string) error {
	if err := checkBackupName(name); err != nil {
		return err
	}
	dir, _ := backupsDir(home)
	p := filepath.Join(dir, name)
	if st, err := os.Stat(p); err != nil || !st.Mode().IsRegular() {
		return fmt.Errorf("копии %s нет", name)
	}
	return os.Remove(p)
}

// pruneBackups оставляет последние keep копий (по времени создания из манифеста).
func pruneBackups(home string, keep int) int {
	items := listBackups(home)
	sort.SliceStable(items, func(i, j int) bool { return items[i].Created > items[j].Created })
	removed := 0
	for i := keep; i < len(items); i++ {
		if os.Remove(filepath.Join(home, "backups", items[i].Name)) == nil {
			removed++
		}
	}
	return removed
}

// restoreBackup восстанавливает копию; сначала сохраняет текущее состояние. Возвращает число файлов и имя страховой копии.
func restoreBackup(home, name, kuniDir string, now time.Time) (map[string]any, error) {
	if err := checkBackupName(name); err != nil {
		return nil, err
	}
	dir, _ := backupsDir(home)
	p := filepath.Join(dir, name)
	if st, err := os.Stat(p); err != nil || !st.Mode().IsRegular() {
		return nil, fmt.Errorf("копии %s нет", name)
	}
	safety, err := createBackup(home, kuniDir, "перед восстановлением", now)
	if err != nil {
		return nil, err
	}
	safetyName := safety["name"].(string)
	fail := func(msg string) error {
		return fmt.Errorf("%s: восстановление отменено (копия «%s» сохранена)", msg, safetyName)
	}
	// проверка всех путей до записи
	if err := walkArchive(p, func(hdr *tar.Header, _ io.Reader) error {
		if hdr.Name == "manifest.json" {
			return nil
		}
		clean := path.Clean(hdr.Name)
		parts := strings.Split(hdr.Name, "/")
		if strings.HasPrefix(hdr.Name, "/") || strings.Contains(hdr.Name, "..") || clean == "." || (parts[0] != "home" && parts[0] != "kuni") {
			return fail(fmt.Sprintf("в копии небезопасный путь %q", hdr.Name))
		}
		if hdr.Typeflag == tar.TypeSymlink || hdr.Typeflag == tar.TypeLink || hdr.Typeflag == tar.TypeChar || hdr.Typeflag == tar.TypeBlock {
			return fail(fmt.Sprintf("в копии небезопасный путь %q", hdr.Name))
		}
		return nil
	}); err != nil {
		return nil, err
	}
	n := 0
	err = walkArchive(p, func(hdr *tar.Header, body io.Reader) error {
		if hdr.Name == "manifest.json" {
			return nil
		}
		parts := strings.Split(strings.TrimSuffix(hdr.Name, "/"), "/")
		var root string
		switch {
		case parts[0] == "home":
			root = home
		case parts[0] == "kuni" && kuniDir != "" && len(parts) > 1 && inList(parts[1], kuniItems):
			root = kuniDir
		default:
			return nil
		}
		target := filepath.Join(append([]string{root}, parts[1:]...)...)
		if hdr.Typeflag == tar.TypeDir {
			return os.MkdirAll(target, 0o755)
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		tmp := target + ".tmp-zc"
		mode := fs.FileMode(hdr.Mode) & fs.ModePerm
		if mode == 0 {
			mode = 0o600
		}
		out, err := os.OpenFile(tmp, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, mode)
		if err != nil {
			return err
		}
		if _, err := io.Copy(out, body); err != nil {
			out.Close()
			return err
		}
		if err := out.Close(); err != nil {
			return err
		}
		if err := os.Rename(tmp, target); err != nil {
			return err
		}
		n++
		return nil
	})
	if err != nil {
		return nil, err
	}
	return map[string]any{"restored": n, "safety": safetyName}, nil
}

func inList(v string, list []string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

// walkArchive открывает tar.gz и вызывает fn для каждой записи.
func walkArchive(p string, fn func(*tar.Header, io.Reader) error) error {
	f, err := os.Open(p)
	if err != nil {
		return err
	}
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		return err
	}
	defer gz.Close()
	tr := tar.NewReader(gz)
	for {
		hdr, err := tr.Next()
		if errors.Is(err, io.EOF) {
			return nil
		}
		if err != nil {
			return err
		}
		if err := fn(hdr, tr); err != nil {
			return err
		}
	}
}

// backupDue — пора ли автоматической копии (последняя старше hours часов).
func backupDue(home string, hours int, now time.Time) bool {
	items := listBackups(home)
	if len(items) == 0 {
		return true
	}
	var newest int64
	for _, b := range items {
		if b.Created > newest {
			newest = b.Created
		}
	}
	return now.Unix()-newest >= int64(hours)*3600
}
