package panel

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// ---------- разговор: сообщение владельца, подтверждение, цикл ходов ----------

func (a *assistantState) message(text string) (map[string]any, error) {
	text = strings.TrimSpace(text)
	if text == "" {
		return nil, errors.New("пустое сообщение")
	}
	if len([]rune(text)) > 8000 {
		return nil, errors.New("сообщение длиннее 8000 символов")
	}
	return a.withLock(func(s map[string]any) error {
		for _, call := range listOf(s["queue"]) {
			appendMsg(s, map[string]any{"role": "tool", "tool_call_id": call["id"], "content": "Отменено: владелец написал новое сообщение, не дожидаясь."})
		}
		s["queue"] = []any{}
		s["pending"] = nil
		s["approved"] = []any{}
		appendMsg(s, map[string]any{"role": "user", "content": text})
		return nil
	})
}

func (a *assistantState) confirm(callID string, approve bool) (map[string]any, error) {
	return a.withLock(func(s map[string]any) error {
		p, _ := s["pending"].(map[string]any)
		if p == nil || toStr(p["id"]) != callID {
			return errors.New("это действие уже не ждёт подтверждения")
		}
		if approve {
			list, _ := s["approved"].([]any)
			s["approved"] = append(list, callID)
		} else {
			queue := listOf(s["queue"])
			if len(queue) > 0 {
				call := queue[0]
				s["queue"] = toAnySlice(queue[1:])
				appendMsg(s, map[string]any{"role": "tool", "tool_call_id": call["id"], "content": "Владелец отклонил это действие. Не повторяй его; предложи другой путь или спроси, что делать."})
			}
			f := false
			p2, _ := p["args"].(map[string]any)
			a.audit(toStr(p["tool"]), p2, false, "отклонено владельцем", &f)
		}
		s["pending"] = nil
		return nil
	})
}

func toAnySlice(list []map[string]any) []any {
	out := make([]any, 0, len(list))
	for _, m := range list {
		out = append(out, m)
	}
	return out
}

// withLock выполняет один ход разговора: подготовка сессии, цикл модели, сохранение. Одновременно — только один ход.
func (a *assistantState) withLock(prep func(map[string]any) error) (map[string]any, error) {
	if enabled, _ := a.settings()["enabled"].(bool); !enabled {
		return nil, errors.New("чат Марин выключен владельцем")
	}
	if !a.mu.TryLock() {
		return nil, errors.New("Марин ещё отвечает на прошлое сообщение")
	}
	defer a.mu.Unlock()
	a.busy.Store(true)
	defer a.busy.Store(false)
	a.canceled.Store(false)
	s := a.session()
	if err := prep(s); err != nil {
		return nil, err
	}
	if err := a.save(s); err != nil {
		return nil, err
	}
	res := a.run(s)
	if err := a.save(s); err != nil {
		return nil, err
	}
	res["state"] = a.stateFrom(s, false)
	return res, nil
}

func (a *assistantState) run(s map[string]any) map[string]any {
	maxSteps := a.intSetting("max_steps")
	steps := []map[string]any{}
	result := func(reply any, pending any, errText any) map[string]any {
		return map[string]any{"reply": reply, "pending": pending, "steps": steps, "error": errText}
	}
	creds, err := a.credsFn(a.s.kuniDir())
	if err != nil {
		return result(nil, nil, err.Error())
	}
	for i := 0; i <= maxSteps; i++ {
		if a.canceled.Load() {
			return result(nil, nil, "остановлено владельцем")
		}
		if p := a.drain(s, &steps); p != nil {
			return result(nil, p, nil)
		}
		if a.canceled.Load() {
			return result(nil, nil, "остановлено владельцем")
		}
		if rounds(msgsOf(s)) >= maxSteps {
			break
		}
		window := append([]map[string]any{{"role": "system", "content": a.systemPrompt()}}, windowOf(msgsOf(s))...)
		resp, err := a.llmFn(creds, window, toolDefs())
		if err != nil {
			return result(nil, nil, err.Error())
		}
		var cost *float64
		if f, ok := resp.Cost.(float64); ok {
			cost = &f
		}
		_ = recordUsage(a.s.M.Home, "panel_chat", resp.Model, resp.Prompt, resp.Compl, cost, "", a.now())
		content, _ := resp.Message["content"].(string)
		clean := map[string]any{"role": "assistant", "content": content}
		var calls []any
		for _, c := range listOf(resp.Message["tool_calls"]) {
			fn := callFunc(c)
			id, _ := c["id"].(string)
			if id == "" {
				id = "call_" + randHex(10)
			}
			argStr, ok := fn["arguments"].(string)
			if !ok {
				raw, _ := json.Marshal(fn["arguments"])
				argStr = string(raw)
				if argStr == "null" || argStr == "" {
					argStr = "{}"
				}
			}
			calls = append(calls, map[string]any{"id": id, "type": "function",
				"function": map[string]any{"name": toStr(fn["name"]), "arguments": argStr}})
		}
		if len(calls) > 0 {
			clean["tool_calls"] = calls
		}
		appendMsg(s, clean)
		if len(calls) == 0 {
			return result(content, nil, nil)
		}
		s["queue"] = calls
		_ = a.save(s)
	}
	return result(nil, nil, fmt.Sprintf("остановилась: достигнут предел в %d шагов подряд; напишите «продолжай», если нужно дальше", maxSteps))
}

// drain выполняет вызовы из очереди по порядку; если нужен ответ владельца, останавливается и возвращает ожидание.
func (a *assistantState) drain(s map[string]any, steps *[]map[string]any) map[string]any {
	for {
		queue := listOf(s["queue"])
		if len(queue) == 0 {
			return nil
		}
		call := queue[0]
		id := toStr(call["id"])
		fn := callFunc(call)
		name := toStr(fn["name"])
		argStr, _ := fn["arguments"].(string)
		if argStr == "" {
			argStr = "{}"
		}
		var args map[string]any
		if err := json.Unmarshal([]byte(argStr), &args); err != nil || args == nil {
			s["queue"] = toAnySlice(queue[1:])
			appendMsg(s, map[string]any{"role": "tool", "tool_call_id": id, "content": "ОШИБКА: аргументы не разобраны как JSON-объект"})
			continue
		}
		approved := false
		for _, x := range listOfStrings(s["approved"]) {
			if x == id {
				approved = true
			}
		}
		why := ""
		if !approved {
			why = a.needsConfirmation(name, args)
		}
		if why != "" {
			p := map[string]any{"id": id, "tool": name, "args": args, "why": why}
			s["pending"] = p
			_ = a.save(s)
			return p
		}
		if a.canceled.Load() {
			return nil
		}
		ok, result := a.execute(name, args)
		var conf *bool
		if approved {
			t := true
			conf = &t
		}
		a.audit(name, args, ok, result, conf)
		s["queue"] = toAnySlice(queue[1:])
		appendMsg(s, map[string]any{"role": "tool", "tool_call_id": id, "content": clip(result, outLimit+errLimit+200)})
		step := map[string]any{"tool": name, "args": args, "ok": ok, "result": clip(result, 400), "confirmed": nil}
		if conf != nil {
			step["confirmed"] = true
		}
		*steps = append(*steps, step)
		_ = a.save(s)
	}
}

func listOfStrings(v any) []string {
	raw, _ := v.([]any)
	out := make([]string, 0, len(raw))
	for _, x := range raw {
		if str, ok := x.(string); ok {
			out = append(out, str)
		}
	}
	return out
}

func rounds(msgs []map[string]any) int {
	n := 0
	for i := len(msgs) - 1; i >= 0; i-- {
		role := strOfMap(msgs[i], "role")
		if role == "user" {
			break
		}
		if role == "assistant" {
			n++
		}
	}
	return n
}

func windowOf(msgs []map[string]any) []map[string]any {
	if len(msgs) > maxHistory {
		msgs = msgs[len(msgs)-maxHistory:]
	}
	for len(msgs) > 0 && strOfMap(msgs[0], "role") != "user" {
		msgs = msgs[1:]
	}
	return msgs
}

func randHex(n int) string {
	b := make([]byte, (n+1)/2)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)[:n]
}

// systemPrompt — личность Марин из промптов бота и служебное дополнение панели.
func (a *assistantState) systemPrompt() string {
	kd := a.s.kuniDir()
	var parts []string
	for _, fn := range []string{"character_base.md", "character_appearance.md"} {
		if raw, err := os.ReadFile(filepath.Join(kd, "prompts", fn)); err == nil {
			parts = append(parts, truncRunes(string(raw), 6000))
		}
	}
	persona := strings.Join(parts, "\n\n")
	if persona == "" {
		persona = fallbackPersona
	}
	kdText := kd
	if kdText == "" {
		kdText = "не задан"
	}
	env := fmt.Sprintf("Сейчас %s. Домашний каталог ядра: %s. Каталог бота: %s.", a.now().Format("2006-01-02 15:04"), a.s.M.Home, kdText)
	return persona + "\n\n" + addendumText + "\n" + env
}
