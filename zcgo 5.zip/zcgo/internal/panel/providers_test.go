package panel

import (
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

const sampleToml = `
# комментарий
[general]
lockdown = "yes"

[general.llm]
model = "gpt-test" # модель
bearerKey = "секрет-не-показывать"

[general.llm.endpoint]
baseUrl = "https://openrouter.ai/api/v1/chat"
extra = [
  "a",
  "b",
]

[general.embedding]
model = 'emb-small'

[general.embedding.endpoint]
baseUrl = "http://127.0.0.1:11434/v1"
`

func TestTOMLSubset(t *testing.T) {
	d := parseTOML(sampleToml)
	g := d["general"].(map[string]any)
	llm := g["llm"].(map[string]any)
	if llm["model"] != "gpt-test" {
		t.Errorf("модель: %v", llm["model"])
	}
	if _, ok := llm["bearerKey"]; !ok {
		t.Error("разбор должен читать ключ, а отдавать его не должен: проверяет parseLLM")
	}
	if g["lockdown"] != "yes" {
		t.Errorf("lockdown: %v", g["lockdown"])
	}
	if _, ok := llm["extra"]; ok {
		t.Error("многострочный массив не должен попадать в результат")
	}
}

func TestParseLLMHidesKeysAndNamesProvider(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.toml")
	if err := os.WriteFile(path, []byte(sampleToml), 0o600); err != nil {
		t.Fatal(err)
	}
	out := parseLLM(path)
	raw, _ := json.Marshal(out)
	if strings.Contains(string(raw), "секрет") {
		t.Fatalf("ключ попал в ответ: %s", raw)
	}
	if out["provider"] != "openrouter" || out["host"] != "https://openrouter.ai" || out["model"] != "gpt-test" {
		t.Errorf("llm: %v", out)
	}
	if out["embedding_host"] != "http://127.0.0.1:11434" || out["provider"] != "openrouter" {
		t.Errorf("эмбеддинги: %v", out)
	}
	if missing := parseLLM(filepath.Join(dir, "nope.toml")); missing["available"] != false {
		t.Errorf("нет файла: %v", missing)
	}
}

func TestConsoleTimestampRollsBackAcrossMidnight(t *testing.T) {
	now := time.Date(2026, 10, 18, 0, 0, 30, 0, time.Local)
	ts, ok := parseConsoleTS("[23:59:50] строка", now)
	if !ok {
		t.Fatal("время не разобрано")
	}
	want := time.Date(2026, 10, 17, 23, 59, 50, 0, time.Local)
	if int64(ts) != want.Unix() {
		t.Errorf("полночь: %v вместо %v", time.Unix(int64(ts), 0), want)
	}
	if _, ok := parseConsoleTS("без времени", now); ok {
		t.Error("строка без времени не должна давать время")
	}
}

func TestStatsAndGenerationFromLogs(t *testing.T) {
	logs := t.TempDir()
	console := filepath.Join(t.TempDir(), "aui.log")
	_ = os.WriteFile(console, []byte(strings.Join([]string{
		"[10:00:00][tools::shell][WARN]: EXEC: ls",
		"[10:00:01][send_telegram_message][INFO]: Synthetic typing delay 2s",
		"[10:00:02][tools::external][INFO]: CALL weather",
		"tool call refused by guard",
		"[10:00:03][x][ERROR]: boom",
		"chatStreaming: status=HTTP_500",
	}, "\n")), 0o644)
	now := time.Now()
	today := now.Format("2006-01-02")
	_ = os.WriteFile(filepath.Join(logs, today+"_1_query.json"), []byte(`{"tools":[{"function":{"name":"b_tool","description":"d"}},{"function":{"name":"a_tool"}}]}`), 0o644)
	_ = os.WriteFile(filepath.Join(logs, today+"_1_response.json"), []byte(`{}`), 0o644)

	st := stats(logs, console, now)
	if st["shell_commands"] != 1 || st["messages_sent"] != 1 || st["external_calls"] != 1 || st["guard_refusals"] != 1 || st["errors"] != 1 || st["llm_http_errors"] != 1 || st["llm_requests_today"] != 1 {
		t.Errorf("статистика: %v", st)
	}
	tools := toolsFromQuery(logs, 120)
	if len(tools) != 2 || tools[0]["name"] != "a_tool" {
		t.Errorf("инструменты из журнала (по имени): %v", tools)
	}
	gen := generationState(logs, now)
	if gen["known"] != true || gen["active"] != false {
		t.Errorf("генерация: %v", gen)
	}
}

func TestHostMetricsAndSamplerKeepsRing(t *testing.T) {
	s := NewMetricsSampler("no-such-process")
	for i := 0; i < 130; i++ {
		s.SampleOnce(time.Unix(int64(i), 0))
	}
	if n := len(s.Points()); n != 120 {
		t.Errorf("кольцевой буфер: %d точек", n)
	}
	if h := hostMetrics(); h["cpus"] == nil {
		t.Error("нет числа процессоров")
	}
}

func TestLogAndMetricsRoutes(t *testing.T) {
	_, ts := newPanel(t)
	for _, path := range []string{"/api/system", "/api/activity", "/api/architecture", "/api/log?n=20", "/api/stats", "/api/tools", "/api/generation", "/api/llm", "/api/metrics"} {
		req, _ := http.NewRequest("GET", ts.URL+path, nil)
		req.Header.Set("X-Token", token)
		resp, err := ts.Client().Do(req)
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()
		if resp.StatusCode != 200 {
			t.Errorf("%s: %d", path, resp.StatusCode)
		}
	}
}
