// Помощники для модулей (порт sdk.py). Контракт среды: ZEROCORE_API, ZEROCORE_HOME, ZEROCORE_MODULE,
// ZEROCORE_DATA_DIR, ZEROCORE_STAGING (1 — проверочный запуск новой версии). Модули на любом языке читают те же переменные.
package sdk

import (
	"encoding/json"
	"os"
	"path/filepath"

	"zcgo/internal/kernel"
)

// DataDir — каталог данных модуля.
func DataDir() string { return os.Getenv("ZEROCORE_DATA_DIR") }

// ModuleName — имя модуля.
func ModuleName() string { return os.Getenv("ZEROCORE_MODULE") }

// IsStaging — проверочный запуск новой версии.
func IsStaging() bool { return os.Getenv("ZEROCORE_STAGING") == "1" }

// Publish публикует событие в шину ядра от имени модуля (home — каталог ядра).
func Publish(home, topic string, payload map[string]any) (int64, error) {
	if home == "" {
		home = os.Getenv("ZEROCORE_HOME")
	}
	if payload == nil {
		payload = map[string]any{}
	}
	return kernel.NewEventBus(filepath.Clean(home)).Publish(topic, payload, ModuleName())
}

// PublishJSON принимает полезную нагрузку строкой JSON (пустая строка — пустой объект).
func PublishJSON(home, topic, raw string) (int64, error) {
	payload := map[string]any{}
	if raw != "" {
		if err := json.Unmarshal([]byte(raw), &payload); err != nil {
			return 0, kernel.Newf(kernel.KindGeneric, "полезная нагрузка должна быть JSON-объектом: %v", err)
		}
	}
	return Publish(home, topic, payload)
}
