package sdk

import (
	"os"
	"testing"

	"zcgo/internal/kernel"
)

func TestContractVariablesAndPublish(t *testing.T) {
	home := t.TempDir()
	t.Setenv("ZEROCORE_MODULE", "demo_mod")
	t.Setenv("ZEROCORE_DATA_DIR", home+"/data/demo_mod")
	t.Setenv("ZEROCORE_STAGING", "1")
	if ModuleName() != "demo_mod" || DataDir() != home+"/data/demo_mod" || !IsStaging() {
		t.Fatal("переменные среды читаются неверно")
	}
	if _, err := PublishJSON(home, "demo.hello", `{"a":1}`); err != nil {
		t.Fatal(err)
	}
	evs, err := kernel.NewEventBus(home).Recent(5)
	if err != nil || len(evs) != 1 || evs[0].Producer != "demo_mod" || evs[0].Topic != "demo.hello" {
		t.Fatalf("событие: %+v %v", evs, err)
	}
	if _, err := PublishJSON(home, "bad", `[1]`); err == nil {
		t.Error("нагрузка не объект должна отклоняться")
	}
	t.Setenv("ZEROCORE_STAGING", "")
	if IsStaging() {
		t.Error("без переменной staging выключен")
	}
	_ = os.Getenv
}
