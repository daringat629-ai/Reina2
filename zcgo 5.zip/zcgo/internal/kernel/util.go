package kernel

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func sprintf(format string, args ...any) string { return fmt.Sprintf(format, args...) }

func containsAny(s, chars string) bool { return strings.ContainsAny(s, chars) }

func splitSlash(s string) []string { return strings.Split(s, "/") }

func hasSuffix(s, suf string) bool { return strings.HasSuffix(s, suf) }

func contains(list []string, v string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

// stringsOf возвращает строки из []any (для уже проверенных полей).
func stringsOf(v any) []string {
	l, ok := asList(v)
	if !ok {
		return nil
	}
	out := make([]string, 0, len(l))
	for _, x := range l {
		if s, ok := asStr(x); ok {
			out = append(out, s)
		}
	}
	return out
}

// AtomicWrite пишет файл через временный и rename.
func AtomicWrite(path string, data []byte, perm os.FileMode) error {
	tmp := filepath.Join(filepath.Dir(path), "."+filepath.Base(path)+fmt.Sprintf(".tmp%d", os.Getpid()))
	if err := os.WriteFile(tmp, data, perm); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// Realpath как os.path.realpath: существующая часть разрешается по симлинкам, несуществующий хвост добавляется как есть.
func Realpath(p string) string {
	abs, err := filepath.Abs(p)
	if err != nil {
		return p
	}
	var rest []string
	cur := abs
	for {
		if r, err := filepath.EvalSymlinks(cur); err == nil {
			return filepath.Join(append([]string{r}, reverse(rest)...)...)
		}
		parent := filepath.Dir(cur)
		if parent == cur {
			return abs
		}
		rest = append(rest, filepath.Base(cur))
		cur = parent
	}
}

func reverse(s []string) []string {
	out := make([]string, len(s))
	for i, v := range s {
		out[len(s)-1-i] = v
	}
	return out
}

// Inside сообщает, лежит ли target внутри base (после разрешения ссылок).
func Inside(base, target string) bool {
	b, t := Realpath(base), Realpath(target)
	return t == b || strings.HasPrefix(t, b+string(filepath.Separator))
}
