package kernel

import (
	"context"
	"net/http"
	"os"
	"os/exec"
	"time"
)

// Проверки состояния модулей. Состояния: healthy, unhealthy, stopped, unknown.

// Health — результат проверки.
type Health struct {
	State  string
	Detail string
}

func str(spec map[string]any, key string) string {
	s, _ := spec[key].(string)
	return s
}

func numOr(spec map[string]any, key string, def int) int {
	if n, ok := asInt(spec[key]); ok {
		return n
	}
	return def
}

// CheckHealth выполняет проверку по спецификации health из манифеста.
// now — момент отсчёта (для file_fresh и job), interval — расписание задачи в секундах.
func CheckHealth(spec map[string]any, runner *ProcessRunner, name, suffix string, runtime map[string]any, now time.Time, interval int) Health {
	t, _ := spec["type"].(string)
	if t == "" {
		t = "none"
	}
	switch t {
	case "none":
		return Health{"unknown", "проверка не настроена"}
	case "process":
		if runner != nil {
			if _, ok := runner.Pid(name, suffix); ok {
				return Health{State: "healthy"}
			}
		}
		return Health{"stopped", "процесса нет"}
	case "pgrep":
		proc := str(spec, "process")
		if runRC([]string{"pgrep", "-x", proc}, 5*time.Second) == 0 {
			return Health{State: "healthy"}
		}
		return Health{"stopped", "процесс " + proc + " не найден"}
	case "command":
		argv := stringsOf(spec["command"])
		rc := runRC(argv, time.Duration(numOr(spec, "timeout", 5))*time.Second)
		if rc == 0 {
			return Health{State: "healthy"}
		}
		return Health{"unhealthy", "команда проверки завершилась кодом " + itoa(rc)}
	case "http":
		timeout := time.Duration(numOr(spec, "timeout", 2)) * time.Second
		client := &http.Client{Timeout: timeout}
		resp, err := client.Get(str(spec, "url"))
		if err != nil {
			return Health{"unhealthy", "HTTP недоступен: " + err.Error()}
		}
		defer resp.Body.Close()
		if resp.StatusCode >= 200 && resp.StatusCode < 400 {
			return Health{State: "healthy"}
		}
		return Health{"unhealthy", "HTTP " + itoa(resp.StatusCode)}
	case "file_fresh":
		st, err := os.Stat(str(spec, "path"))
		if err != nil {
			return Health{"unhealthy", "файл не найден"}
		}
		age := now.Sub(st.ModTime()).Seconds()
		if age > float64(numOr(spec, "max_age_seconds", 0)) {
			return Health{"unhealthy", "файл не обновлялся " + itoa(int(age)) + " с"}
		}
		return Health{State: "healthy"}
	case "job":
		last, has := runtime["last_run"]
		if !has {
			return Health{"unknown", "ещё не запускалась"}
		}
		lastF, _ := last.(float64)
		if rc, ok := runtime["last_rc"]; ok && rc != nil {
			if n, _ := asInt(rc); n != 0 {
				return Health{"unhealthy", "последний запуск завершился кодом " + itoa(n)}
			}
		}
		if interval > 0 && float64(now.UnixNano())/1e9-lastF > float64(interval*3+5) {
			return Health{"unhealthy", "задача давно не выполнялась"}
		}
		return Health{State: "healthy"}
	}
	return Health{"unknown", "неизвестный тип проверки " + t}
}

func runRC(argv []string, timeout time.Duration) int {
	if len(argv) == 0 {
		return -1
	}
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, argv[0], argv[1:]...)
	if err := cmd.Run(); err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return ee.ExitCode()
		}
		return -1
	}
	return 0
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	neg := n < 0
	if neg {
		n = -n
	}
	var b []byte
	for n > 0 {
		b = append([]byte{byte('0' + n%10)}, b...)
		n /= 10
	}
	if neg {
		b = append([]byte{'-'}, b...)
	}
	return string(b)
}
