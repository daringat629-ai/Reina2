package kernel

import (
	"path/filepath"
)

// ResolveDataPath — путь внутри каталога данных модуля. Выход за пределы (в том числе через симлинк) — ошибка.
func ResolveDataPath(home, module, rel string) (string, error) {
	base := filepath.Join(home, "data", module)
	target := filepath.Join(base, rel)
	if !Inside(base, target) {
		return "", Newf(KindPermission, "%s: путь %q выходит за пределы каталога данных", module, rel)
	}
	return target, nil
}

// ResolveSharedPath — чтение shared/ другого модуля только при объявленном праве read на его возможности.
func ResolveSharedPath(home string, reader, owner *Manifest, rel string) (string, error) {
	allowed := false
	for _, p := range permissionList(reader, "read") {
		if contains(owner.Provides, p) {
			allowed = true
		}
	}
	if !allowed {
		return "", Newf(KindPermission, "%s не объявил право read на возможности модуля %s", reader.Name, owner.Name)
	}
	base := filepath.Join(home, "data", owner.Name, "shared")
	target := filepath.Join(base, rel)
	if !Inside(base, target) {
		return "", Newf(KindPermission, "%s: путь %q выходит за пределы shared/ модуля %s", reader.Name, rel, owner.Name)
	}
	return target, nil
}

func permissionList(m *Manifest, key string) []string {
	v, ok := m.Permissions[key]
	if !ok {
		return nil
	}
	return stringsOf(v)
}
