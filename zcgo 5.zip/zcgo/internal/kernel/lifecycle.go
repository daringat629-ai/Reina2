package kernel

import (
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

// Запуск и остановка процессов модулей. Своя группа процессов, SIGTERM, затем SIGKILL, без фоновых хвостов.

// WaitUntil ждёт, пока predicate станет истиной, до timeout.
func WaitUntil(predicate func() bool, timeout time.Duration) bool {
	end := time.Now().Add(timeout)
	for time.Now().Before(end) {
		if predicate() {
			return true
		}
		time.Sleep(50 * time.Millisecond)
	}
	return predicate()
}

type child struct {
	cmd  *exec.Cmd
	done chan struct{}
}

// ProcessRunner ведёт pid-файлы и процессы модулей в каталоге run.
type ProcessRunner struct {
	RunDir   string
	mu       sync.Mutex
	children map[int]*child
}

// NewProcessRunner создаёт каталог run при необходимости.
func NewProcessRunner(runDir string) (*ProcessRunner, error) {
	if err := os.MkdirAll(runDir, 0o755); err != nil {
		return nil, err
	}
	return &ProcessRunner{RunDir: runDir, children: map[int]*child{}}, nil
}

func (r *ProcessRunner) pidfile(name, suffix string) string {
	return filepath.Join(r.RunDir, name+suffix+".pid")
}

func (r *ProcessRunner) logfile(name string) string {
	return filepath.Join(r.RunDir, name+".log")
}

func (r *ProcessRunner) alive(pid int) bool {
	r.mu.Lock()
	c := r.children[pid]
	r.mu.Unlock()
	if c != nil {
		select {
		case <-c.done:
			return false
		default:
			return true
		}
	}
	if err := syscall.Kill(pid, 0); err != nil {
		return err == syscall.EPERM
	}
	if raw, err := os.ReadFile(fmt.Sprintf("/proc/%d/stat", pid)); err == nil {
		s := string(raw)
		if i := strings.LastIndex(s, ")"); i >= 0 && len(s) > i+2 && s[i+2] == 'Z' {
			return false
		}
	}
	return true
}

// Pid возвращает pid живого процесса или false; протухший pid-файл удаляется.
func (r *ProcessRunner) Pid(name, suffix string) (int, bool) {
	raw, err := os.ReadFile(r.pidfile(name, suffix))
	if err != nil {
		return 0, false
	}
	pid, err := strconv.Atoi(strings.TrimSpace(string(raw)))
	if err == nil && r.alive(pid) {
		return pid, true
	}
	r.mu.Lock()
	delete(r.children, pid)
	r.mu.Unlock()
	_ = os.Remove(r.pidfile(name, suffix))
	return 0, false
}

// Start запускает процесс. limits: memory_mb, cpu_seconds, open_files (через ulimit в оболочке).
func (r *ProcessRunner) Start(name string, argv []string, cwd string, env []string, limits map[string]int, suffix string) (int, error) {
	if _, ok := r.Pid(name, suffix); ok {
		return 0, Newf(KindLifecycle, "%s: уже запущен", name)
	}
	if len(argv) == 0 {
		return 0, Newf(KindLifecycle, "%s: пустая команда", name)
	}
	args := argv
	if len(limits) > 0 {
		var parts []string
		if v, ok := limits["memory_mb"]; ok {
			parts = append(parts, fmt.Sprintf("ulimit -v %d", v*1024))
		}
		if v, ok := limits["cpu_seconds"]; ok {
			parts = append(parts, fmt.Sprintf("ulimit -t %d", v))
		}
		if v, ok := limits["open_files"]; ok {
			parts = append(parts, fmt.Sprintf("ulimit -n %d", v))
		}
		parts = append(parts, `exec "$@"`)
		args = append([]string{"/bin/sh", "-c", strings.Join(parts, "; "), "zerocore"}, argv...)
	}
	log, err := os.OpenFile(r.logfile(name), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return 0, err
	}
	defer log.Close()
	cmd := exec.Command(args[0], args[1:]...)
	cmd.Dir = cwd
	cmd.Env = env
	cmd.Stdin = nil
	cmd.Stdout = log
	cmd.Stderr = log
	cmd.SysProcAttr = &syscall.SysProcAttr{Setsid: true}
	if err := cmd.Start(); err != nil {
		return 0, Newf(KindLifecycle, "%s: не удалось запустить %s: %v", name, argv[0], err)
	}
	c := &child{cmd: cmd, done: make(chan struct{})}
	go func() {
		_ = cmd.Wait()
		close(c.done)
	}()
	r.mu.Lock()
	r.children[cmd.Process.Pid] = c
	r.mu.Unlock()
	if err := os.WriteFile(r.pidfile(name, suffix), []byte(strconv.Itoa(cmd.Process.Pid)), 0o644); err != nil {
		return 0, err
	}
	return cmd.Process.Pid, nil
}

// Stop останавливает группу процессов: SIGTERM, ожидание, SIGKILL. Возвращает "not_running", "graceful" или "killed".
func (r *ProcessRunner) Stop(name string, timeout time.Duration, suffix string) (string, error) {
	pid, ok := r.Pid(name, suffix)
	if !ok {
		return "not_running", nil
	}
	result := "graceful"
	_ = syscall.Kill(-pid, syscall.SIGTERM)
	if !WaitUntil(func() bool { return !r.alive(pid) }, timeout) {
		result = "killed"
		_ = syscall.Kill(-pid, syscall.SIGKILL)
		if !WaitUntil(func() bool { return !r.alive(pid) }, 5*time.Second) {
			return "", Newf(KindLifecycle, "%s: процесс %d не завершился даже после SIGKILL", name, pid)
		}
	}
	r.mu.Lock()
	delete(r.children, pid)
	r.mu.Unlock()
	_ = os.Remove(r.pidfile(name, suffix))
	return result, nil
}

// Promote переносит pid-файл одного суффикса на другой (после горячей замены).
func (r *ProcessRunner) Promote(name, fromSuffix, toSuffix string) error {
	return os.Rename(r.pidfile(name, fromSuffix), r.pidfile(name, toSuffix))
}

// LogTail возвращает последние n байт лога модуля.
func (r *ProcessRunner) LogTail(name string, n int) string {
	f, err := os.Open(r.logfile(name))
	if err != nil {
		return ""
	}
	defer f.Close()
	st, err := f.Stat()
	if err != nil {
		return ""
	}
	off := st.Size() - int64(n)
	if off < 0 {
		off = 0
	}
	_, _ = f.Seek(off, io.SeekStart)
	buf, _ := io.ReadAll(f)
	return strings.ToValidUTF8(string(buf), "")
}
