package kernel

import (
	"regexp"
	"strconv"
	"strings"
)

var consRE = regexp.MustCompile(`^(==|>=|<=|>|<|!=)\s*(\d+(\.\d+){0,2})$`)

// ParseVersion превращает "1.2" в [1 2 0].
func ParseVersion(v string) ([3]int, error) {
	var out [3]int
	parts := strings.Split(v, ".")
	for i, p := range parts {
		n, err := strconv.Atoi(p)
		if err != nil || i > 2 {
			return out, Newf(KindContract, "неверная версия: %q", v)
		}
		out[i] = n
	}
	return out, nil
}

func cmpVersion(a, b [3]int) int {
	for i := 0; i < 3; i++ {
		if a[i] != b[i] {
			if a[i] < b[i] {
				return -1
			}
			return 1
		}
	}
	return 0
}

// Satisfies проверяет версию по ограничению вида ">=1.2,<2" (как contracts.satisfies).
func Satisfies(version, constraint string) (bool, error) {
	a, err := ParseVersion(version)
	if err != nil {
		return false, err
	}
	for _, part := range strings.Split(constraint, ",") {
		m := consRE.FindStringSubmatch(strings.TrimSpace(part))
		if m == nil {
			return false, Newf(KindContract, "неверное ограничение версии: %q", constraint)
		}
		b, err := ParseVersion(m[2])
		if err != nil {
			return false, err
		}
		c := cmpVersion(a, b)
		ok := map[string]bool{"==": c == 0, ">=": c >= 0, "<=": c <= 0, ">": c > 0, "<": c < 0, "!=": c != 0}[m[1]]
		if !ok {
			return false, nil
		}
	}
	return true, nil
}
