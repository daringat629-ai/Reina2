package kernel

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"syscall"
	"time"
)

// Единый менеджер транзакций конфигурации. Все изменения системы идут через RunTxn:
//  1. блокировка flock (одновременные изменения выстраиваются в очередь);
//  2) журнал отката пишется до изменений: если процесс умер посреди операции, при следующем входе всё откатывается;
//  3) при ошибке (или панике) откат состояния и всех зарегистрированных действий в обратном порядке.

// FileStore — файл состояния (JSON), с атомарной записью.
type FileStore struct {
	Path    string
	Default string // JSON по умолчанию, если файла нет
}

// Snapshot возвращает байты состояния (или значение по умолчанию).
func (s *FileStore) Snapshot() ([]byte, error) {
	raw, err := os.ReadFile(s.Path)
	if os.IsNotExist(err) {
		if s.Default == "" {
			return []byte("{}"), nil
		}
		return []byte(s.Default), nil
	}
	return raw, err
}

// Restore записывает байты состояния атомарно.
func (s *FileStore) Restore(raw []byte) error {
	return AtomicWrite(s.Path, raw, 0o644)
}

// Load читает состояние в v.
func (s *FileStore) Load(v any) error {
	raw, err := s.Snapshot()
	if err != nil {
		return err
	}
	if err := json.Unmarshal(raw, v); err != nil {
		return json.Unmarshal([]byte(s.defaultOrEmpty()), v)
	}
	return nil
}

func (s *FileStore) defaultOrEmpty() string {
	if s.Default == "" {
		return "{}"
	}
	return s.Default
}

// Save записывает v как JSON с отступом (как indent=1, sort_keys в Python).
func (s *FileStore) Save(v any) error {
	raw, err := json.MarshalIndent(v, "", " ")
	if err != nil {
		return err
	}
	return s.Restore(raw)
}

// Txn — открытая транзакция.
type Txn struct {
	home     string
	label    string
	store    *FileStore
	lockFile *os.File
	stateRaw []byte
	undo     [][]any
	journal  string
}

// JournalPath — файл журнала отката.
func JournalPath(home string) string { return filepath.Join(home, "txn.journal.json") }

func acquire(home string, timeout time.Duration) (*os.File, error) {
	if err := os.MkdirAll(home, 0o755); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(filepath.Join(home, "config.lock"), os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		return nil, err
	}
	end := time.Now().Add(timeout)
	for {
		err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB)
		if err == nil {
			return f, nil
		}
		if time.Now().After(end) {
			f.Close()
			return nil, Newf(KindTxn, "не удалось получить блокировку конфигурации за %s", timeout)
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func release(f *os.File) {
	_ = syscall.Flock(int(f.Fd()), syscall.LOCK_UN)
	f.Close()
}

func doUndo(action []any) {
	if len(action) == 0 {
		return
	}
	kind, _ := action[0].(string)
	arg := func(i int) string {
		if i < len(action) {
			if s, ok := action[i].(string); ok {
				return s
			}
		}
		return ""
	}
	switch kind {
	case "rm":
		_ = os.Remove(arg(1))
	case "rmtree":
		_ = os.RemoveAll(arg(1))
	case "mv":
		if _, err := os.Lstat(arg(1)); err == nil {
			_ = os.MkdirAll(filepath.Dir(arg(2)), 0o755)
			_ = os.Rename(arg(1), arg(2))
		}
	case "symlink":
		link, target := arg(1), arg(2)
		if _, err := os.Lstat(link); err == nil {
			_ = os.Remove(link)
		}
		if target != "" {
			_ = os.Symlink(target, link)
		}
	case "restore_file":
		path := arg(1)
		if len(action) < 3 || action[2] == nil {
			_ = os.Remove(path)
		} else if content, ok := action[2].(string); ok {
			_ = AtomicWrite(path, []byte(content), 0o644)
		}
	}
}

type journalDoc struct {
	Label       string          `json:"label"`
	PID         int             `json:"pid"`
	TS          float64         `json:"ts"`
	StateBefore json.RawMessage `json:"state_before"`
	Undo        [][]any         `json:"undo"`
}

func (t *Txn) writeJournal() error {
	doc := journalDoc{Label: t.label, PID: os.Getpid(), TS: float64(time.Now().UnixNano()) / 1e9,
		StateBefore: t.stateRaw, Undo: t.undo}
	raw, err := json.Marshal(doc)
	if err != nil {
		return err
	}
	return AtomicWrite(t.journal, raw, 0o644)
}

// AddUndo регистрирует действие отката (до того, как оно выполнено).
func (t *Txn) AddUndo(action ...any) error {
	t.undo = append(t.undo, action)
	return t.writeJournal()
}

// recoverLocked откатывает операцию, прерванную смертью процесса. Вызывать под блокировкой.
func recoverLocked(home string, store *FileStore) (bool, error) {
	journal := JournalPath(home)
	raw, err := os.ReadFile(journal)
	if os.IsNotExist(err) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	var doc journalDoc
	if err := json.Unmarshal(raw, &doc); err != nil {
		_ = os.Remove(journal)
		return false, nil
	}
	for i := len(doc.Undo) - 1; i >= 0; i-- {
		doUndo(doc.Undo[i])
	}
	if len(doc.StateBefore) > 0 {
		if err := store.Restore(doc.StateBefore); err != nil {
			return false, err
		}
	}
	_ = os.Remove(journal)
	return true, nil
}

// RunTxn выполняет fn внутри транзакции. Ошибка или паника в fn откатывает всё, что успели зарегистрировать.
func RunTxn(home, label string, store *FileStore, timeout time.Duration, fn func(t *Txn) error) (err error) {
	lock, err := acquire(home, timeout)
	if err != nil {
		return err
	}
	defer release(lock)
	if _, err := recoverLocked(home, store); err != nil {
		return err
	}
	before, err := store.Snapshot()
	if err != nil {
		return err
	}
	t := &Txn{home: home, label: label, store: store, lockFile: lock, stateRaw: before, journal: JournalPath(home)}
	if err := t.writeJournal(); err != nil {
		return err
	}
	committed := false
	defer func() {
		if committed {
			return
		}
		r := recover()
		for i := len(t.undo) - 1; i >= 0; i-- {
			doUndo(t.undo[i])
		}
		_ = store.Restore(before)
		_ = os.Remove(t.journal)
		if r != nil {
			panic(r)
		}
	}()
	if err = fn(t); err != nil {
		return err
	}
	committed = true
	if err := os.Remove(t.journal); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("%s: %w", label, err)
	}
	return nil
}

// Recover — вызывается при старте: откатывает операцию, прерванную смертью процесса.
func Recover(home string, store *FileStore) (bool, error) {
	if _, err := os.Stat(JournalPath(home)); os.IsNotExist(err) {
		return false, nil
	}
	lock, err := acquire(home, 30*time.Second)
	if err != nil {
		return false, err
	}
	defer release(lock)
	return recoverLocked(home, store)
}
