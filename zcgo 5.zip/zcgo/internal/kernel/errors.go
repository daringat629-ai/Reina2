// Package kernel — контракт модуля, шина событий, транзакции конфигурации, процессы, проверки здоровья,
// реестр возможностей и изоляция данных. Порт zero_core/zerocore/kernel.
package kernel

import (
	"errors"
	"fmt"
)

// Виды ошибок (как классы исключений в Python-версии).
const (
	KindGeneric    = "error"
	KindContract   = "contract"
	KindDependency = "dependency"
	KindConflict   = "conflict"
	KindPermission = "permission"
	KindLifecycle  = "lifecycle"
	KindTxn        = "txn"
)

// Error — ошибка ядра. Любая ошибка модуля или менеджера не должна валить ядро.
type Error struct {
	Kind string
	Msg  string
}

func (e *Error) Error() string { return e.Msg }

// Newf создаёт ошибку заданного вида.
func Newf(kind, format string, args ...any) error {
	return &Error{Kind: kind, Msg: fmt.Sprintf(format, args...)}
}

// Is сообщает, является ли err ошибкой заданного вида.
func Is(err error, kind string) bool {
	var e *Error
	return errors.As(err, &e) && e.Kind == kind
}
