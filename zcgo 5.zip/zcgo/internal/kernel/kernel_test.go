package kernel

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func mustManifest(t *testing.T, doc string) *Manifest {
	t.Helper()
	var raw map[string]any
	if err := json.Unmarshal([]byte(doc), &raw); err != nil {
		t.Fatal(err)
	}
	m, err := FromRaw(raw)
	if err != nil {
		t.Fatalf("манифест должен быть корректен: %v", err)
	}
	return m
}

func TestValidMinimalManifest(t *testing.T) {
	mustManifest(t, `{"api":"1","name":"demo_tools","version":"1.2.3","kind":"library","provides":["demo.tools"]}`)
}

func TestInvalidManifests(t *testing.T) {
	bad := map[string]string{
		"лишнее поле":            `{"api":"1","name":"demo_tools","version":"1","kind":"library","zzz":1}`,
		"плохой api":             `{"api":"2","name":"demo_tools","version":"1","kind":"library"}`,
		"плохое имя":             `{"api":"1","name":"Demo","version":"1","kind":"library"}`,
		"плохой kind":            `{"api":"1","name":"demo_tools","version":"1","kind":"daemon"}`,
		"service без command":    `{"api":"1","name":"demo_tools","version":"1","kind":"service"}`,
		"optional и required":    `{"api":"1","name":"a_mod","version":"1","kind":"library","requires":["x.y"],"optional_requires":["x.y"]}`,
		"неизвестный ключ патча": `{"api":"1","name":"a_mod","version":"1","kind":"library","patches":[{"key":"bogus","id":"p1"}]}`,
		"required без параметра": `{"api":"1","name":"a_mod","version":"1","kind":"library","tools":[{"name":"x_y","description":"d","parameters":{},"required":["q"],"command":["true"]}]}`,
	}
	for why, doc := range bad {
		var raw map[string]any
		_ = json.Unmarshal([]byte(doc), &raw)
		if errs := ValidateManifest(raw); len(errs) == 0 {
			t.Errorf("должна быть ошибка: %s", why)
		}
	}
}

func TestSatisfies(t *testing.T) {
	cases := []struct {
		v, c string
		want bool
	}{{"1.2.0", ">=1.2,<2", true}, {"2.0", "<2", false}, {"1.0", "==1", true}, {"1.1", "!=1.1", false}}
	for _, c := range cases {
		got, err := Satisfies(c.v, c.c)
		if err != nil || got != c.want {
			t.Errorf("Satisfies(%s,%s)=%v,%v want %v", c.v, c.c, got, err, c.want)
		}
	}
	if _, err := Satisfies("1", "~1"); err == nil {
		t.Error("неверное ограничение должно давать ошибку")
	}
}

func TestRegistryDuplicateCapability(t *testing.T) {
	a := mustManifest(t, `{"api":"1","name":"mod_one","version":"1","kind":"library","provides":["x.cap"]}`)
	b := mustManifest(t, `{"api":"1","name":"mod_two","version":"1","kind":"library","provides":["x.cap"]}`)
	if _, err := NewRegistry(map[string]*Manifest{"mod_one": a, "mod_two": b}); !Is(err, KindConflict) {
		t.Fatalf("ожидали конфликт возможностей, получили %v", err)
	}
}

func TestEventBusCursorAndLimits(t *testing.T) {
	bus := NewEventBus(t.TempDir())
	bus.MaxEvents = 5
	for i := 0; i < 8; i++ {
		if _, err := bus.Publish("t.one", map[string]any{"i": i}, "test"); err != nil {
			t.Fatal(err)
		}
	}
	first, _ := bus.Poll("c1", nil, 100, true)
	if len(first) != 5 {
		t.Fatalf("очередь должна быть ограничена 5 событиями, получено %d", len(first))
	}
	again, _ := bus.Poll("c1", nil, 100, true)
	if len(again) != 0 {
		t.Fatalf("повторной выдачи быть не должно, получено %d", len(again))
	}
	_, _ = bus.Publish("other.x", nil, "test")
	filtered, _ := bus.Poll("c2", []string{"other."}, 100, true)
	if len(filtered) != 1 || filtered[0].Topic != "other.x" {
		t.Fatalf("фильтр по теме: %+v", filtered)
	}
	big := strings.Repeat("я", MaxPayload)
	if _, err := bus.Publish("big", map[string]any{"s": big}, "test"); err == nil {
		t.Fatal("слишком большая нагрузка должна отклоняться")
	}
}

func TestTxnRollsBackOnError(t *testing.T) {
	home := t.TempDir()
	store := &FileStore{Path: filepath.Join(home, "state.json"), Default: `{"v":1}`}
	target := filepath.Join(home, "target.txt")
	if err := os.WriteFile(target, []byte("old"), 0o644); err != nil {
		t.Fatal(err)
	}
	err := RunTxn(home, "fail", store, time.Second, func(tx *Txn) error {
		_ = tx.AddUndo("restore_file", target, "old")
		_ = os.WriteFile(target, []byte("new"), 0o644)
		_ = store.Save(map[string]any{"v": 2})
		return Newf(KindGeneric, "сбой")
	})
	if err == nil {
		t.Fatal("ожидали ошибку")
	}
	if raw, _ := os.ReadFile(target); string(raw) != "old" {
		t.Errorf("файл не откатан: %q", raw)
	}
	if raw, _ := os.ReadFile(store.Path); !strings.Contains(string(raw), `"v": 1`) && !strings.Contains(string(raw), `"v":1`) {
		t.Errorf("состояние не откатано: %s", raw)
	}
	if _, err := os.Stat(JournalPath(home)); !os.IsNotExist(err) {
		t.Error("журнал должен быть удалён")
	}
}

func TestTxnRecoveryAfterCrash(t *testing.T) {
	home := t.TempDir()
	store := &FileStore{Path: filepath.Join(home, "state.json"), Default: `{}`}
	target := filepath.Join(home, "f.txt")
	_ = os.WriteFile(target, []byte("changed"), 0o644)
	// имитация смерти процесса: журнал есть, фиксации нет
	journal := `{"label":"x","pid":1,"ts":0,"state_before":{"modules":{}},"undo":[["restore_file","` + target + `","original"]]}`
	if err := os.WriteFile(JournalPath(home), []byte(journal), 0o644); err != nil {
		t.Fatal(err)
	}
	rec, err := Recover(home, store)
	if err != nil || !rec {
		t.Fatalf("восстановление: %v %v", rec, err)
	}
	if raw, _ := os.ReadFile(target); string(raw) != "original" {
		t.Errorf("откат после сбоя не выполнен: %q", raw)
	}
}

func TestDataPathsAreContained(t *testing.T) {
	home := t.TempDir()
	if _, err := ResolveDataPath(home, "mod", "../../etc/passwd"); !Is(err, KindPermission) {
		t.Errorf("выход за пределы должен запрещаться: %v", err)
	}
	outside := t.TempDir()
	if err := os.MkdirAll(filepath.Join(home, "data", "mod"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(outside, filepath.Join(home, "data", "mod", "link")); err != nil {
		t.Fatal(err)
	}
	if _, err := ResolveDataPath(home, "mod", "link/secret.txt"); !Is(err, KindPermission) {
		t.Errorf("симлинк наружу должен запрещаться: %v", err)
	}
	if _, err := ResolveDataPath(home, "mod", "notes/a.txt"); err != nil {
		t.Errorf("обычный путь должен проходить: %v", err)
	}
}

func TestProcessStartStopAndStalePidfile(t *testing.T) {
	runDir := t.TempDir()
	r, err := NewProcessRunner(runDir)
	if err != nil {
		t.Fatal(err)
	}
	pid, err := r.Start("svc", []string{"sleep", "30"}, runDir, os.Environ(), nil, "")
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := r.Pid("svc", ""); !ok {
		t.Fatal("процесс должен быть жив")
	}
	if _, err := r.Start("svc", []string{"sleep", "30"}, runDir, os.Environ(), nil, ""); !Is(err, KindLifecycle) {
		t.Errorf("повторный запуск должен отказывать: %v", err)
	}
	res, err := r.Stop("svc", 5*time.Second, "")
	if err != nil || res != "graceful" {
		t.Fatalf("остановка: %s %v", res, err)
	}
	if _, ok := r.Pid("svc", ""); ok {
		t.Errorf("процесс %d не должен числиться живым", pid)
	}
	// протухший pid-файл убирается
	_ = os.WriteFile(filepath.Join(runDir, "ghost.pid"), []byte("999999"), 0o644)
	if _, ok := r.Pid("ghost", ""); ok {
		t.Error("протухший pid не должен считаться запущенным")
	}
	if _, err := os.Stat(filepath.Join(runDir, "ghost.pid")); !os.IsNotExist(err) {
		t.Error("протухший pid-файл должен удаляться")
	}
}

func TestMissingExecutableIsLifecycleError(t *testing.T) {
	r, _ := NewProcessRunner(t.TempDir())
	if _, err := r.Start("nope", []string{"/no/such/program"}, t.TempDir(), os.Environ(), nil, ""); !Is(err, KindLifecycle) {
		t.Errorf("ожидали ошибку запуска: %v", err)
	}
}

func TestHungProcessIsKilledAfterTimeout(t *testing.T) {
	r, _ := NewProcessRunner(t.TempDir())
	// процесс игнорирует SIGTERM
	argv := []string{"/bin/sh", "-c", `trap "" TERM; sleep 30`}
	if _, err := r.Start("hung", argv, t.TempDir(), os.Environ(), nil, ""); err != nil {
		t.Fatal(err)
	}
	time.Sleep(200 * time.Millisecond) // даём оболочке установить trap до сигнала
	res, err := r.Stop("hung", 300*time.Millisecond, "")
	if err != nil || res != "killed" {
		t.Fatalf("ожидали killed, получили %s %v", res, err)
	}
}
