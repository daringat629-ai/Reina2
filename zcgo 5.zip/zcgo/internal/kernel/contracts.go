package kernel

import (
	"encoding/json"
	"math"
	"os"
	"regexp"
)

// Контракт модуля: manifest.json. Строгий: неизвестные поля — ошибка. Порт kernel/contracts.py.

const APIVersion = "1"

var (
	kinds        = []string{"service", "job", "external", "library"}
	healthTypes  = []string{"none", "process", "pgrep", "command", "http", "file_fresh", "job"}
	dataPolicies = []string{"keep", "delete"}
	topKeys      = set("api", "name", "version", "kind", "description", "run", "provides", "requires", "optional_requires", "depends",
		"conflicts", "permissions", "health", "data_policy", "limits", "config", "widgets", "tools", "patches")
	// PatchKeys — ключи расширения, которые ядро знает. Неизвестный ключ манифест не пройдёт.
	PatchKeys = map[string]string{"prompt.append": "добавка к промпту бота", "hook.event": "реакция на событие бота"}
	// PromptTargets — файлы промптов бота, в которые можно вставить добавку.
	PromptTargets = []string{"system.md", "character_base.md", "character_appearance.md", "photo_to_text.md", "sticker_to_text.md",
		"anti_repeat.md", "diary_save.md", "sleep_consolidator.md", "record_audio_speech.md", "messages_epilogue.md"}
	eventKinds  = []string{"message", "llm", "tool", "tools", "guard", "manager", "error"}
	patchFields = map[string]map[string]bool{
		"prompt.append": set("target", "file", "position"),
		"hook.event":    set("on", "contains", "command", "cooldown_seconds", "timeout_seconds"),
	}
	widgetKinds    = []string{"kv", "table", "text", "counter"}
	widgetKeys     = set("id", "title", "kind", "command", "refresh_seconds", "actions", "size")
	toolKeys       = set("name", "description", "parameters", "required", "command", "timeout_seconds", "max_output_bytes")
	toolParamTypes = []string{"string", "integer", "number", "boolean"}
	runKeys        = set("command", "cwd", "env", "stop_timeout", "start_timeout", "schedule_seconds", "timeout", "handoff", "restart",
		"autostart", "start_command", "stop_command", "kill_command")
	permKeys  = set("network", "shell", "read", "secrets")
	limitKeys = set("memory_mb", "cpu_seconds", "open_files")

	patchIDRE   = regexp.MustCompile(`^[a-z][a-z0-9_]{0,31}$`)
	widgetIDRE  = regexp.MustCompile(`^[a-z][a-z0-9_]{0,31}$`)
	toolNameRE  = regexp.MustCompile(`^[a-z][a-z0-9_]{1,63}$`)
	toolParamRE = regexp.MustCompile(`^[a-z][a-z0-9_]{0,63}$`)
	nameRE      = regexp.MustCompile(`^[a-z][a-z0-9_]{1,31}$`)
	capRE       = regexp.MustCompile(`^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$`)
	verRE       = regexp.MustCompile(`^\d+(\.\d+){0,2}$`)
)

const (
	MaxPatches     = 16
	MaxPromptBytes = 4096
	maxToolParams  = 32
)

func set(items ...string) map[string]bool {
	m := make(map[string]bool, len(items))
	for _, s := range items {
		m[s] = true
	}
	return m
}

func inList(v string, list []string) bool {
	for _, x := range list {
		if x == v {
			return true
		}
	}
	return false
}

// --- разбор JSON-значений ---

func asMap(v any) (map[string]any, bool) {
	m, ok := v.(map[string]any)
	return m, ok
}

func asList(v any) ([]any, bool) {
	l, ok := v.([]any)
	return l, ok
}

func asStr(v any) (string, bool) {
	s, ok := v.(string)
	return s, ok
}

// asInt принимает только целые числа (bool и дробные — нет).
func asInt(v any) (int, bool) {
	f, ok := v.(float64)
	if !ok || math.Trunc(f) != f || math.IsInf(f, 0) {
		return 0, false
	}
	return int(f), true
}

func intIn(v any, lo, hi int) bool {
	n, ok := asInt(v)
	return ok && n >= lo && n <= hi
}

// strList: непустой список непустых строк (как _strlist в Python).
func strList(v any) bool {
	l, ok := asList(v)
	if !ok || len(l) == 0 {
		return false
	}
	for _, x := range l {
		if s, ok := asStr(x); !ok || s == "" {
			return false
		}
	}
	return true
}

// plainStrList: список строк, пустой допустим.
func plainStrList(v any) bool {
	l, ok := asList(v)
	if !ok {
		return false
	}
	for _, x := range l {
		if _, ok := asStr(x); !ok {
			return false
		}
	}
	return true
}

func keysSubset(m map[string]any, allowed map[string]bool) bool {
	for k := range m {
		if !allowed[k] {
			return false
		}
	}
	return true
}

func validateWidgets(v any) []string {
	widgets, ok := asList(v)
	if !ok {
		return []string{"widgets: список описаний виджетов"}
	}
	var errs []string
	seen := map[string]bool{}
	for i, wv := range widgets {
		p := sprintf("widgets[%d]", i)
		w, ok := asMap(wv)
		if !ok {
			errs = append(errs, p+": объект")
			continue
		}
		for k := range w {
			if !widgetKeys[k] {
				errs = append(errs, sprintf("%s: неизвестное поле %s", p, k))
			}
		}
		wid, _ := asStr(w["id"])
		if !widgetIDRE.MatchString(wid) {
			errs = append(errs, p+".id: строчные буквы, цифры и _, до 32 символов")
		} else if seen[wid] {
			errs = append(errs, sprintf("%s.id: повтор %s", p, wid))
		} else {
			seen[wid] = true
		}
		if t, ok := asStr(w["title"]); !ok || t == "" {
			errs = append(errs, p+".title: непустая строка")
		}
		if k, _ := asStr(w["kind"]); !inList(k, widgetKinds) {
			errs = append(errs, sprintf("%s.kind: одно из %v", p, widgetKinds))
		}
		if !strList(w["command"]) {
			errs = append(errs, p+".command: непустой список строк")
		}
		rs := any(float64(10))
		if x, ok := w["refresh_seconds"]; ok {
			rs = x
		}
		if !intIn(rs, 1, 3600) {
			errs = append(errs, p+".refresh_seconds: целое от 1 до 3600")
		}
		size := map[string]any{"w": 6.0, "h": 6.0}
		if x, ok := w["size"]; ok {
			size, ok = asMap(x)
			if !ok {
				size = nil
			}
		}
		sizeOK := size != nil && keysSubset(size, set("w", "h"))
		for _, sv := range size {
			if !intIn(sv, 2, 40) {
				sizeOK = false
			}
		}
		if !sizeOK {
			errs = append(errs, p+".size: {w, h} целые от 2 до 40")
		}
		acts := []any{}
		if x, ok := w["actions"]; ok {
			acts, ok = asList(x)
			if !ok {
				errs = append(errs, p+".actions: список")
				continue
			}
		}
		aseen := map[string]bool{}
		for j, av := range acts {
			q := sprintf("%s.actions[%d]", p, j)
			a, ok := asMap(av)
			if !ok || !keysSubset(a, set("id", "label", "command")) {
				errs = append(errs, q+": объект с полями id, label, command")
				continue
			}
			aid, _ := asStr(a["id"])
			if !widgetIDRE.MatchString(aid) || aseen[aid] {
				errs = append(errs, q+".id: уникальный идентификатор")
			} else {
				aseen[aid] = true
			}
			if l, ok := asStr(a["label"]); !ok || l == "" {
				errs = append(errs, q+".label: непустая строка")
			}
			if !strList(a["command"]) {
				errs = append(errs, q+".command: непустой список строк")
			}
		}
	}
	return errs
}

func validateTools(v any) []string {
	tools, ok := asList(v)
	if !ok {
		return []string{"tools: список описаний инструментов"}
	}
	var errs []string
	seen := map[string]bool{}
	for i, tv := range tools {
		p := sprintf("tools[%d]", i)
		t, ok := asMap(tv)
		if !ok {
			errs = append(errs, p+": объект")
			continue
		}
		for k := range t {
			if !toolKeys[k] {
				errs = append(errs, sprintf("%s: неизвестное поле %s", p, k))
			}
		}
		name, _ := asStr(t["name"])
		if !toolNameRE.MatchString(name) {
			errs = append(errs, p+".name: строчные буквы, цифры и _, 2-64 символа, начинается с буквы")
		} else if seen[name] {
			errs = append(errs, sprintf("%s.name: повтор %s", p, name))
		} else {
			seen[name] = true
		}
		if d, ok := asStr(t["description"]); !ok || d == "" || len([]rune(d)) > 2000 {
			errs = append(errs, p+".description: непустая строка до 2000 символов")
		}
		params := map[string]any{}
		if x, ok := t["parameters"]; ok {
			pm, isMap := asMap(x)
			if !isMap || len(pm) > maxToolParams {
				errs = append(errs, p+".parameters: объект {имя: {type, description}}, до 32 параметров")
			} else {
				params = pm
			}
		}
		for pn, sv := range params {
			if !toolParamRE.MatchString(pn) {
				errs = append(errs, sprintf("%s.parameters.%s: недопустимое имя", p, pn))
			}
			spec, ok := asMap(sv)
			typ, _ := asStr(spec["type"])
			if !ok || !inList(typ, toolParamTypes) || !keysSubset(spec, set("type", "description")) {
				errs = append(errs, sprintf("%s.parameters.%s: {type: string|integer|number|boolean, description}", p, pn))
			}
		}
		if x, ok := t["required"]; ok {
			req, isList := asList(x)
			good := isList
			for _, r := range req {
				s, isStr := asStr(r)
				if _, declared := params[s]; !isStr || !declared {
					good = false
				}
			}
			if !good {
				errs = append(errs, p+".required: список имён объявленных параметров")
			}
		}
		if !strList(t["command"]) {
			errs = append(errs, p+".command: непустой список строк (до 64), программа не пустая")
		} else if l, _ := asList(t["command"]); len(l) > 64 {
			errs = append(errs, p+".command: непустой список строк (до 64), программа не пустая")
		}
		if x, ok := t["timeout_seconds"]; ok && !intIn(x, 1, 300) {
			errs = append(errs, p+".timeout_seconds: целое от 1 до 300")
		}
		if x, ok := t["max_output_bytes"]; ok && !intIn(x, 100, 65536) {
			errs = append(errs, p+".max_output_bytes: целое от 100 до 65536")
		}
	}
	return errs
}

// SafeRel — относительный путь внутри детали.
func SafeRel(p any) bool {
	s, ok := asStr(p)
	if !ok || len(s) == 0 || len(s) > 200 {
		return false
	}
	if s[0] == '/' || containsAny(s, "\\\x00") || s[len(s)-1] == '/' {
		return false
	}
	for _, part := range splitSlash(s) {
		if part == ".." {
			return false
		}
	}
	return true
}

func validatePatches(v any) []string {
	patches, ok := asList(v)
	if !ok || len(patches) > MaxPatches {
		return []string{sprintf("patches: список не длиннее %d", MaxPatches)}
	}
	var errs []string
	seen := map[string]bool{}
	for i, pv := range patches {
		where := sprintf("patches[%d]", i)
		p, ok := asMap(pv)
		if !ok {
			errs = append(errs, where+": объект")
			continue
		}
		key, _ := asStr(p["key"])
		if _, known := PatchKeys[key]; !known {
			errs = append(errs, sprintf("%s.key: ядро не знает ключа %q", where, key))
			continue
		}
		pid, _ := asStr(p["id"])
		if !patchIDRE.MatchString(pid) {
			errs = append(errs, where+".id: строчные латинские буквы, цифры и _, до 32 символов, начинается с буквы")
		} else if seen[pid] {
			errs = append(errs, sprintf("%s.id: %q повторяется", where, pid))
		} else {
			seen[pid] = true
		}
		for k := range p {
			if !set("key", "id", "title")[k] && !patchFields[key][k] {
				errs = append(errs, sprintf("%s: лишнее поле %s для ключа %s", where, k, key))
			}
		}
		if x, ok := p["title"]; ok {
			if s, isStr := asStr(x); !isStr || len([]rune(s)) > 80 {
				errs = append(errs, where+".title: строка до 80 символов")
			}
		}
		if key == "prompt.append" {
			target, _ := asStr(p["target"])
			if !inList(target, PromptTargets) {
				errs = append(errs, where+".target: один из файлов промптов бота")
			}
			file, _ := asStr(p["file"])
			if !SafeRel(p["file"]) || !(hasSuffix(file, ".md") || hasSuffix(file, ".txt")) {
				errs = append(errs, where+".file: относительный путь внутри детали к файлу .md или .txt")
			}
			pos := "end"
			if x, ok := p["position"]; ok {
				pos, _ = asStr(x)
			}
			if pos != "start" && pos != "end" {
				errs = append(errs, where+".position: start или end")
			}
			continue
		}
		on, _ := asStr(p["on"])
		if !inList(on, eventKinds) {
			errs = append(errs, sprintf("%s.on: одно из %v", where, eventKinds))
		}
		if !strList(p["command"]) {
			errs = append(errs, where+".command: непустой список строк")
		}
		if x, ok := p["contains"]; ok {
			if s, isStr := asStr(x); !isStr || s == "" || len([]rune(s)) > 200 {
				errs = append(errs, where+".contains: непустая строка до 200 символов")
			}
		}
		cd, to := any(float64(60)), any(float64(10))
		if x, ok := p["cooldown_seconds"]; ok {
			cd = x
		}
		if x, ok := p["timeout_seconds"]; ok {
			to = x
		}
		if !intIn(cd, 5, 86400) {
			errs = append(errs, where+".cooldown_seconds: целое от 5 до 86400")
		}
		if !intIn(to, 1, 60) {
			errs = append(errs, where+".timeout_seconds: целое от 1 до 60")
		}
	}
	return errs
}

// ValidateManifest возвращает список ошибок (пустой — манифест корректен).
func ValidateManifest(d any) []string {
	m, ok := asMap(d)
	if !ok {
		return []string{"манифест должен быть объектом JSON"}
	}
	var e []string
	for k := range m {
		if !topKeys[k] {
			e = append(e, "неизвестное поле: "+k)
		}
	}
	if api, _ := asStr(m["api"]); api != APIVersion {
		e = append(e, `api должен быть "1"`)
	}
	name, _ := asStr(m["name"])
	if !nameRE.MatchString(name) {
		e = append(e, "name: строчные буквы, цифры и _, 2–32 символа, начинается с буквы")
	}
	version, _ := asStr(m["version"])
	if !verRE.MatchString(version) {
		e = append(e, "version: формат 1, 1.2 или 1.2.3")
	}
	kind, _ := asStr(m["kind"])
	if !inList(kind, kinds) {
		e = append(e, sprintf("kind: одно из %v", kinds))
	}
	run := map[string]any{}
	if x, ok := m["run"]; ok {
		rm, isMap := asMap(x)
		if !isMap {
			e = append(e, "run должен быть объектом")
		} else {
			run = rm
		}
	}
	for k := range run {
		if !runKeys[k] {
			e = append(e, "run: неизвестное поле "+k)
		}
	}
	if (kind == "service" || kind == "job") && !strList(run["command"]) {
		e = append(e, "run.command: непустой список строк обязателен для service и job")
	}
	if kind == "job" && !(intIn(run["schedule_seconds"], 10, math.MaxInt32)) {
		e = append(e, "run.schedule_seconds: целое число не меньше 10 обязательно для job")
	}
	if kind == "external" && !strList(run["start_command"]) {
		e = append(e, "run.start_command обязателен для external")
	}
	handoff := "parallel"
	if s, ok := asStr(run["handoff"]); ok {
		handoff = s
	}
	if handoff != "parallel" && handoff != "stop_first" {
		e = append(e, "run.handoff: parallel или stop_first")
	}
	restart := "never"
	if s, ok := asStr(run["restart"]); ok {
		restart = s
	}
	if restart != "never" && restart != "on-failure" {
		e = append(e, "run.restart: never или on-failure")
	}
	for _, k := range []string{"provides", "requires", "optional_requires", "conflicts"} {
		if x, ok := m[k]; ok && !plainStrList(x) {
			e = append(e, k+": список строк")
		}
	}
	provides := stringsOf(m["provides"])
	requires := stringsOf(m["requires"])
	optional := stringsOf(m["optional_requires"])
	for _, list := range [][]string{provides, requires, optional} {
		for _, cap := range list {
			if !capRE.MatchString(cap) {
				e = append(e, sprintf("возможность %q: формат группа.имя", cap))
			}
		}
	}
	for _, cap := range optional {
		if contains(requires, cap) {
			e = append(e, sprintf("optional_requires: %q уже в requires (выберите одно: обязательно или желательно)", cap))
		}
		if contains(provides, cap) {
			e = append(e, sprintf("optional_requires: %q модуль сам же предоставляет", cap))
		}
	}
	if x, ok := m["depends"]; ok {
		dm, isMap := asMap(x)
		if !isMap {
			e = append(e, "depends: объект имя -> ограничение версии")
		} else {
			for n, cv := range dm {
				c, _ := asStr(cv)
				if _, err := Satisfies("0", c); err != nil {
					e = append(e, sprintf("depends.%s: неверное ограничение %q", n, c))
				}
			}
		}
	}
	if x, ok := m["permissions"]; ok {
		pm, isMap := asMap(x)
		if !isMap || !keysSubset(pm, permKeys) {
			e = append(e, "permissions: допустимы только network, shell, read, secrets")
		}
	}
	health := map[string]any{"type": "none"}
	if x, ok := m["health"]; ok {
		health, _ = asMap(x)
	}
	ht, _ := asStr(health["type"])
	if health == nil || !inList(ht, healthTypes) {
		e = append(e, sprintf("health.type: одно из %v", healthTypes))
	} else {
		switch ht {
		case "pgrep":
			if _, ok := asStr(health["process"]); !ok {
				e = append(e, "health.process обязателен для pgrep")
			}
		case "command":
			if !strList(health["command"]) {
				e = append(e, "health.command обязателен для command")
			}
		case "http":
			if _, ok := asStr(health["url"]); !ok {
				e = append(e, "health.url обязателен для http")
			}
		case "file_fresh":
			_, okPath := asStr(health["path"])
			_, okAge := asInt(health["max_age_seconds"])
			if !okPath || !okAge {
				e = append(e, "health.path и health.max_age_seconds обязательны для file_fresh")
			}
		}
	}
	dp := "keep"
	if x, ok := m["data_policy"]; ok {
		dp, _ = asStr(x)
	}
	if !inList(dp, dataPolicies) {
		e = append(e, sprintf("data_policy: одно из %v", dataPolicies))
	}
	if x, ok := m["limits"]; ok {
		lm, isMap := asMap(x)
		good := isMap && keysSubset(lm, limitKeys)
		for _, v := range lm {
			if n, ok := asInt(v); !ok || n <= 0 {
				good = false
			}
		}
		if !good {
			e = append(e, "limits: положительные целые, ключи из memory_mb, cpu_seconds, open_files")
		}
	}
	if x, ok := m["config"]; ok {
		if _, isMap := asMap(x); !isMap {
			e = append(e, "config: объект значений по умолчанию")
		}
	}
	if x, ok := m["widgets"]; ok {
		e = append(e, validateWidgets(x)...)
	}
	if x, ok := m["tools"]; ok {
		e = append(e, validateTools(x)...)
	}
	if x, ok := m["patches"]; ok {
		e = append(e, validatePatches(x)...)
	}
	return e
}

// Manifest — разобранный и проверенный манифест.
type Manifest struct {
	Name             string            `json:"name"`
	Version          string            `json:"version"`
	Kind             string            `json:"kind"`
	Description      string            `json:"description"`
	Run              map[string]any    `json:"run"`
	Provides         []string          `json:"provides"`
	Requires         []string          `json:"requires"`
	OptionalRequires []string          `json:"optional_requires"`
	Depends          map[string]string `json:"depends"`
	Conflicts        []string          `json:"conflicts"`
	Permissions      map[string]any    `json:"permissions"`
	Health           map[string]any    `json:"health"`
	DataPolicy       string            `json:"data_policy"`
	Limits           map[string]int    `json:"limits"`
	Config           map[string]any    `json:"config"`
	Widgets          []map[string]any  `json:"widgets"`
	Tools            []Tool            `json:"tools"`
	Patches          []map[string]any  `json:"patches"`
}

// Tool — инструмент для LLM из манифеста.
type Tool struct {
	Name           string                    `json:"name"`
	Description    string                    `json:"description"`
	Parameters     map[string]map[string]any `json:"parameters"`
	Required       []string                  `json:"required"`
	Command        []string                  `json:"command"`
	TimeoutSeconds *int                      `json:"timeout_seconds,omitempty"`
	MaxOutput      *int                      `json:"max_output_bytes,omitempty"`
}

// FromRaw проверяет сырой объект манифеста и превращает его в Manifest.
func FromRaw(raw map[string]any) (*Manifest, error) {
	if errs := ValidateManifest(raw); len(errs) > 0 {
		msg := ""
		for i, e := range errs {
			if i > 0 {
				msg += "; "
			}
			msg += e
		}
		return nil, Newf(KindContract, "%s", msg)
	}
	data, err := json.Marshal(raw)
	if err != nil {
		return nil, Newf(KindContract, "%v", err)
	}
	var m Manifest
	if err := json.Unmarshal(data, &m); err != nil {
		return nil, Newf(KindContract, "%v", err)
	}
	if m.Health == nil {
		m.Health = map[string]any{"type": "none"}
	}
	if m.DataPolicy == "" {
		m.DataPolicy = "keep"
	}
	if m.Run == nil {
		m.Run = map[string]any{}
	}
	return &m, nil
}

// LoadManifest читает и проверяет manifest.json.
func LoadManifest(path string) (*Manifest, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, Newf(KindContract, "%s: не удалось прочитать манифест: %v", path, err)
	}
	var d any
	if err := json.Unmarshal(raw, &d); err != nil {
		return nil, Newf(KindContract, "%s: не удалось прочитать манифест: %v", path, err)
	}
	m, ok := asMap(d)
	if !ok {
		return nil, Newf(KindContract, "манифест должен быть объектом JSON")
	}
	return FromRaw(m)
}
