package kernel

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

// Шина событий: журнал + курсоры потребителей, ограниченная очередь.
//
// Отличие от Python-версии: вместо SQLite (в Go без внешних модулей его нет) журнал хранится в events.jsonl,
// курсоры в cursors.json, доступ под flock. Формат событий тот же (id, ts, topic, producer, payload).
const (
	MaxEvents  = 10000
	MaxPayload = 65536
)

// Event — одно событие.
type Event struct {
	ID       int64          `json:"id"`
	TS       float64        `json:"ts"`
	Topic    string         `json:"topic"`
	Producer string         `json:"producer"`
	Payload  map[string]any `json:"payload"`
}

// EventBus хранит события в каталоге home.
type EventBus struct {
	dir       string
	MaxEvents int
}

// NewEventBus создаёт шину в каталоге home.
func NewEventBus(home string) *EventBus {
	return &EventBus{dir: home, MaxEvents: MaxEvents}
}

func (b *EventBus) lock() (*os.File, error) {
	f, err := os.OpenFile(filepath.Join(b.dir, "events.lock"), os.O_CREATE|os.O_RDWR, 0o644)
	if err != nil {
		return nil, err
	}
	if err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX); err != nil {
		f.Close()
		return nil, err
	}
	return f, nil
}

func unlock(f *os.File) {
	_ = syscall.Flock(int(f.Fd()), syscall.LOCK_UN)
	f.Close()
}

func (b *EventBus) readAll() ([]Event, error) {
	f, err := os.Open(filepath.Join(b.dir, "events.jsonl"))
	if os.IsNotExist(err) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []Event
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	for sc.Scan() {
		var e Event
		if json.Unmarshal(sc.Bytes(), &e) == nil {
			out = append(out, e)
		}
	}
	return out, sc.Err()
}

func (b *EventBus) writeAll(events []Event) error {
	var buf bytes.Buffer
	for _, e := range events {
		line, err := json.Marshal(e)
		if err != nil {
			return err
		}
		buf.Write(line)
		buf.WriteByte('\n')
	}
	return AtomicWrite(filepath.Join(b.dir, "events.jsonl"), buf.Bytes(), 0o644)
}

// Publish добавляет событие. Возвращает его номер.
func (b *EventBus) Publish(topic string, payload map[string]any, producer string) (int64, error) {
	if payload == nil {
		payload = map[string]any{}
	}
	data, err := json.Marshal(payload)
	if err != nil {
		return 0, err
	}
	if len(data) > MaxPayload {
		return 0, Newf(KindGeneric, "событие %s: полезная нагрузка больше %d байт", topic, MaxPayload)
	}
	f, err := b.lock()
	if err != nil {
		return 0, err
	}
	defer unlock(f)
	events, err := b.readAll()
	if err != nil {
		return 0, err
	}
	var last int64
	if len(events) > 0 {
		last = events[len(events)-1].ID
	}
	e := Event{ID: last + 1, TS: float64(time.Now().UnixNano()) / 1e9, Topic: topic, Producer: producer, Payload: payload}
	events = append(events, e)
	if len(events) > b.MaxEvents {
		events = events[len(events)-b.MaxEvents:]
	}
	if err := b.writeAll(events); err != nil {
		return 0, err
	}
	return e.ID, nil
}

type cursors map[string]int64

func (b *EventBus) loadCursors() cursors {
	c := cursors{}
	if raw, err := os.ReadFile(filepath.Join(b.dir, "cursors.json")); err == nil {
		_ = json.Unmarshal(raw, &c)
	}
	return c
}

func (b *EventBus) saveCursors(c cursors) error {
	raw, err := json.Marshal(c)
	if err != nil {
		return err
	}
	return AtomicWrite(filepath.Join(b.dir, "cursors.json"), raw, 0o644)
}

// Poll отдаёт потребителю события после его курсора, с фильтром по префиксу темы. ack — сдвинуть курсор.
func (b *EventBus) Poll(consumer string, topics []string, limit int, ack bool) ([]Event, error) {
	f, err := b.lock()
	if err != nil {
		return nil, err
	}
	defer unlock(f)
	events, err := b.readAll()
	if err != nil {
		return nil, err
	}
	c := b.loadCursors()
	last := c[consumer]
	var out []Event
	scanned := 0
	for _, e := range events {
		if e.ID <= last {
			continue
		}
		scanned++
		if scanned > limit*5 || len(out) >= limit {
			break
		}
		if matchesTopics(e.Topic, topics) {
			out = append(out, e)
		}
	}
	if ack && len(out) > 0 {
		c[consumer] = out[len(out)-1].ID
		if err := b.saveCursors(c); err != nil {
			return nil, err
		}
	}
	return out, nil
}

func matchesTopics(topic string, topics []string) bool {
	if len(topics) == 0 {
		return true
	}
	for _, t := range topics {
		if strings.HasPrefix(topic, t) {
			return true
		}
	}
	return false
}

// Recent возвращает последние n событий по порядку.
func (b *EventBus) Recent(n int) ([]Event, error) {
	f, err := b.lock()
	if err != nil {
		return nil, err
	}
	defer unlock(f)
	events, err := b.readAll()
	if err != nil {
		return nil, err
	}
	if len(events) > n {
		events = events[len(events)-n:]
	}
	return events, nil
}

// String для отладки.
func (e Event) String() string { return fmt.Sprintf("%d %s", e.ID, e.Topic) }
