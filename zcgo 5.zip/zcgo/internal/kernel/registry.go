package kernel

import (
	"sort"
	"strings"
)

// Registry — кто что предоставляет. Две реализации одной возможности запрещены.
type Registry struct {
	providers map[string][]string
}

// NewRegistry строит реестр по включённым манифестам (имя -> манифест).
func NewRegistry(manifests map[string]*Manifest) (*Registry, error) {
	r := &Registry{providers: map[string][]string{}}
	names := make([]string, 0, len(manifests))
	for n := range manifests {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		for _, c := range manifests[n].Provides {
			r.providers[c] = append(r.providers[c], n)
		}
	}
	var problems []string
	caps := make([]string, 0)
	for c := range r.providers {
		caps = append(caps, c)
	}
	sort.Strings(caps)
	for _, c := range caps {
		if len(r.providers[c]) > 1 {
			mods := append([]string(nil), r.providers[c]...)
			sort.Strings(mods)
			problems = append(problems, "возможность "+c+" предоставляют несколько модулей: "+strings.Join(mods, ", "))
		}
	}
	if len(problems) > 0 {
		return nil, Newf(KindConflict, "%s", strings.Join(problems, "; "))
	}
	return r, nil
}

// Provider возвращает модуль, предоставляющий возможность, или "".
func (r *Registry) Provider(capability string) string {
	if p := r.providers[capability]; len(p) > 0 {
		return p[0]
	}
	return ""
}
