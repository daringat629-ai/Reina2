package toolcall

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func schema() Tool {
	var t Tool
	t.Name = "note_add"
	t.Parameters.Properties = map[string]map[string]any{
		"text":  {"type": "string"},
		"n":     {"type": "integer"},
		"flag":  {"type": "boolean"},
		"score": {"type": "number"},
	}
	t.Parameters.Required = []string{"text"}
	return t
}

func TestPrepareValidatesLikeKuni(t *testing.T) {
	tool := schema()
	if p := Prepare(tool, ""); p.Error != "error: missing required argument \"text\" for tool note_add" {
		t.Errorf("обязательный аргумент: %q", p.Error)
	}
	if p := Prepare(tool, `{"text":"a","zzz":1}`); !strings.Contains(p.Error, "unknown argument") {
		t.Errorf("лишний аргумент: %q", p.Error)
	}
	if p := Prepare(tool, `{"text":"a","n":7.5}`); !strings.Contains(p.Error, "must be an integer") {
		t.Errorf("дробное целое: %q", p.Error)
	}
	if p := Prepare(tool, `[1,2]`); p.Error == "" {
		t.Error("массив вместо объекта должен отклоняться")
	}
	if p := Prepare(tool, `{bad`); !strings.Contains(p.Error, "not valid JSON") {
		t.Errorf("битый JSON: %q", p.Error)
	}
}

func TestPrepareCoercesTypesAndSkipsNull(t *testing.T) {
	tool := schema()
	p := Prepare(tool, `{"text":"a","n":"3","flag":"true","score":"2.5","text2":null}`)
	if p.Error != "error: unknown argument \"text2\" for tool note_add" {
		// null для неизвестного поля тоже ошибка, как в kuni
		t.Fatalf("неизвестный аргумент с null: %q", p.Error)
	}
	p = Prepare(tool, `{"text":"a","n":"3","flag":"true","score":"2.5","n2":null}`)
	if p.Error == "" {
		t.Fatal("ожидали ошибку неизвестного аргумента n2")
	}
	p = Prepare(tool, `{"text":"a","n":"3","flag":"true","score":"2.5"}`)
	if p.Error != "" || !strings.Contains(p.Payload, `"n":3`) || !strings.Contains(p.Payload, `"flag":true`) {
		t.Fatalf("приведение типов: %q %q", p.Payload, p.Error)
	}
	p = Prepare(tool, `{"text":"a","n":null}`)
	if p.Error != "" || strings.Contains(p.Payload, `"n"`) {
		t.Errorf("null означает «не передано»: %q", p.Payload)
	}
}

func TestRunPassesPayloadAndFormatsErrors(t *testing.T) {
	dir := t.TempDir()
	echo := Tool{Name: "echo_tool", Command: []string{"cat"}, Cwd: dir, TimeoutSeconds: 5, MaxOutput: 8000}
	out := Run(echo, `{"tool":"echo_tool","arguments":{}}`)
	if out != `{"tool":"echo_tool","arguments":{}}` {
		t.Errorf("stdin не передан: %q", out)
	}
	fail := Tool{Name: "f", Command: []string{"sh", "-c", "echo boom; exit 3"}, Cwd: dir, TimeoutSeconds: 5}
	if out := Run(fail, "{}"); out != "error: the tool exited with code 3\nboom" {
		t.Errorf("код выхода: %q", out)
	}
	slow := Tool{Name: "s", Command: []string{"sleep", "10"}, Cwd: dir, TimeoutSeconds: 1}
	if out := Run(slow, "{}"); !strings.Contains(out, "timed out after 1 s") {
		t.Errorf("таймаут: %q", out)
	}
	big := Tool{Name: "b", Command: []string{"sh", "-c", "head -c 5000 /dev/zero | tr '\\0' a"}, Cwd: dir, TimeoutSeconds: 5, MaxOutput: 100}
	if out := Run(big, "{}"); !strings.HasSuffix(out, "[output truncated]") || len(out) > 150 {
		t.Errorf("обрезка вывода: len=%d", len(out))
	}
	none := Tool{Name: "n", Command: []string{"true"}, Cwd: dir, TimeoutSeconds: 5}
	if out := Run(none, "{}"); out != "(no output)" {
		t.Errorf("пустой вывод: %q", out)
	}
	missing := Tool{Name: "m", Command: []string{filepath.Join(dir, "nope")}, Cwd: dir, TimeoutSeconds: 5}
	if out := Run(missing, "{}"); !strings.HasPrefix(out, "error: failed to start the tool") {
		t.Errorf("отсутствующая программа: %q", out)
	}
	_ = os.Getpid()
}
