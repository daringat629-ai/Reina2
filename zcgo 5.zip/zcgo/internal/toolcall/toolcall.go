// Вызов инструмента так же, как его вызывает бот kuni (порт разбора и запуска из external_tools.cpp):
// аргументы проверяются по схеме (лишние поля, типы, обязательные), приводятся к типам,
// в stdin уходит JSON {"tool","arguments"}, ответ форматируется как у бота.
package toolcall

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"syscall"
	"time"
	"unicode"
)

const MaxPayload = 65536

// Tool — описание инструмента из tools.json.
type Tool struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Parameters  struct {
		Properties map[string]map[string]any `json:"properties"`
		Required   []string                  `json:"required"`
	} `json:"parameters"`
	Command        []string          `json:"command"`
	Cwd            string            `json:"cwd"`
	Env            map[string]string `json:"env"`
	TimeoutSeconds int               `json:"timeout_seconds"`
	MaxOutput      int               `json:"max_output_bytes"`
}

// Prepared — результат проверки аргументов.
type Prepared struct {
	Payload string
	Error   string
}

// Prepare проверяет аргументы (JSON-объект или пусто) и строит payload для stdin.
func Prepare(t Tool, argsJSON string) Prepared {
	args := map[string]any{}
	if strings.TrimSpace(argsJSON) != "" {
		var v any
		if err := json.Unmarshal([]byte(argsJSON), &v); err != nil {
			return Prepared{Error: "error: the arguments are not valid JSON: " + err.Error()}
		}
		switch x := v.(type) {
		case nil:
		case map[string]any:
			args = x
		default:
			return Prepared{Error: "error: the arguments must be a JSON object"}
		}
	}
	cleaned := map[string]any{}
	for name, val := range args {
		spec, ok := t.Parameters.Properties[name]
		if !ok {
			return Prepared{Error: fmt.Sprintf("error: unknown argument %q for tool %s", name, t.Name)}
		}
		if val == nil {
			continue
		}
		conv, problem := coerce(name, spec, val)
		if problem != "" {
			return Prepared{Error: "error: " + problem}
		}
		cleaned[name] = conv
	}
	for _, r := range t.Parameters.Required {
		if _, ok := cleaned[r]; !ok {
			return Prepared{Error: fmt.Sprintf("error: missing required argument %q for tool %s", r, t.Name)}
		}
	}
	payload, err := json.Marshal(map[string]any{"tool": t.Name, "arguments": cleaned})
	if err != nil {
		return Prepared{Error: "error: " + err.Error()}
	}
	if len(payload) > MaxPayload {
		return Prepared{Error: fmt.Sprintf("error: the arguments are too large (limit %d bytes)", MaxPayload)}
	}
	return Prepared{Payload: string(payload)}
}

func coerce(name string, spec map[string]any, in any) (any, string) {
	typ, _ := spec["type"].(string)
	switch typ {
	case "string":
		switch v := in.(type) {
		case string:
			return v, ""
		case float64:
			return strconv.FormatFloat(v, 'f', -1, 64), ""
		case bool:
			return strconv.FormatBool(v), ""
		}
		return nil, fmt.Sprintf("argument %q must be a string", name)
	case "boolean":
		switch v := in.(type) {
		case bool:
			return v, ""
		case string:
			if v == "true" || v == "false" {
				return v == "true", ""
			}
		}
		return nil, fmt.Sprintf("argument %q must be a boolean", name)
	}
	var d float64
	switch v := in.(type) {
	case float64:
		d = v
	case string:
		f, err := strconv.ParseFloat(strings.TrimSpace(v), 64)
		if err != nil {
			return nil, fmt.Sprintf("argument %q must be a number", name)
		}
		d = f
	default:
		return nil, fmt.Sprintf("argument %q must be a number", name)
	}
	if typ == "integer" && (math.Floor(d) != d || math.Abs(d) >= 9e15) {
		return nil, fmt.Sprintf("argument %q must be an integer", name)
	}
	return d, ""
}

// Run запускает команду инструмента и возвращает текст ответа, как бот.
func Run(t Tool, payload string) string {
	if len(t.Command) == 0 {
		return "error: failed to start the tool: пустая команда"
	}
	timeout := t.TimeoutSeconds
	if timeout <= 0 {
		timeout = 30
	}
	maxOut := t.MaxOutput
	if maxOut <= 0 {
		maxOut = 8000
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(timeout)*time.Second)
	defer cancel()
	cmd := exec.Command(t.Command[0], t.Command[1:]...)
	cmd.Dir = t.Cwd
	cmd.Env = os.Environ()
	for k, v := range t.Env {
		cmd.Env = append(cmd.Env, k+"="+v)
	}
	cmd.Stdin = strings.NewReader(payload)
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	var out bytes.Buffer
	cmd.Stdout = &limitWriter{buf: &out, max: maxOut}
	cmd.Stderr = cmd.Stdout
	if err := cmd.Start(); err != nil {
		return "error: failed to start the tool: " + err.Error()
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	var err error
	timedOut := false
	select {
	case err = <-done:
	case <-ctx.Done():
		timedOut = true
		_ = syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)
		err = <-done
	}
	lw := cmd.Stdout.(*limitWriter)
	text := strings.TrimRight(out.String(), " \t\r\n")
	if lw.truncated {
		text += "\n[output truncated]"
	}
	if timedOut {
		text += fmt.Sprintf("\n[timed out after %d s; the process was killed]", timeout)
	} else if err != nil {
		code := -1
		if ee, ok := err.(*exec.ExitError); ok {
			code = ee.ExitCode()
		}
		text = fmt.Sprintf("error: the tool exited with code %d", code) + ifNonEmpty(text, "\n"+text)
	}
	if text == "" {
		return "(no output)"
	}
	return text
}

func ifNonEmpty(s, v string) string {
	if s == "" {
		return ""
	}
	return v
}

// limitWriter пишет не больше max байт и помнит, что был обрезан.
type limitWriter struct {
	buf       *bytes.Buffer
	max       int
	truncated bool
}

func (w *limitWriter) Write(p []byte) (int, error) {
	room := w.max - w.buf.Len()
	if room <= 0 {
		if len(p) > 0 {
			w.truncated = true
		}
		return len(p), nil
	}
	if len(p) > room {
		w.buf.Write(p[:room])
		w.truncated = true
		return len(p), nil
	}
	w.buf.Write(p)
	return len(p), nil
}

// Find ищет инструмент по имени в каталоге (список из tools.json).
func Find(tools []Tool, name string) (Tool, bool) {
	for _, t := range tools {
		if t.Name == name {
			return t, true
		}
	}
	return Tool{}, false
}

// IsBlank — пустой ли текст аргументов (в kuni так же считается отсутствие аргументов).
func IsBlank(s string) bool {
	for _, r := range s {
		if !unicode.IsSpace(r) {
			return false
		}
	}
	return true
}
