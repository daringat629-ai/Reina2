module zcgo

go 1.24
