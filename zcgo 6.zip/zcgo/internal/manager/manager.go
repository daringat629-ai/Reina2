// Менеджер модулей: единая точка управления. Все изменения идут через kernel.RunTxn. Порт module_manager/manager.py.
package manager

import (
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"

	"zcgo/internal/kernel"
)

const txnTimeout = 30 * time.Second

var templateRE = regexp.MustCompile(`\$\{([a-z_.]+)\}`)

// ModuleState — запись о модуле в state.json.
type ModuleState struct {
	Version  string   `json:"version"`
	Versions []string `json:"versions"`
	Enabled  bool     `json:"enabled"`
	Previous *string  `json:"previous"`
	Desired  bool     `json:"desired"`
}

// State — содержимое state.json.
type State struct {
	Modules map[string]*ModuleState `json:"modules"`
}

// Manager управляет каталогом home (modules, data, run, config, .trash, state.json, tools.json, zerocore.db-аналог).
type Manager struct {
	Home       string
	CoreDir    string
	Store      *kernel.FileStore
	RuntimeSt  *kernel.FileStore
	Runner     *kernel.ProcessRunner
	Bus        *kernel.EventBus
	Recovered  bool
	RunTimeout time.Duration
}

// New открывает (и при необходимости создаёт) каталог home. Прерванная операция откатывается.
func New(home, coreDir string) (*Manager, error) {
	abs, err := filepath.Abs(home)
	if err != nil {
		return nil, err
	}
	for _, d := range []string{"modules", "data", "run", "config", ".trash"} {
		if err := os.MkdirAll(filepath.Join(abs, d), 0o755); err != nil {
			return nil, err
		}
	}
	runner, err := kernel.NewProcessRunner(filepath.Join(abs, "run"))
	if err != nil {
		return nil, err
	}
	m := &Manager{
		Home:       abs,
		CoreDir:    coreDir,
		Store:      &kernel.FileStore{Path: filepath.Join(abs, "state.json"), Default: `{"modules": {}}`},
		RuntimeSt:  &kernel.FileStore{Path: filepath.Join(abs, "runtime.json"), Default: "{}"},
		Runner:     runner,
		Bus:        kernel.NewEventBus(abs),
		RunTimeout: 0,
	}
	rec, err := kernel.Recover(abs, m.Store)
	if err != nil {
		return nil, err
	}
	m.Recovered = rec
	if rec {
		_, _ = m.Emit("txn.recovered", map[string]any{"msg": "прерванная операция откатана"})
	}
	m.gcTrash()
	if _, err := os.Stat(m.ToolsPath()); os.IsNotExist(err) && len(m.EnabledNames()) > 0 {
		m.RefreshTools()
	}
	return m, nil
}

func (m *Manager) gcTrash() {
	ents, _ := os.ReadDir(filepath.Join(m.Home, ".trash"))
	for _, e := range ents {
		_ = os.RemoveAll(filepath.Join(m.Home, ".trash", e.Name()))
	}
}

// Txn выполняет fn внутри транзакции конфигурации.
func (m *Manager) Txn(label string, fn func(t *kernel.Txn) error) error {
	return kernel.RunTxn(m.Home, label, m.Store, txnTimeout, fn)
}

// ModuleRoot — каталог модуля (versions/ и current).
func (m *Manager) ModuleRoot(name string) string {
	return filepath.Join(m.Home, "modules", name)
}

// ModuleDir — каталог версии; без версии — текущая (по симлинку current).
func (m *Manager) ModuleDir(name, version string) string {
	if version != "" {
		return filepath.Join(m.ModuleRoot(name), "versions", version)
	}
	cur := filepath.Join(m.ModuleRoot(name), "current")
	if r, err := filepath.EvalSymlinks(cur); err == nil {
		return r
	}
	return cur
}

// Manifest читает манифест модуля (текущей или указанной версии).
func (m *Manager) Manifest(name, version string) (*kernel.Manifest, error) {
	return kernel.LoadManifest(filepath.Join(m.ModuleDir(name, version), "manifest.json"))
}

// Installed возвращает состояние установленных модулей.
func (m *Manager) Installed() (map[string]*ModuleState, error) {
	var st State
	if err := m.Store.Load(&st); err != nil {
		return nil, err
	}
	if st.Modules == nil {
		st.Modules = map[string]*ModuleState{}
	}
	return st.Modules, nil
}

func (m *Manager) installedMap() map[string]*ModuleState {
	mods, _ := m.Installed()
	return mods
}

// EnabledNames — имена включённых модулей по алфавиту.
func (m *Manager) EnabledNames() []string {
	var out []string
	for n, ms := range m.installedMap() {
		if ms.Enabled {
			out = append(out, n)
		}
	}
	sort.Strings(out)
	return out
}

// EnabledManifests — манифесты включённых модулей (с заменами и добавлением/удалением для проверок).
func (m *Manager) EnabledManifests(add string, replace map[string]*kernel.Manifest, remove string) (map[string]*kernel.Manifest, error) {
	names := map[string]bool{}
	for _, n := range m.EnabledNames() {
		names[n] = true
	}
	if add != "" {
		names[add] = true
	}
	if remove != "" {
		delete(names, remove)
	}
	out := map[string]*kernel.Manifest{}
	for n := range names {
		if r, ok := replace[n]; ok {
			out[n] = r
			continue
		}
		mod, err := m.Manifest(n, "")
		if err != nil {
			return nil, err
		}
		out[n] = mod
	}
	return out, nil
}

// Emit публикует событие от имени менеджера. Ошибка журнала не должна ломать операцию — её просто возвращают.
func (m *Manager) Emit(topic string, payload map[string]any) (int64, error) {
	return m.Bus.Publish(topic, payload, "manager")
}

// --- конфигурация ---

// ConfigPath — файл пользовательской конфигурации модуля.
func (m *Manager) ConfigPath(name string) string {
	return filepath.Join(m.Home, "config", name+".json")
}

// Config возвращает конфигурацию: значения по умолчанию из манифеста (mdir или текущей версии) поверх пользовательских.
func (m *Manager) Config(name, mdir string) (map[string]any, error) {
	var base *kernel.Manifest
	var err error
	if mdir != "" {
		base, err = kernel.LoadManifest(filepath.Join(mdir, "manifest.json"))
	} else {
		base, err = m.Manifest(name, "")
	}
	if err != nil {
		return nil, err
	}
	cfg := map[string]any{}
	for k, v := range base.Config {
		cfg[k] = v
	}
	if raw, err := os.ReadFile(m.ConfigPath(name)); err == nil {
		var user map[string]any
		if json.Unmarshal(raw, &user) == nil {
			for k, v := range user {
				cfg[k] = v
			}
		}
	}
	return cfg, nil
}

// ConfigUpdate атомарно меняет конфигурацию модуля под блокировкой. Неизвестный параметр откатывает всё.
func (m *Manager) ConfigUpdate(name string, fn func(cfg map[string]any)) (map[string]any, error) {
	var result map[string]any
	err := m.Txn("config "+name, func(t *kernel.Txn) error {
		mod, err := m.Manifest(name, "")
		if err != nil {
			return err
		}
		path := m.ConfigPath(name)
		var old any
		if raw, err := os.ReadFile(path); err == nil {
			old = string(raw)
		}
		if err := t.AddUndo("restore_file", path, old); err != nil {
			return err
		}
		cfg, err := m.Config(name, "")
		if err != nil {
			return err
		}
		fn(cfg)
		var unknown []string
		for k := range cfg {
			if _, ok := mod.Config[k]; !ok {
				unknown = append(unknown, k)
			}
		}
		if len(unknown) > 0 {
			sort.Strings(unknown)
			return kernel.Newf(kernel.KindGeneric, "%s: неизвестные параметры конфигурации: %s", name, strings.Join(unknown, ", "))
		}
		raw, err := json.MarshalIndent(cfg, "", " ")
		if err != nil {
			return err
		}
		if err := kernel.AtomicWrite(path, raw, 0o644); err != nil {
			return err
		}
		result = cfg
		return nil
	})
	if err != nil {
		return nil, err
	}
	_, _ = m.Emit("config.changed", map[string]any{"module": name})
	m.RefreshExtensions()
	return result, nil
}

// ConfigSet меняет один параметр конфигурации.
func (m *Manager) ConfigSet(name, key string, value any) (map[string]any, error) {
	return m.ConfigUpdate(name, func(c map[string]any) { c[key] = value })
}

// expand подставляет ${data_dir}, ${home}, ${module_dir}, ${core_dir}, ${config.X} во все строки значения.
func (m *Manager) expand(v any, name, mdir string) any {
	cfg, _ := m.Config(name, mdir)
	var rep func(string) string
	rep = func(s string) string {
		return templateRE.ReplaceAllStringFunc(s, func(match string) string {
			k := templateRE.FindStringSubmatch(match)[1]
			switch {
			case k == "data_dir":
				return filepath.Join(m.Home, "data", name)
			case k == "home":
				return m.Home
			case k == "module_dir":
				return mdir
			case k == "core_dir":
				return m.CoreDir
			case strings.HasPrefix(k, "config."):
				return cfgString(cfg[strings.TrimPrefix(k, "config.")])
			}
			return ""
		})
	}
	var walk func(any) any
	walk = func(x any) any {
		switch t := x.(type) {
		case string:
			return rep(t)
		case []any:
			out := make([]any, len(t))
			for i, e := range t {
				out[i] = walk(e)
			}
			return out
		case map[string]any:
			out := make(map[string]any, len(t))
			for k, e := range t {
				out[k] = walk(e)
			}
			return out
		}
		return x
	}
	return walk(v)
}

func cfgString(v any) string {
	switch t := v.(type) {
	case nil:
		return ""
	case bool:
		if t {
			return "1"
		}
		return ""
	case string:
		return t
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	}
	return fmt.Sprint(v)
}

// expandList раскрывает шаблоны в списке строк команды.
func (m *Manager) expandList(list []string, name, mdir string) []string {
	out := make([]string, len(list))
	for i, s := range list {
		out[i] = m.expand(s, name, mdir).(string)
	}
	return out
}

func (m *Manager) expandStr(v any, name, mdir string) string {
	s, _ := m.expand(v, name, mdir).(string)
	return s
}

// envFor — окружение процесса модуля.
func (m *Manager) envFor(name string, mod *kernel.Manifest, mdir string, staging bool) []string {
	env := map[string]string{}
	for _, kv := range os.Environ() {
		if i := strings.IndexByte(kv, '='); i > 0 {
			env[kv[:i]] = kv[i+1:]
		}
	}
	data := filepath.Join(m.Home, "data", name)
	_ = os.MkdirAll(data, 0o755)
	stg := ""
	if staging {
		stg = "1"
	}
	for k, v := range map[string]string{"ZEROCORE_API": "1", "ZEROCORE_HOME": m.Home, "ZEROCORE_MODULE": name,
		"ZEROCORE_DATA_DIR": data, "ZEROCORE_STAGING": stg} {
		env[k] = v
	}
	for k, v := range secretEnv(m.Home, name) {
		env[k] = v
	}
	if runEnv, ok := mod.Run["env"].(map[string]any); ok {
		for k, v := range runEnv {
			val := m.expandStr(v, name, mdir)
			if val != "" {
				env[k] = val
			}
		}
	}
	return mapToEnv(env)
}

func mapToEnv(env map[string]string) []string {
	keys := make([]string, 0, len(env))
	for k := range env {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out := make([]string, 0, len(keys))
	for _, k := range keys {
		out = append(out, k+"="+env[k])
	}
	return out
}

// --- состояние ---

// IsRunning — работает ли модуль.
func (m *Manager) IsRunning(name string, mod *kernel.Manifest) bool {
	mdir := m.ModuleDir(name, "")
	switch mod.Kind {
	case "external":
		spec, _ := m.expand(mod.Health, name, mdir).(map[string]any)
		if t, _ := spec["type"].(string); t != "pgrep" {
			return false
		}
		return kernel.CheckHealth(spec, m.Runner, name, "", nil, time.Now(), 0).State == "healthy"
	case "library", "job":
		return false
	}
	_, ok := m.Runner.Pid(name, "")
	return ok
}

// Health — состояние здоровья модуля.
func (m *Manager) Health(name string) (kernel.Health, error) {
	mod, err := m.Manifest(name, "")
	if err != nil {
		return kernel.Health{}, err
	}
	mdir := m.ModuleDir(name, "")
	spec, _ := m.expand(mod.Health, name, mdir).(map[string]any)
	rt := m.runtimeOf(name)
	interval, _ := asIntAny(mod.Run["schedule_seconds"])
	return kernel.CheckHealth(spec, m.Runner, name, "", rt, time.Now(), interval), nil
}

func (m *Manager) runtimeOf(name string) map[string]any {
	var all map[string]any
	_ = m.RuntimeSt.Load(&all)
	rt, _ := all[name].(map[string]any)
	return rt
}

func asIntAny(v any) (int, bool) {
	f, ok := v.(float64)
	return int(f), ok
}

// Status — строки для панели: все установленные модули с состоянием.
func (m *Manager) Status() []map[string]any {
	installed := m.installedMap()
	names := sortedKeys(installed)
	rows := []map[string]any{}
	for _, n := range names {
		ms := installed[n]
		row := map[string]any{"name": n, "version": ms.Version, "enabled": ms.Enabled, "versions": ms.Versions}
		mod, err := m.Manifest(n, "")
		if err != nil {
			row["kind"], row["provides"], row["running"], row["health"], row["detail"] = "?", []string{}, false, "broken", err.Error()
		} else {
			h, _ := m.Health(n)
			row["kind"], row["provides"] = mod.Kind, mod.Provides
			row["running"], row["health"], row["detail"] = m.IsRunning(n, mod), h.State, h.Detail
		}
		rows = append(rows, row)
	}
	return rows
}

// CheckIntegrity — проблемы целостности включённых модулей.
func (m *Manager) CheckIntegrity() []string {
	manifests, err := m.EnabledManifests("", nil, "")
	if err != nil {
		return []string{err.Error()}
	}
	if _, err := Solve(manifests); err != nil {
		return []string{err.Error()}
	}
	return nil
}

// --- процессы ---

func (m *Manager) runCmd(argv []string) error {
	if len(argv) == 0 {
		return kernel.Newf(kernel.KindLifecycle, "пустая команда")
	}
	cmd := exec.Command(argv[0], argv[1:]...)
	out, err := cmd.CombinedOutput()
	if err != nil {
		if ee, ok := err.(*exec.ExitError); ok {
			return kernel.Newf(kernel.KindLifecycle, "команда %s завершилась кодом %d: %s", argv[0], ee.ExitCode(), trimTail(string(out), 300))
		}
		return kernel.Newf(kernel.KindLifecycle, "команда %s не выполнена: %v", argv[0], err)
	}
	return nil
}

func trimTail(s string, n int) string {
	s = strings.TrimSpace(s)
	if len(s) > n {
		return s[len(s)-n:]
	}
	return s
}

func (m *Manager) spawn(name string, mod *kernel.Manifest, mdir, suffix string, staging bool) error {
	argv := m.expandList(stringsOfAny(mod.Run["command"]), name, mdir)
	cwdRaw, ok := mod.Run["cwd"].(string)
	if !ok {
		cwdRaw = "${module_dir}"
	}
	cwd := m.expandStr(cwdRaw, name, mdir)
	env := m.envFor(name, mod, mdir, staging)
	_, err := m.Runner.Start(name, argv, cwd, env, mod.Limits, suffix)
	return err
}

func (m *Manager) startInstance(name string, mod *kernel.Manifest, mdir, suffix string, staging bool) error {
	if mod.Kind == "external" {
		if err := m.runCmd(m.expandList(stringsOfAny(mod.Run["start_command"]), name, mdir)); err != nil {
			return err
		}
	} else if err := m.spawn(name, mod, mdir, suffix, staging); err != nil {
		return err
	}
	return m.waitReady(name, mod, mdir, suffix)
}

func (m *Manager) stopInstance(name string, mod *kernel.Manifest, suffix string) error {
	timeout := numOrDefault(mod.Run["stop_timeout"], 10)
	if mod.Kind == "external" {
		mdir := m.ModuleDir(name, "")
		if cmd := stringsOfAny(mod.Run["stop_command"]); len(cmd) > 0 {
			if err := m.runCmd(m.expandList(cmd, name, mdir)); err != nil {
				return err
			}
		}
		if !kernel.WaitUntil(func() bool { return !m.IsRunning(name, mod) }, time.Duration(timeout)*time.Second) {
			if cmd := stringsOfAny(mod.Run["kill_command"]); len(cmd) > 0 {
				if err := m.runCmd(m.expandList(cmd, name, mdir)); err != nil {
					return err
				}
			}
			if !kernel.WaitUntil(func() bool { return !m.IsRunning(name, mod) }, 5*time.Second) {
				return kernel.Newf(kernel.KindLifecycle, "%s: не удалось остановить", name)
			}
		}
		return nil
	}
	_, err := m.Runner.Stop(name, time.Duration(timeout)*time.Second, suffix)
	return err
}

func numOrDefault(v any, def int) int {
	if f, ok := v.(float64); ok {
		return int(f)
	}
	return def
}

func (m *Manager) waitReady(name string, mod *kernel.Manifest, mdir, suffix string) error {
	spec, _ := m.expand(mod.Health, name, mdir).(map[string]any)
	timeout := numOrDefault(mod.Run["start_timeout"], 10)
	t, _ := spec["type"].(string)
	if t == "" {
		t = "none"
	}
	if (t == "none" || t == "process") && mod.Kind != "external" {
		time.Sleep(300 * time.Millisecond)
		if _, ok := m.Runner.Pid(name, suffix); !ok {
			return kernel.Newf(kernel.KindLifecycle, "%s: завершился сразу после запуска. Лог: %q", name, m.Runner.LogTail(name, 600))
		}
		return nil
	}
	end := time.Now().Add(time.Duration(timeout) * time.Second)
	last := kernel.Health{State: "unknown"}
	for time.Now().Before(end) {
		if mod.Kind != "external" {
			if _, ok := m.Runner.Pid(name, suffix); !ok {
				return kernel.Newf(kernel.KindLifecycle, "%s: процесс завершился при запуске. Лог: %q", name, m.Runner.LogTail(name, 600))
			}
		}
		last = kernel.CheckHealth(spec, m.Runner, name, suffix, nil, time.Now(), 0)
		if last.State == "healthy" {
			return nil
		}
		time.Sleep(100 * time.Millisecond)
	}
	return kernel.Newf(kernel.KindLifecycle, "%s: не стал здоровым за %d с (%s)", name, timeout, last.Detail)
}

// setDesired меняет флаг «должна работать» у модулей под транзакцией.
func (m *Manager) setDesired(names []string, value bool) error {
	return m.Txn("flag desired", func(t *kernel.Txn) error {
		var st State
		if err := m.Store.Load(&st); err != nil {
			return err
		}
		for _, n := range names {
			if ms, ok := st.Modules[n]; ok {
				ms.Desired = value
			}
		}
		return m.Store.Save(st)
	})
}

// closure — модуль и всё, от чего он зависит (транзитивно).
func (m *Manager) closure(name string, manifests map[string]*kernel.Manifest) map[string]bool {
	reg, err := kernel.NewRegistry(manifests)
	if err != nil {
		return map[string]bool{name: true}
	}
	edges, _ := buildEdges(manifests, reg)
	seen := map[string]bool{}
	stack := []string{name}
	for len(stack) > 0 {
		n := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		if seen[n] {
			continue
		}
		seen[n] = true
		for d := range edges[n] {
			stack = append(stack, d)
		}
	}
	return seen
}

// Start запускает модуль вместе с зависимостями. Возвращает список запущенных.
func (m *Manager) Start(name string) ([]string, error) {
	st := m.installedMap()
	ms, ok := st[name]
	if !ok {
		return nil, kernel.Newf(kernel.KindGeneric, "%s: не установлен", name)
	}
	if !ms.Enabled {
		return nil, kernel.Newf(kernel.KindGeneric, "%s: не включён (zerocore enable %s)", name, name)
	}
	manifests, err := m.EnabledManifests("", nil, "")
	if err != nil {
		return nil, err
	}
	order, err := Solve(manifests)
	if err != nil {
		return nil, err
	}
	closure := m.closure(name, manifests)
	var started []string
	for _, n := range order {
		if !closure[n] {
			continue
		}
		mod := manifests[n]
		if mod.Kind == "library" || mod.Kind == "job" || m.IsRunning(n, mod) {
			continue
		}
		if err := m.startInstance(n, mod, m.ModuleDir(n, ""), "", false); err != nil {
			_, _ = m.Emit("module.failed", map[string]any{"module": n, "error": truncate(err.Error(), 500)})
			return started, err
		}
		started = append(started, n)
		_, _ = m.Emit("module.started", map[string]any{"module": n})
	}
	var desired []string
	for n := range closure {
		if k := manifests[n].Kind; k == "service" || k == "external" {
			desired = append(desired, n)
		}
	}
	_ = m.setDesired(desired, true)
	return started, nil
}

func truncate(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}

// Stop останавливает модуль и зависящие от него. Возвращает остановленные.
func (m *Manager) Stop(name string) ([]string, error) {
	manifests, err := m.EnabledManifests("", nil, "")
	if err != nil {
		return nil, err
	}
	var victims []string
	if _, ok := manifests[name]; ok {
		deps := Dependents(name, manifests)
		order, err := Solve(manifests)
		if err != nil {
			return nil, err
		}
		for i := len(order) - 1; i >= 0; i-- {
			if deps[order[i]] {
				victims = append(victims, order[i])
			}
		}
	}
	var stopped []string
	for _, n := range append(append([]string{}, victims...), name) {
		mod, ok := manifests[n]
		if !ok {
			mod, err = m.Manifest(n, "")
			if err != nil {
				return stopped, err
			}
		}
		if m.IsRunning(n, mod) {
			if err := m.stopInstance(n, mod, ""); err != nil {
				return stopped, err
			}
			stopped = append(stopped, n)
			_, _ = m.Emit("module.stopped", map[string]any{"module": n})
		}
	}
	_ = m.setDesired(append(victims, name), false)
	return stopped, nil
}

// Restart — остановить и запустить заново.
func (m *Manager) Restart(name string) ([]string, error) {
	if _, err := m.Stop(name); err != nil {
		return nil, err
	}
	return m.Start(name)
}

// Enable включает модуль. Если он сервис или внешний и autostart не выключен — запускает.
func (m *Manager) Enable(name string) (bool, error) {
	changed := false
	err := m.Txn("enable "+name, func(t *kernel.Txn) error {
		var st State
		if err := m.Store.Load(&st); err != nil {
			return err
		}
		ms, ok := st.Modules[name]
		if !ok {
			return kernel.Newf(kernel.KindGeneric, "%s: не установлен", name)
		}
		if ms.Enabled {
			return nil
		}
		manifests, err := m.EnabledManifests(name, nil, "")
		if err != nil {
			return err
		}
		if _, err := Solve(manifests); err != nil {
			return err
		}
		ms.Enabled = true
		changed = true
		return m.Store.Save(st)
	})
	if err != nil {
		return false, err
	}
	if !changed {
		return false, nil
	}
	_, _ = m.Emit("module.enabled", map[string]any{"module": name})
	m.RefreshExtensions()
	mod, err := m.Manifest(name, "")
	if err != nil {
		return true, err
	}
	auto := true
	if v, ok := mod.Run["autostart"].(bool); ok {
		auto = v
	}
	if (mod.Kind == "service" || mod.Kind == "external") && auto {
		if _, err := m.Start(name); err != nil {
			return true, err
		}
	}
	return true, nil
}

// Disable выключает модуль. С cascade выключает и зависящие от него. Возвращает выключенные.
func (m *Manager) Disable(name string, cascade bool) ([]string, error) {
	manifests, err := m.EnabledManifests("", nil, "")
	if err != nil {
		return nil, err
	}
	if _, ok := manifests[name]; !ok {
		return nil, nil
	}
	deps := Dependents(name, manifests)
	if len(deps) > 0 && !cascade {
		return nil, kernel.Newf(kernel.KindDependency, "от %s зависят включённые модули: %s (используйте cascade)", name, strings.Join(sortedBoolKeys(deps), ", "))
	}
	order, err := Solve(manifests)
	if err != nil {
		return nil, err
	}
	victims := []string{}
	for i := len(order) - 1; i >= 0; i-- {
		if deps[order[i]] {
			victims = append(victims, order[i])
		}
	}
	victims = append(victims, name)
	for _, n := range victims {
		if m.IsRunning(n, manifests[n]) {
			if err := m.stopInstance(n, manifests[n], ""); err != nil {
				return nil, err
			}
		}
	}
	err = m.Txn("disable "+name, func(t *kernel.Txn) error {
		var st State
		if err := m.Store.Load(&st); err != nil {
			return err
		}
		for _, n := range victims {
			if ms, ok := st.Modules[n]; ok {
				ms.Enabled = false
				ms.Desired = false
			}
		}
		return m.Store.Save(st)
	})
	if err != nil {
		return nil, err
	}
	for _, n := range victims {
		_, _ = m.Emit("module.disabled", map[string]any{"module": n})
	}
	m.RefreshExtensions()
	return victims, nil
}

func sortedBoolKeys(m map[string]bool) []string {
	out := make([]string, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}

func stringsOfAny(v any) []string {
	l, _ := v.([]any)
	out := make([]string, 0, len(l))
	for _, x := range l {
		if s, ok := x.(string); ok {
			out = append(out, s)
		}
	}
	return out
}
