package panel

// Ручные настройки модели для Марин: адрес, ключ и модель в <home>/llm.json (права 0600).
// Ключ наружу не отдаётся ни панелью, ни командой llm show.

import (
	"encoding/json"
	"errors"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"unicode"
)

type llmFile struct {
	BaseURL string `json:"base_url"`
	APIKey  string `json:"api_key"`
	Model   string `json:"model"`
}

func llmFilePath(home string) string { return filepath.Join(home, "llm.json") }

// loadLLMFile читает сохранённые настройки; ok только если заполнены все три поля.
func loadLLMFile(home string) (llmFile, bool) {
	if home == "" {
		return llmFile{}, false
	}
	raw, err := os.ReadFile(llmFilePath(home))
	if err != nil {
		return llmFile{}, false
	}
	var f llmFile
	if json.Unmarshal(raw, &f) != nil || f.BaseURL == "" || f.APIKey == "" || f.Model == "" {
		return llmFile{}, false
	}
	return f, true
}

// SaveLLM проверяет и сохраняет настройки модели.
func SaveLLM(home, baseURL, key, model string) error {
	baseURL = strings.TrimRight(strings.TrimSpace(baseURL), "/")
	key = strings.TrimSpace(key)
	model = strings.TrimSpace(model)
	u, err := url.Parse(baseURL)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Hostname() == "" {
		return errors.New("адрес должен быть вида https://хост/путь")
	}
	if key == "" {
		return errors.New("ключ пустой")
	}
	for _, r := range key {
		if unicode.IsSpace(r) || unicode.IsControl(r) {
			return errors.New("в ключе есть пробелы или управляющие символы: вставьте только сам ключ")
		}
	}
	if len(key) > 500 {
		return errors.New("ключ слишком длинный")
	}
	if model == "" || len(model) > 200 {
		return errors.New("модель: от 1 до 200 символов")
	}
	raw, _ := json.MarshalIndent(llmFile{BaseURL: baseURL, APIKey: key, Model: model}, "", " ")
	return writeFileAtomic(llmFilePath(home), raw, 0o600)
}

// ClearLLM удаляет сохранённые настройки.
func ClearLLM(home string) error {
	err := os.Remove(llmFilePath(home))
	if err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

// LLMStatus — что сохранено, без ключа.
func LLMStatus(home string) map[string]any {
	f, ok := loadLLMFile(home)
	if !ok {
		return map[string]any{"configured": false}
	}
	host := ""
	if u, err := url.Parse(f.BaseURL); err == nil {
		host = u.Hostname()
	}
	return map[string]any{"configured": true, "base_url": f.BaseURL, "host": host, "model": f.Model, "key_set": true}
}
