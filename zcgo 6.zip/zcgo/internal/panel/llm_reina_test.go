package panel

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestLLMCredentialsFromReinaConfig(t *testing.T) {
	t.Setenv("ZEROCORE_LLM_URL", "")
	t.Setenv("ZEROCORE_LLM_KEY", "")
	t.Setenv("ZEROCORE_LLM_MODEL", "")
	p := filepath.Join(t.TempDir(), "config.json")
	cfg := `{"telegram":{"api_hash":"nope"},"llm":{"base_url":"https://openrouter.ai/api/v1/","api_key":"sk-secret-1","fast_model":"fast/x","strong_model":"strong/y"},"voice":{"api_key":"other"}}`
	if err := os.WriteFile(p, []byte(cfg), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("ZEROCORE_REINA_CONFIG", p)
	c, err := llmCredentials(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if c.URL != "https://openrouter.ai/api/v1" || c.Key != "sk-secret-1" || c.Model != "strong/y" {
		t.Fatalf("настройки: %+v", c)
	}
	av := llmAvailable(t.TempDir())
	if av["available"] != true || av["model"] != "strong/y" {
		t.Fatalf("available: %v", av)
	}
	for _, v := range av {
		if s, ok := v.(string); ok && strings.Contains(s, "sk-secret-1") {
			t.Fatal("ключ попал в ответ")
		}
	}
}

func TestLLMCredentialsMissingIsExplained(t *testing.T) {
	t.Setenv("ZEROCORE_LLM_URL", "")
	t.Setenv("ZEROCORE_LLM_KEY", "")
	t.Setenv("ZEROCORE_LLM_MODEL", "")
	t.Setenv("ZEROCORE_REINA_CONFIG", filepath.Join(t.TempDir(), "нет.json"))
	if _, err := llmCredentials(t.TempDir()); err == nil || !strings.Contains(err.Error(), "ZEROCORE_REINA_CONFIG") {
		t.Fatalf("ошибка: %v", err)
	}
}

func TestManualLLMSettingsBeatReinaAndNeverLeakKey(t *testing.T) {
	t.Setenv("ZEROCORE_LLM_URL", "")
	t.Setenv("ZEROCORE_LLM_KEY", "")
	t.Setenv("ZEROCORE_LLM_MODEL", "")
	d := t.TempDir()
	rp := filepath.Join(d, "reina.json")
	_ = os.WriteFile(rp, []byte(`{"llm":{"base_url":"https://old.example/v1","api_key":"old-key","strong_model":"old/m"}}`), 0o600)
	t.Setenv("ZEROCORE_REINA_CONFIG", rp)
	home := filepath.Join(d, "home")
	if err := SaveLLM(home, "https://api.example.com/v1/", "  sk-manual-777  ", "my/model"); err != nil {
		t.Fatal(err)
	}
	c, err := llmCredentialsHome(home, "")
	if err != nil || c.URL != "https://api.example.com/v1" || c.Key != "sk-manual-777" || c.Model != "my/model" {
		t.Fatalf("настройки: %+v, %v", c, err)
	}
	if st, _ := os.Stat(llmFilePath(home)); st.Mode().Perm() != 0o600 {
		t.Fatalf("права файла: %v", st.Mode().Perm())
	}
	raw, _ := json.Marshal(LLMStatus(home))
	if strings.Contains(string(raw), "sk-manual-777") {
		t.Fatal("ключ попал в статус")
	}
	if err := ClearLLM(home); err != nil {
		t.Fatal(err)
	}
	c, _ = llmCredentialsHome(home, "")
	if c.Key != "old-key" {
		t.Fatalf("после очистки должен остаться запасной вариант: %+v", c)
	}
}

func TestSaveLLMRejectsBadInput(t *testing.T) {
	home := t.TempDir()
	bad := [][3]string{
		{"not a url", "k", "m"},
		{"ftp://x.y/v1", "k", "m"},
		{"https://x.y/v1", "", "m"},
		{"https://x.y/v1", "two words", "m"},
		{"https://x.y/v1", "k", ""},
	}
	for _, b := range bad {
		if err := SaveLLM(home, b[0], b[1], b[2]); err == nil {
			t.Fatalf("принято: %v", b)
		}
	}
	if _, err := os.Stat(llmFilePath(home)); err == nil {
		t.Fatal("после отказов файл не должен появиться")
	}
}

func TestLLMSettingsRoutes(t *testing.T) {
	t.Setenv("ZEROCORE_LLM_KEY", "")
	srv, _ := newPanel(t)
	st, out, ok := srv.postExtra([]string{"llm", "settings"}, map[string]any{"base_url": "https://api.example.com/v1", "api_key": "sk-route-1", "model": "m"})
	if !ok || st != 200 || out.(map[string]any)["configured"] != true {
		t.Fatalf("сохранение: %d %v", st, out)
	}
	raw, _ := json.Marshal(out)
	if strings.Contains(string(raw), "sk-route-1") {
		t.Fatal("ключ в ответе")
	}
	st, _, _ = srv.postExtra([]string{"llm", "settings"}, map[string]any{"base_url": "x", "api_key": "k", "model": "m"})
	if st != 400 {
		t.Fatalf("плохой адрес принят: %d", st)
	}
}
