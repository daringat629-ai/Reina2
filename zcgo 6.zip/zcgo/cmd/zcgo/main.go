// zcgo — Go-версия ядра zero_core: установка, включение, запуск, замена версий, доверие, патчи, тики.
//
//	zcgo [--home DIR] <команда> [аргументы]
//
//	status                         состояние всех модулей
//	install <папка|архив.zip>      установка (выключенным)
//	enable|disable <модуль> [--cascade]
//	start|stop|restart <модуль>
//	swap <модуль> <версия>         горячая замена версии
//	rollback <модуль>              откат на предыдущую версию
//	uninstall <модуль> [--purge|--keep-data] [--force]
//	tools                          пересобрать tools.json и показать итог
//	patches                        применить патчи деталей и показать состояние
//	trust sign|approve|revoke|status <модуль>
//	tick                           периодическая работа (задачи, здоровье, перезапуски)
//	check <папка_модулей>          проверка манифестов в папке
//	tokens <папка_модулей> [--budget N]   сколько токенов уходит модели
//	tool <инструмент> [json]       вызов инструмента как у бота (аргументы JSON-объектом)
//	publish <тема> [json]          публикация события в шину ядра
//	llm set|show|clear            ключ, адрес и модель для Марин (хранятся в <home>/llm.json)
//	panel [--host H] [--port N] [--tunnel]   панель «Нулевое ядро» в браузере (по умолчанию 127.0.0.1:8767); --tunnel даёт публичную https-ссылку
package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"time"

	"zcgo/internal/kernel"
	"zcgo/internal/manager"
	"zcgo/internal/panel"
	"zcgo/internal/sdk"
	"zcgo/internal/toolcall"
	"zcgo/internal/tunnel"
)

func usage() {
	fmt.Fprintln(os.Stderr, "использование: zcgo [--home DIR] <команда> [аргументы]; команды: status install enable disable start stop restart swap rollback uninstall tools patches trust tick check tokens")
}

func main() {
	defHome := filepath.Join(userHome(), "zero_core_home")
	home := os.Getenv("ZEROCORE_HOME")
	if home == "" {
		home = defHome
	}
	global := flag.NewFlagSet("zcgo", flag.ContinueOnError)
	homeFlag := global.String("home", home, "каталог состояния ядра")
	global.Usage = usage
	if err := global.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}
	args := global.Args()
	if len(args) == 0 {
		usage()
		os.Exit(2)
	}
	cmd, rest := args[0], args[1:]
	os.Exit(run(cmd, rest, *homeFlag))
}

func userHome() string {
	h, err := os.UserHomeDir()
	if err != nil {
		return "."
	}
	return h
}

func coreDir() string {
	if d := os.Getenv("ZEROCORE_CORE_DIR"); d != "" {
		return d
	}
	wd, _ := os.Getwd()
	return wd
}

func fail(err error) int {
	fmt.Println("ОШИБКА:", err)
	return 1
}

func run(cmd string, args []string, home string) int {
	switch cmd {
	case "check":
		return cmdCheck(args)
	case "tokens":
		return cmdTokens(args)
	case "llm":
		return cmdLLM(home, args)
	}
	mgr, err := manager.New(home, coreDir())
	if err != nil {
		return fail(err)
	}
	switch cmd {
	case "status":
		rows := mgr.Status()
		out, _ := json.MarshalIndent(rows, "", " ")
		fmt.Println(string(out))
		return 0
	case "install":
		if len(args) != 1 {
			return usageErr("install <папка|архив.zip>")
		}
		mod, err := mgr.Install(args[0])
		if err != nil {
			return fail(err)
		}
		fmt.Printf("установлен %s %s (выключен)\n", mod.Name, mod.Version)
		return 0
	case "enable":
		if len(args) != 1 {
			return usageErr("enable <модуль>")
		}
		changed, err := mgr.Enable(args[0])
		if err != nil {
			return fail(err)
		}
		if !changed {
			fmt.Println("уже включён")
		} else {
			fmt.Println("включён", args[0])
		}
		return 0
	case "disable":
		fs := flag.NewFlagSet("disable", flag.ContinueOnError)
		cascade := fs.Bool("cascade", false, "выключить и зависящие модули")
		name, ok := nameArg(fs, args)
		if !ok {
			return usageErr("disable <модуль> [--cascade]")
		}
		victims, err := mgr.Disable(name, *cascade)
		if err != nil {
			return fail(err)
		}
		fmt.Println("выключено:", strings.Join(victims, ", "))
		return 0
	case "start":
		return simple(args, "start <модуль>", func(n string) error { _, err := mgr.Start(n); return err }, "запущен")
	case "stop":
		return simple(args, "stop <модуль>", func(n string) error { _, err := mgr.Stop(n); return err }, "остановлен")
	case "restart":
		return simple(args, "restart <модуль>", func(n string) error { _, err := mgr.Restart(n); return err }, "перезапущен")
	case "swap":
		if len(args) != 2 {
			return usageErr("swap <модуль> <версия>")
		}
		old, nw, err := mgr.Swap(args[0], args[1])
		if err != nil {
			return fail(err)
		}
		fmt.Printf("%s: %s -> %s\n", args[0], old, nw)
		return 0
	case "rollback":
		return simple(args, "rollback <модуль>", func(n string) error {
			old, nw, err := mgr.Rollback(n)
			if err == nil {
				fmt.Printf("%s: %s -> %s\n", n, old, nw)
			}
			return err
		}, "")
	case "uninstall":
		fs := flag.NewFlagSet("uninstall", flag.ContinueOnError)
		purge := fs.Bool("purge", false, "удалить данные")
		keep := fs.Bool("keep-data", false, "сохранить данные")
		force := fs.Bool("force", false, "удалить даже при зависимостях")
		name, ok := nameArg(fs, args)
		if !ok {
			return usageErr("uninstall <модуль> [--purge|--keep-data] [--force]")
		}
		var p *bool
		if *purge {
			t := true
			p = &t
		} else if *keep {
			f := false
			p = &f
		}
		purged, err := mgr.Uninstall(name, p, *force, false)
		if err != nil {
			return fail(err)
		}
		fmt.Printf("удалён %s (данные удалены: %v)\n", name, purged)
		return 0
	case "tools":
		cat, err := mgr.ExportTools()
		if err != nil {
			return fail(err)
		}
		fmt.Printf("инструментов: %d, проблем: %d\n", len(cat.Tools), len(cat.Errors))
		for _, e := range cat.Errors {
			fmt.Println("  -", e)
		}
		return 0
	case "patches":
		state, err := mgr.SyncAllPatches()
		if err != nil {
			return fail(err)
		}
		out, _ := json.MarshalIndent(state, "", " ")
		fmt.Println(string(out))
		return 0
	case "trust":
		return cmdTrust(mgr, args)
	case "tool":
		return cmdTool(mgr, args)
	case "publish":
		return cmdPublish(mgr, args)
	case "panel":
		return cmdPanel(mgr, args)
	case "tick":
		for _, a := range mgr.Tick(time.Now()) {
			fmt.Println(a)
		}
		return 0
	}
	usage()
	return 2
}

func nameArg(fs *flag.FlagSet, args []string) (string, bool) {
	// флаги указываются до имени модуля или после него
	var flags, pos []string
	for _, a := range args {
		if strings.HasPrefix(a, "-") {
			flags = append(flags, a)
		} else {
			pos = append(pos, a)
		}
	}
	if err := fs.Parse(flags); err != nil || len(pos) != 1 {
		return "", false
	}
	return pos[0], true
}

func simple(args []string, usageText string, fn func(string) error, done string) int {
	if len(args) != 1 {
		return usageErr(usageText)
	}
	if err := fn(args[0]); err != nil {
		return fail(err)
	}
	if done != "" {
		fmt.Println(args[0], done)
	}
	return 0
}

func usageErr(u string) int {
	fmt.Println("использование: zcgo", u)
	return 2
}

func cmdTrust(mgr *manager.Manager, args []string) int {
	if len(args) != 2 {
		return usageErr("trust sign|approve|revoke|status <модуль>")
	}
	action, name := args[0], args[1]
	dir := mgr.ModuleDir(name, "")
	switch action {
	case "sign":
		doc, err := manager.Sign(mgr.Home, dir)
		if err != nil {
			return fail(err)
		}
		fmt.Printf("подписан %s (файлов: %d, ключ %s)\n", name, doc.Files, doc.KeyID)
	case "approve":
		if err := manager.Approve(mgr.Home, name, dir, ""); err != nil {
			return fail(err)
		}
		fmt.Println("одобрен", name)
	case "revoke":
		ok, err := manager.Revoke(mgr.Home, name)
		if err != nil {
			return fail(err)
		}
		fmt.Printf("одобрение снято: %v\n", ok)
	case "status":
		st, err := manager.Status(mgr.Home, name, dir)
		if err != nil {
			return fail(err)
		}
		out, _ := json.MarshalIndent(st, "", " ")
		fmt.Println(string(out))
	default:
		return usageErr("trust sign|approve|revoke|status <модуль>")
	}
	mgr.RefreshExtensions()
	return 0
}

// cmdCheck проверяет все манифесты в папке (без установки).
func cmdCheck(args []string) int {
	if len(args) != 1 {
		return usageErr("check <папка_модулей>")
	}
	found, errs := manager.Discover(args[0])
	for _, e := range errs {
		fmt.Println("ОШИБКА:", e)
	}
	tools := 0
	for _, d := range found {
		tools += len(d.Manifest.Tools)
		if _, err := manager.ValidateSource(d.Dir); err != nil {
			fmt.Println("ОШИБКА:", err)
			errs = append(errs, err.Error())
		}
	}
	fmt.Printf("модулей: %d, инструментов: %d, ошибок: %d\n", len(found), tools, len(errs))
	if len(errs) > 0 {
		return 1
	}
	return 0
}

// cmdTokens — сколько токенов уходит модели с каждым запросом (символы / 3.5, как в Python-версии).
func cmdTokens(args []string) int {
	fs := flag.NewFlagSet("tokens", flag.ContinueOnError)
	budget := fs.Int("budget", 0, "бюджет токенов")
	dir, ok := nameArg(fs, args)
	if !ok {
		return usageErr("tokens <папка_модулей> [--budget N]")
	}
	found, errs := manager.Discover(dir)
	type row struct {
		name, heaviest      string
		tools, chars, heavy int
	}
	var rows []row
	var all []struct {
		name  string
		chars int
	}
	total := 0
	names := make([]string, 0, len(found))
	for n := range found {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		r := row{name: n}
		for _, t := range found[n].Manifest.Tools {
			c := modelChars(t)
			r.tools++
			r.chars += c
			all = append(all, struct {
				name  string
				chars int
			}{t.Name, c})
			if c > r.heavy {
				r.heavy, r.heaviest = c, t.Name
			}
		}
		total += r.chars
		if r.tools > 0 {
			rows = append(rows, r)
		}
	}
	sort.Slice(rows, func(i, j int) bool { return rows[i].chars > rows[j].chars })
	fmt.Printf("%-16s %6s %8s %10s  %s\n", "модуль", "инстр.", "символов", "~токенов", "самый тяжёлый")
	for _, r := range rows {
		fmt.Printf("%-16s %6d %8d %10d  %s (%d)\n", r.name, r.tools, r.chars, kernelTokens(r.chars), r.heaviest, r.heavy)
	}
	fmt.Printf("%-16s %6d %8d %10d\n", "ИТОГО", len(all), total, kernelTokens(total))
	for _, e := range errs {
		fmt.Println("ОШИБКА:", e)
	}
	if *budget > 0 && kernelTokens(total) > *budget {
		sort.Slice(all, func(i, j int) bool { return all[i].chars > all[j].chars })
		fmt.Printf("ПРЕВЫШЕН бюджет %d токенов. Самые тяжёлые инструменты:\n", *budget)
		for i := 0; i < 5 && i < len(all); i++ {
			fmt.Printf("  %-22s %d символов\n", all[i].name, all[i].chars)
		}
		return 1
	}
	if len(errs) > 0 {
		return 1
	}
	return 0
}

func kernelTokens(chars int) int { return int(float64(chars) / 3.5) }

func modelChars(t kernel.Tool) int {
	params := t.Parameters
	if params == nil {
		params = map[string]map[string]any{}
	}
	req := t.Required
	if req == nil {
		req = []string{}
	}
	payload := map[string]any{"type": "function", "name": t.Name, "description": t.Description,
		"parameters": map[string]any{"type": "object", "properties": params, "required": req}}
	raw, _ := json.Marshal(payload)
	return len([]rune(string(raw)))
}

// cmdTool вызывает инструмент из tools.json так же, как бот kuni.
func cmdTool(mgr *manager.Manager, args []string) int {
	if len(args) < 1 || len(args) > 2 {
		return usageErr("tool <инструмент> [json]")
	}
	raw, err := os.ReadFile(mgr.ToolsPath())
	if err != nil {
		return fail(kernel.Newf(kernel.KindGeneric, "каталог инструментов не найден: %v", err))
	}
	var cat struct {
		Tools []toolcall.Tool `json:"tools"`
	}
	if err := json.Unmarshal(raw, &cat); err != nil {
		return fail(err)
	}
	tool, ok := toolcall.Find(cat.Tools, args[0])
	if !ok {
		fmt.Printf("error: unknown tool %s\n", args[0])
		return 1
	}
	argsJSON := ""
	if len(args) == 2 {
		argsJSON = args[1]
	}
	prep := toolcall.Prepare(tool, argsJSON)
	if prep.Error != "" {
		fmt.Println(prep.Error)
		return 1
	}
	text := toolcall.Run(tool, prep.Payload)
	fmt.Println(text)
	if strings.HasPrefix(text, "error:") {
		return 1
	}
	return 0
}

// cmdPublish публикует событие от имени модуля (ZEROCORE_MODULE, если задан).
func cmdPublish(mgr *manager.Manager, args []string) int {
	if len(args) < 1 || len(args) > 2 {
		return usageErr("publish <тема> [json]")
	}
	payload := ""
	if len(args) == 2 {
		payload = args[1]
	}
	id, err := sdk.PublishJSON(mgr.Home, args[0], payload)
	if err != nil {
		return fail(err)
	}
	fmt.Println("событие", id, args[0])
	return 0
}

// cmdPanel поднимает HTTP-панель. Токен не печатается: он в файле panel_token (права 0600).
func cmdPanel(mgr *manager.Manager, args []string) int {
	fs := flag.NewFlagSet("panel", flag.ContinueOnError)
	host := fs.String("host", "127.0.0.1", "адрес для прослушивания")
	port := fs.Int("port", 8767, "порт")
	useTunnel := fs.Bool("tunnel", false, "публичная https-ссылка через Cloudflare Quick Tunnel (cloudflared скачивается сам)")
	if err := fs.Parse(args); err != nil {
		return 2
	}
	srv, err := panel.New(mgr)
	if err != nil {
		return fail(err)
	}
	srv.SetListenPort(*port)
	addr := net.JoinHostPort(*host, strconv.Itoa(*port))
	httpSrv := &http.Server{Addr: addr, Handler: srv.Handler(), ReadHeaderTimeout: 10 * time.Second}
	srv.StartBackground()
	defer srv.StopBackground()
	fmt.Printf("Панель «Нулевое ядро»: http://%s/\n", addr)
	fmt.Printf("Токен: файл %s\n", mgr.Home+"/panel_token")
	if *host != "127.0.0.1" && *host != "localhost" {
		fmt.Fprintln(os.Stderr, "ВНИМАНИЕ: панель слушает не только localhost; токен — единственная защита.")
	}
	if *useTunnel {
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		tun := &tunnel.Module{Home: mgr.Home, Local: addr, OnURL: func(u string) {
			fmt.Printf("Публичная ссылка на панель: %s\n(доступ к API — по токену из panel_token; ссылка меняется при перезапуске)\n", u)
		}}
		go func() { _ = tun.Run(ctx) }()
		fmt.Fprintln(os.Stderr, "ВНИМАНИЕ: панель открыта в интернет по случайной ссылке; в ней есть Марин с доступом к командам, держите токен в секрете.")
	}
	if err := httpSrv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		return fail(err)
	}
	return 0
}
