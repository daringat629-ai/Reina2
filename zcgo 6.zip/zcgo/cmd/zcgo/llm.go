package main

// zcgo llm set|show|clear — ручные настройки модели для Марин (<home>/llm.json, права 0600).
// Ключ спрашивается в терминале без эха, поэтому не попадает в историю команд.

import (
	"bufio"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"strings"

	"zcgo/internal/panel"
)

func readLine(r *bufio.Reader) string {
	s, _ := r.ReadString('\n')
	return strings.TrimSpace(s)
}

func cmdLLM(home string, args []string) int {
	if len(args) == 0 {
		return usageErr("llm set [--url URL] [--model МОДЕЛЬ] | show | clear")
	}
	switch args[0] {
	case "show":
		st := panel.LLMStatus(home)
		if st["configured"] != true {
			fmt.Println("настройки модели не заданы: zcgo llm set")
			return 0
		}
		fmt.Printf("адрес: %v\nмодель: %v\nключ: задан (не показывается)\n", st["base_url"], st["model"])
		return 0
	case "clear":
		if err := panel.ClearLLM(home); err != nil {
			return fail(err)
		}
		fmt.Println("настройки модели удалены")
		return 0
	case "set":
		fs := flag.NewFlagSet("llm set", flag.ContinueOnError)
		u := fs.String("url", "https://openrouter.ai/api/v1", "адрес OpenAI-совместимого API")
		model := fs.String("model", "", "модель")
		if err := fs.Parse(args[1:]); err != nil {
			return 2
		}
		in := bufio.NewReader(os.Stdin)
		if *model == "" {
			fmt.Print("Модель (например openai/gpt-4o-mini): ")
			*model = readLine(in)
		}
		fmt.Print("Ключ API (ввод скрыт): ")
		hide := exec.Command("stty", "-echo")
		hide.Stdin = os.Stdin
		hidden := hide.Run() == nil
		key := readLine(in)
		if hidden {
			show := exec.Command("stty", "echo")
			show.Stdin = os.Stdin
			_ = show.Run()
		}
		fmt.Println()
		if err := panel.SaveLLM(home, *u, key, *model); err != nil {
			return fail(err)
		}
		fmt.Printf("сохранено: %s, модель %s (ключ в %s/llm.json, права 0600)\n", strings.TrimRight(*u, "/"), *model, home)
		return 0
	}
	return usageErr("llm set [--url URL] [--model МОДЕЛЬ] | show | clear")
}
